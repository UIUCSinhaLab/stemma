STochastic Evolutionary Model for cis-regulatory Module Analysis
STEMMA 1.0
Author: Xu Ling <xuling@illinois.edu>
http://ews.uiuc.edu/~xuling

--------------------------------------------------------------------------
DESCRIPTION

This package includes the programs for regulatory sequence discovery using multi-species genome sequence data. STEMMA is based on a probabilistic model with a spatial component describing the binding site content of CRMs and
a temporal component describing their evolution. A key feature of this model is that the functional state of a site (i.e., whether it is a functional binding site or neutral sequence) is allowed to evolve over time. This naturally incorporates binding site loss and gain, and also provides a mechanism to offset the confounding effects of alignment errors, thus leading to improved CRM discovery and motif finding.
STEMMA offers a powerful probabilistic framework for decoding cis-regulatory programs; this includes the
tasks of (i) searching for TF motifs overrepresented in a set of genes
with similar expression patterns, (ii) finding conserved binding sites of
these TFs, and (iii) predicting CRMs targeted by them.

This package includes variety of programs for the above tasks.
In general, the programs takes input of:
(i) a file of multiple aligned sequences, in MSA (a FASTA-like) format;
(ii) an indel history annotation file, in FASTA format (see sample file in the
"sample-data" directory, which can be produce by the program "indelHistory" in
the Phast package)
(iii) a phylogeny tree file, in Newick format
Outputs:
(i) LLR (Log-Likelihood-Ratio) scores of certain fix-length sequence site as a
CRM or a TFBS,
or (ii) decoded CRM and TFBS annotations.
See section "PROGRAM USAGE" for details.

--------------------------------------------------------------------------
INSTALLATION

The program needs GNU Scientific Library (GSL). If it is not installed in your system, go to: 
http://www.gnu.org/software/gsl/
After installing GSL, you need to change the start-up script of your shell, e.g., .bash_profile at your home directory if you are using bash. Suppose the GSL installation directory is /raid/apps/gsl-1.8: 

LD_LIBRARY_PATH=/raid/apps/gsl-1.8/lib:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH

NOTE: STEMMA has been successfully tested with gsl 1.8.
Other gsl vertions are not tested yet.
If you have problem compiling STEMMA, please install gsl 1.8.
Sorry about any inconvenience. 

After extracting STEMMA, change the GSL directory in src/Makefile, e.g.: 
GSL_DIR = my_gsl_dir

Then simply type: 
cd src/
gmake

All the executables are in the src/ directory. 

--------------------------------------------------------------------------
PROGRAM USAGE

########### 1. Window-wise CRM scan ###########

Example files used in the following can be found in sample-data/ directory. To run the program: 

src/crmProfile -s sample-data/eve_stripe2.aln.fa -m sample-data/blast.wtmx -a sample-data/eve_stripe2.ann.fa -t sample-data/full_tree.txt -p sample-data/param.txt -r Mel -win 500 -sft 50 -o sample-data/eve_stripe2

Or

src/crmProfile -path sample-data/input_path.txt -m sample-data/blast.wtmx -t sample-data/full_tree.txt -p sample-data/param.txt -r Mel -win 500 -sft 50 -o sample-data/output

The command line arguments are:

-s <InputSeqFile> : the multiple sequence alignment file in FASTA format
-a <InputIndelFile> : the indel history annotation file
-path <file of the path to InputSeqFile and InputIndelFile>, if -path is
	specified, -s and -a will be ignored. This option is mainly to be used to
	batch crmProfile runs which needs to score a number of sequence alignments.
-t <TreeFile> : the phylogeny tree file of the target sepecies
-m <InputMotifFile> : the wtmx file of input motifs
-p <ParameterFile> : the file specifying model parameters
-r <RefSeqName> : this specifies what species to be used as the reference sequence
-o <outFilePrefix> : prefix of the output files
-lcm <LinageChangeMode> : this specifies what type of linage-specific
	evolutionary changes to be modeled.
	0=background only;
	1=fully conserved;
	2=one event approximation;
	3=only one approximate history.
	Default: 2
-stm <SwitchTimeMode> : this specifies at what time point the binding site
	turnover happens.
	2: t'=t/2, that is, in the middle of the branch;
	3: t'=0, that is, at the begining of the branch.
	Default: 3
-win <windowLength> : this specifies the window length to computer LLR score.
	Default: 500
-sft <shiftLength> : this specifies the shift length of the windows.
	Default: 50

Output: sample output can be found in two files: *.wLLR.txt and *.site.txt
For example: sample-data/eve_stripe2.wLLR.txt and sample-data/eve_stripe2.site.txt
The *.wLLR.txt contains the window-wise LLR score, in 3-column tab-delimited format.
	col_1 = window start position of the reference sequence,
	col_2 = LLR (Likelihood ratio test) score of 500bp window (specified by -win),
	col_3 = window start position of the aligned sequences.
The *.site.txt file has the similar format, but for individual viterbi decoded
TFBS instead of the fix-length windows.
	col_1 = TFBS start position of the reference sequence,
	col_2 = motif index (starting from 1), ordered as in the motif wtmx file
	col_3 = strand of the TFBS, assuming the input sequences in the + strand
	col_4 = TFBS LLR score
	col_5 = TFBS start position of the aligned sequences.
Note, in our Likelihood ratio test, the null hypothesis is that the sequences
evolve according to the background model; the alternative hypothesis is that
they evolve according to CRM model. LLR score greater than, say 10, is
generally significant. But the program does not produce an exact cutoff.
Normally, it will be used to compute LLR for many sequences and choose the
best ones as the likely targets of give motifs.

########## 2. CRM decoding ############

Command line examples:

src/crmPredict -s sample-data/eve_stripe2.aln.fa -m sample-data/blast.wtmx -a
sample-data/eve_stripe2.ann.fa -t sample-data/full_tree.txt -p
sample-data/param.txt -r Mel -o sample-data/eve_stripe2

Or

src/crmPredict -path sample-data/input_path.txt -m sample-data/blast.wtmx -t
sample-data/full_tree.txt -p sample-data/param.txt -r Mel -o sample-data

The command line arguments are:

-s <InputSeqFile> : the multiple sequence alignment file in FASTA format
-a <InputIndelFile> : the indel history annotation file
-path <file of the path to InputSeqFile and InputIndelFile>, if -path is
        specified, -s and -a will be ignored. This option is mainly to be used
to
        batch crmProfile runs which needs to score a number of sequence
alignments.
-t <TreeFile> : the phylogeny tree file of the target sepecies
-m <InputMotifFile> : the wtmx file of input motifs
-p <ParameterFile> : the file specifying model parameters
-r <RefSeqName> : this specifies what species to be used as the reference
sequence
-o <outFilePrefix> : prefix of the output files
-lcm <LinageChangeMode> : this specifies what type of linage-specific
        evolutionary changes to be modeled.
        0=background only;
        1=fully conserved;
        2=one event approximation;
        3=only one approximate history.
        Default: 2
-stm <SwitchTimeMode> : this specifies at what time point the binding site
        turnover happens.
        2: t'=t/2, that is, in the middle of the branch;
        3: t'=0, that is, at the begining of the branch.
        Default: 3

Output: sample output can be found in files: *.module.txt
For example: sample-data/eve_stripe2.module.txt
The *.module.txt contains the information of the predicted crms, in 4-column tab-delimited
format.
        col_1 = length of the CRM region
	col_2 = CRM start position of the reference sequence,
        col_3 = CRM end position of the reference sequence,
        col_4 = TFs which have target binding sites within this CRM.

########## 3. Tree file processing ###########

Command line examples:

src/treeExtractor -tree sample-data/tree.fly_12.txt -nodes "Mel Sim Yak Ere Ana Sec" > sample-data/tree.melanogaster_6.txt

This is to extract the basic phylogeny tree with targeting species (specified
by -nodes) from a larger phylogeny tree (specified by -tree), and print the
extracted tree to screen

src/treeSimple2Complete -tree sample-data/tree.melanogaster_6.txt > sample-data/full_tree.txt

This is to add the internal nodes to the tree file, so that this file can be
later used (i) for generating the indel history annotation using "indelHistory" in
the Phast package, and (ii) as input tree file for STEMMA programs.


--------------------------------------------------------------------------
SETTING UP PARAMETERS

Below is a sample parameter file for crmProfile (# is used for commenting a line): 

# neutral background nt. distribution (used in computation of binding energy)
background = {0.3,0.2,0.2,0.3}

# evolutionary parameters of the background sequence
rate = 1.0      # substitution rate
bias = 2.0      # transition/transversion bias

# HMM transition probs
mu = 0.0005
nu = 0.000125

# TFBS gain/loss rate
Lambda = {0.004, 0.004, 0.004, 0.004, 0.004, 0.004}
Mu = {0.4, 0.4, 0.4, 0.4, 0.4, 0.4}

# TFBS energy threshold
motifThr = {4.55749, 4.77794, 4.4306, 4.47224, 4.25399, 4.49076}


--------------------------------------------------------------------------
PREPARE INPUT FILES

(1) Prepare the motif file: 
It should contain the position weight matrices of all motifs relevant to the sequence. The headline of each motif specifies the name, the length, and the pseudocount values. Note that the pseudocount must be specified as a positive number. And the rest specifies the counts of A,C,G,T in each position. For example: 

>bcd 8  0.1
9       18      3       18
8       3       1       36
45      1       1       1
47      0       1       0
1       0       16      31
1       44      0       3
2       26      3       17
5       12      18      13
<

NOTE: it is OK to use frequencies instead of counts, then pseudocount will not be needed. However, in this case, the frequency of any nucleotide in any position cannot be zero. 

(2) Define the binding energy threshold of motifs:
The threshold values for defining binding site gain and loss.
This value is used to speed up the program as any site with score below it
will not be considered as a TFBS.
The threshold values of the motifs can be estimated using the program comp_thr (see the section OTHER UTILITIES).
If you set it to zero, then the program will exhaustively evaluate every site
as potentially a TFBS. This will make the program slow if you need scan a very large
number of sequences, although the final LLR scores will be very similar.
Also note that the order of motifs in the parameter file and the weight matrix
file above must be identical.

(3) Estimate the background evolutionary parameters: 
These include: 

background
The genome-wide nucleotide frequencies (global background).
This is used for computing the likelihood ratio score of a binding site.

bias
The transition-transversion bias. It will not be reestimated, so choose a reasonable value for the species being analyzed, e.g. 2.0 for fly.


--------------------------------------------------------------------------
OTHER UTILITIES

src/utils/comp_thr
Compute the threshold of TFBSs from a given p value. The score of a TFBS is its likelihood ratio score of the site under the motif model vs the null model (the genomoe-wide nucleotide frequencies). The threshold is chosen from the distribution of scores of sites randomly sampled from the null model, according to the specified p value. 
-m []: the motif file
-N []: optional. The sample size (an integer), how many random sites will be sampled to derive the null distribution. The default value is 10^6. 
-p []: optional, p value. The default is 0.002. 
-c []: optional. The neutral GC content, used to define the score of a TFBS. Should be a positive number, e.g. -c 0.4. The default value is 0.4.

