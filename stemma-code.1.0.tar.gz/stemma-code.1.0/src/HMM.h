// HMM.h: interface for the HMM class.
//
//////////////////////////////////////////////////////////////////////

#ifndef HMM_H
#define HMM_H

//#include <list>
//#include <iostream>
//#include <fstream>

//#include "gsl/gsl_math.h"
//#include <gsl/gsl_vector.h>
//#include <gsl/gsl_matrix.h>
//#include <gsl/gsl_linalg.h>
//#include "gsl/gsl_rng.h"
#include "common.h"
#include "EvolModels.h"
#include "Param.h"
#include "Felsenstein.h"

using namespace std;
using namespace myUtilities;

/*****************************************************
* HMM class, for HMM computation
******************************************************/


class HMM  
{
private:
	struct vCell
	{
		double vLogProb;	// the viterbi prob end with this state
		int motifInd;		// -1: the previous state is NCRM BKG; 0..K: the previous state is CRM motif
		int posInd;			// the previous last-pos to follow
							// -1: means no more pointer to follow, ie, the start of the Viterbi path

		vCell()
		{
			vLogProb = GSL_NEGINF;
			motifInd = -1;
			posInd = -1;
		}
		vCell(double prob, int motif, int pos): vLogProb(prob), motifInd(motif), posInd(pos) {}
		friend ostream& operator<<(ostream& out, const vCell& c)
		{
			out << "(" << c.motifInd << "," << c.posInd << "," << c.vLogProb << ")";
			return out;
		}
	};

	Felsenstein * felsen;
	
	// To record the prob of the output sequences at a certain position
	vector<double> NCrmProb;			// for Forward_NCRM_Prob
	DynamicArray<double> CrmProb;		// for Forward_CRM_Prob
	DynamicArray<double> CrmBlockProb;	// for Forward_CRM_Prob

	// To record the best path information for the Viterbi algorithm
	DynamicArray<vCell> CrmBlockVCell;	// for Viterbi_CRM_block
	vector<vCell> NCrmVCell;			// for Viterbi_CRM
	DynamicArray<vCell> CrmVCell;		// for Viterbi_CRM
	// the Viterbi path
	vector< vCell > vPath;
	vector< vector< vCell > > vPath_CRM_block;	// for Viterbi_CRM_block

	// To record the strong TFBS positions
	vector< double > motifThrs;
	bool *** TfbsPositions;

	// Data
	vector< Sequence > sequences;
	vector< TfbsMotif > motifs;
	vector< Indel > indels;
	vector< string > seqNames;
	int seq_length;
	int num_motifs;			// 2K, excluding the background

	// Parameters
	DynamicArray<SubstModel *> motifEvolModels;
	SubstModel* NCrmBkgModel;
	double mu, nu, one_mu, one_nu;	// NCRM,CRM transition prob
	vector< double > Lambda;	// TFBS gain rate
	vector< double > Mu;		// TFBS loss rate

	int refSequence;
	
	bool mDiagnose;		// indicate will diagnose or not
	
public:
	struct motifSite
	{
		int pos;			// site start position
		int motifInd;		// index of the motif, start from 0
		char strand;		// '+' or '-'
		double LLRscore;	// log( prob(binding site) ) - log( prob(background) )

		motifSite(int _pos, int _mInd, char _strand, double _score) : pos(_pos), motifInd(_mInd), strand(_strand), LLRscore(_score) {}
		friend ostream& operator<<(ostream& out, const motifSite& s)
		{
			out << s.pos << "\t" << s.motifInd << "\t" << s.strand << "\t" << s.LLRscore;
			return out;
		}
	};

	HMM(const vector< Sequence >& seqs, const vector< TfbsMotif >& mots, const vector< Indel >& idls, const vector< string >& names, const bool _diagnose=false);
	HMM(const vector< Sequence >& seqs, const vector< TfbsMotif >& mots, const vector< Indel >& idls, const vector< string >& names, const int refSeq, const bool _diagnose=false);
	~HMM();
  
	void loadSequence(const PhyloTree& tree, const vector< Sequence >& seqs, const vector< Indel >& idls, const vector< string >& names);
	void loadSequence(const PhyloTree& tree, const vector< Sequence >& seqs, const vector< Indel >& idls, const vector< string >& names, const int refSeq);
	void Init(const PhyloTree& tree, const Param &par, const int _StateHistAprxMode, const int _StateSwitchAprxMode=3);
	
	// Given the parameters of the model, compute the probability of a particular output sequence
	// and the probabilities of the hidden state values given that output sequence.
	double Forward_CRM();
	double Forward_CRM_block(const int start=0, int end=-1);
	double Backward();

	// Discover the parameters of the HMM given a dataset of sequences.
	double Baum_Welch();

	// Given the parameters of the model, find the most likely sequence of hidden states
	// that could have generated a given output sequence.
	double Viterbi_CRM_block(const int start, const int end);
	double Viterbi_CRM();
	
	double cmptCRMBackground(const int start=0, int end=-1) const;

	void printViterbiPath(ostream &os) const;
	vector<char> getAnnotationFromVPath() const;
	vector<char> getAnnotationFromVPath(const vector< vCell >& vp, const int start, const int end) const;
	vector<char> getLLRscoreFromVPath(const vector< vCell >& vp, const int start, const int end) const;
	void printCrmAnnotation(ostream &os) const;
	void printCrmAnnotation(ostream &os, const vector<int>& crm_start, const vector<int>& crm_end) const;
	void printCrmAnnotation4Diag(ostream &os, const vector<int>& crm_start, const vector<int>& crm_end) const;
	void printCrmMotifBlockInfo4Diag(ostream &os, const vector<int>& crm_start, const vector<string>& names) const;
	void printBlockInfo4Diag(ostream &os, const int start, const int end, const int motifIndex, const vector<string>& names) const;
	double printCrmMotifBlock(ostream &os, int len, int end_pos, int k) const;

	void scanCrmByWindows(const string &filePrefix, int winLen, int sftLen);
	double cmptMaxCrmWindow(int winLen, int sftLen, char * info);
	double cmptMaxCrmSite(char * info);
	void printCrmPosition(const string &filePrefix, const vector<string> &motifNames);

	// TODO
	//double Viterbi_CRM_turnover(const int start, const int end);
	

private:
	// Extract the Viterbi path
	void getVPathOfCRM();
	void getVPathOfCRM_block(const int start, const int end);
	void getMotifBlockScoreFromVPath(double * bkgProb, const vector<vCell>& vp, const int start, const int end, vector< motifSite >& v_sites) const;

	void dumpNCrmVCells(ostream & os);
	void dumpCrmBlockVCells(ostream & os, const int start, const int end);
	void dumpCrmVCells(ostream & os);

	void Viterbi_NCRM_vCell(int n);
	void Viterbi_CRM_block_vCell(int n, int k, const int START);
	void Viterbi_CRM_vCell(int n, int k);
	void Forward_NCRM_Prob(int n);
	void Forward_CRM_Prob(int n, int k);
	void Forward_CRM_block_Prob(int n, int k, const int START);
	void Forward_CRM_block_Prob_viterbi(int n, int k, const int START);

	double compNcrmBkgCol(int n);
	double compCrmMotifBlock(int len, int end_pos, int k) const;

	int getMinNtLen(int len, int n);
	bool isMotifBlock(const int len, const int n, const int motifLen, const int k) const;
	void scanTfbsPositions();

	void scanCrmByWindows(const int wLen, const int sLen, vector<int>& v_pos, vector<double>& v_score);
	void scanCrmByWindows_ref(const int wLen, const int sLen, vector<int>& v_refPos, vector<int>& v_pos, vector<double>& v_score);
	void scanCrmByWindows(const int wLen, const int sLen, vector<int>& v_pos, vector<double>& v_score, vector< motifSite >& v_sites);
	void scanCrmByWindows_ref(const int wLen, const int sLen, vector<int>& v_refPos, vector<int>& v_pos, vector<double>& v_score, vector<int>& v_refSitePos, vector< motifSite >& v_sites);
	//void scanCrmByWindows_blockProb(int n, int k, const int wLen, const int sLen, vector<int>& window_start, vector< DynamicArray<double> >& crmWindows_BlockProb, vector<int>& v_pos, vector<double>& v_score);

	// TODO
	//double Viterbi_CRM_turnover_vCell(const int start, const int end);
};

#endif

