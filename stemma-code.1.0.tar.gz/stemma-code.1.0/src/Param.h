// Param.h: interface for the Param class.
//
//////////////////////////////////////////////////////////////////////

#ifndef PARAM_H
#define PARAM_H

#include <string>
#include <map>

#include "IO.h"

using namespace std;
using namespace myUtilities;

class Param
{
public:
	vector< double > BgPWM;	// neutral distribution
	
	double rate;	// substitution rate
	double bias;	// transition/transversion bias

	double mu, nu;	// HMM transition probs
	vector< double > Lambda;	// TFBS gain rate
	vector< double > Mu;		// TFBS loss rate
	vector< double > motifThrs;	// TFBS energy threshold		

	// access methods
	void loadParameters(const string& paramFile);
	void dumpParameters(ostream& os);
};

#endif
