// decodeCRM.cpp : Defines the entry point for the console application of decodeCRM.
//

#include "common.h"
#include "Tools.h"
#include "IO.h"
#include "Param.h"
#include "PhyloTree.h"
#include "HMM.h"

void printUsage(char * cmd);
void parseCMDLine(int argc, char* argv[]);

string refSeq="";
string SeqFile="";
string OutputFile="";
string MotifFile="";
string TreeFile="";
string IndelFile="";
string ParameterFile="";
int LinageChangeMode=2;	// 0: only background
						// 1: no gain/loss = all or none
						// 2: only one event per tree

int main(int argc, char* argv[])
{
	// command line processing
	parseCMDLine(argc, argv);
	
	// read parameter file
	Param param;
	param.loadParameters(ParameterFile);
	//cerr << "Parameters:" <<endl;
	//param.dumpParameters(cerr);
	
	// read motif file
	vector< TfbsMotif > motifs;
	vector< string > motifNames;
	IO::readMotifs( MotifFile, param.BgPWM, motifs, motifNames, WTMX);
	//cerr<< "Read in " << motifs.size() << " motifs:"<<endl;
	//for(int i=0; i<motifs.size(); i++)
	//{
	//	cerr<< ">" << motifNames[i] <<endl;
	//	motifs[i].dumpPWM(cerr);
	//}

	// read tree file
	PhyloTree phyloTree;
	phyloTree.load(TreeFile);
	//cerr<< "The phylogeny:" << endl;
	//phyloTree.Print(cerr);	

	// Prepare the log-add algorithm class for log-add computaion.
	myUtilities::LogAddAlgorithm::Init( -10.0, 0, 500 );

	// read sequence file
	vector< Sequence > sequences;
	vector< string > seqNames;
	IO::readSequences( SeqFile, sequences, seqNames );
	// read indel file
	vector< Indel > indelAnts;
	vector< string > indelSeqNames;
	IO::readIndelAnts( IndelFile, indelAnts, indelSeqNames );
	GeneralUtil::ReorderVectorByString(indelAnts, indelSeqNames, seqNames);
	// alingn tree node index with the indel sequence index
	phyloTree.indexNode(indelSeqNames);

	HMM * myHmm;
	if (refSeq.compare("")==0)
	{
		myHmm = new HMM(sequences, motifs, indelAnts, seqNames, true);
	}
	else
	{
		int i=0;
		for(; i<indelSeqNames.size(); i++)
		{
			if (indelSeqNames[i].compare(refSeq)==0)
			{
				myHmm = new HMM(sequences, motifs, indelAnts, seqNames, i, true);
				break;
			}
		}
		if (i == indelSeqNames.size())
		{
			cerr<< "Error: reference sequence name not found!"<<endl;
			exit(INPUT_ERROR);
		}
	}
	myHmm->Init(phyloTree, param, LinageChangeMode);
	
	double prob=myHmm->Viterbi_CRM_block(0, sequences[0].size()-1);
	vector<int> start;
	vector<int> end;
	start.push_back(0);
	end.push_back(sequences[0].size()-1);
	myHmm->printCrmAnnotation(cout, start, end);

//	double prob_CRM = myHmm->Forward_CRM_block();
//	double prob_background = myHmm->cmptCRMBackground();
//	cout << prob_CRM-prob_background <<endl;

	return 0;
}

void printUsage(char * cmd)
{
	cerr<<"Usage: "<<endl;
	cerr<< cmd << " <Options>"<<endl;
	cerr<< "\t-s <InputSeqFile> (required, for accepting a single file input)"<<endl;
	cerr<< "\t-m <InputMotifFile> (required, for accepting a single file input)"<<endl;
	cerr<< "\t-a <InputIndelFile> (required, for accepting a single file input)"<<endl;
	//cerr<< "\t-o <OutputFile> (required, for accepting a single file output)"<<endl;
	cerr<< "\t-t <TreeFile> (required, for accepting a single file input)"<<endl;
	cerr<< "\t-p <ParameterFile> (required, for accepting a single file input)"<<endl;
	cerr<< "\t-lcm <LinageChangeMode> (optional, for accepting an integer in {0,1,2})"<<endl;
	cerr<< "\t-r <RefSeqName> (optional, for accepting a string)"<<endl;
}

void parseCMDLine(int argc, char* argv[])
{
	int i=1;
	while(i<argc)
	{
		if (!strcmp(argv[i], "-s"))
		{
			SeqFile = argv[++i];
		}
		else if (!strcmp(argv[i], "-m"))
		{
			MotifFile = argv[++i];
		}
		else if (!strcmp(argv[i], "-a"))
		{
			IndelFile = argv[++i];
		}
		else if (!strcmp(argv[i], "-o"))
		{
			OutputFile = argv[++i];
		}
		else if (!strcmp(argv[i], "-p"))
		{
			ParameterFile = argv[++i];
		}
		else if (!strcmp(argv[i], "-t"))
		{
			TreeFile = argv[++i];
		}
		else if (!strcmp(argv[i], "-lcm"))
		{
			LinageChangeMode = atoi(argv[++i]);
		}
		else if (!strcmp(argv[i], "-r"))
		{
			refSeq = argv[++i];
		}
		else{
			cerr<<"ERROR: Unrecognizable options: "<<argv[i]<<endl;
			printUsage(argv[0]);
			exit(CMDLINE_ERROR);			
		}
		i++;
	}
	
	// check required arguments
	if(SeqFile.size() && IndelFile.size() && TreeFile.size() && MotifFile.size() && ParameterFile.size()) return;
	else {
		cerr<<"ERROR: please specify: s, m, a, p, t" << endl;
		printUsage(argv[0]);
		exit(CMDLINE_ERROR);
	}
}

