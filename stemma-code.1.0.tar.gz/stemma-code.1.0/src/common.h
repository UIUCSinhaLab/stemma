
#ifndef COMMON_H
#define COMMON_H

#include <numeric>
#include <vector>
#include <deque>
#include <map>
#include <cassert>
#include <cmath>

/*
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <list>
#include <iterator>
#include <algorithm>
#include <time.h>
#include <limits>
#include <queue>

#include <gsl/gsl_statistics.h>
#include <gsl_math.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>

*/

/*
#include <iomanip>
#include <string>
#include <set>
#include <new>
#include <float.h>
#include <utility>

#include <gsl/gsl_vector.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_math.h>

*/

#ifdef WIN32
#define for if(0);else for //for VC
#endif

using namespace std;
 
/* for debugging */
#define DEBUG_INPUT 0

/* constants */
#define CMDLINE_ERROR 1		// return error about cmd line 
#define INPUT_ERROR 2		// return error for problems with input file
#define OUTPUT_ERROR 3		// return error for problems with output file
#define FELSEN_ERROR 4		// return error for problems with Felsensteins algorithm
#define ANNOT_ERROR 5		// return error for problems with final annotation

#define MAX_LINE 5000			// max length of input line 
/*
#define MAX_DOCS 100000			// max number of documents
#define MAX_MEM 1000000
// max double value
const double MAX_DOUBLE = std::numeric_limits<double>::max();
const double MAX_LOG_DOUBLE = std::log(MAX_DOUBLE);
const double MIN_LOG_DOUBLE = std::log(MIN_DOUBLE);
const double MIN_DOUBLE = std::numeric_limits<double>::min();
*/

typedef std::vector<bool>::reference BoolRef;
typedef unsigned long int BitMapOfStates;

const double EPS = 1e-10;
const int INT_INF = numeric_limits< int >::max() / 2;
const int MAX_SEQ_LENGTH = 10000;
const int SEQ_PRINT_LINE_LENGTH = 100;
// alphabet
const char ALPHABET[] = { 'A', 'C', 'G', 'T', 'N', 'X', '-' };
const int NBASES = 4;	// number of bases
const int ALPHABET_SIZE = 7;
const int GAP = 6;		// '-'
// file formats for Sequence and motif
enum FileFormats { FASTA, PHYLIP, WTMX, FM };

#endif
