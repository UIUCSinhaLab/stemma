// Sequence.cpp: implementation of the n.t. sequence related classes.
//
//////////////////////////////////////////////////////////////////////

#include "Sequence.h"

/*****************************************************
* Indel annotation class
******************************************************/

bool Indel::containsIndel() const
{
	for ( int i = 0; i < indels.size(); i++ ) {
		if ( indels[ i ] ) return true;
	}	
	
	return false;
}

// insert an indel annotation at the end
void Indel::push_back( bool indel )
{	
	indels.push_back( indel );
}

// output the sequence
void Indel::dumpIndelAnt( ostream& os, const int length) const
{
	// output the indel annotations
	int lines = this->size()/length;
	int tail_len = this->size()%length;
	for ( int l = 0; l < lines; ++l ) {
		int start = l*length;
		int end = start+length;
		for (int i=start; i<end; ++i) {
			if ( this->indels[i] ) os << "-";
			else os << "b";
		}
		os << endl;
	}
	for (int i=this->size()-tail_len; i<this->size(); ++i) {
		if ( this->indels[i] ) os << "-";
		else os << "b";
	}
	os << endl;
}

int Indel::countNts( int len, int n ) const
{
	return (this->ntCounts[n+1] - this->ntCounts[n-len+1]);
}

void Indel::InitNtCounts()
{
	int size = this->indels.size();
	int count = 0;
	this->ntCounts.push_back(count);
	for ( int i=0; i<size; i++ )
	{
		if (! this->indels[i]) ++count;
		this->ntCounts.push_back(count);
	}
}

/*// insert an indel annotation at the begining
void Indel::push_front( bool indel )
{	
	indels.insert( indels.begin(), indel);
}*/

/*****************************************************
* DNA Sequence class
******************************************************/

Sequence::Sequence( const vector< int >& _nts ) : nts( _nts )
{
	// check the Sequence 
	for ( int i = 0; i < nts.size(); i++ ) {
		assert( nts[ i ] >= 0 && nts[ i ] < ALPHABET_SIZE );
	}	
}

bool Sequence::containsGap() const
{
	for ( int i = 0; i < nts.size(); i++ ) {
		if ( nts[ i ] == GAP ) return true;
	}	
	
	return false;
}

// information of the Sequence
void Sequence::getNtCounts( vector< int >& counts ) const
{
	counts.clear();
	for ( int i = 0; i < NBASES; i++ ) {
		counts.push_back( 0 );
	}
	
	for ( int i = 0; i < nts.size(); i++ ) {
		if ( nts[ i ] != GAP ) counts[ nts[ i ] ]++;	
	}
}

// insert a nt. at the begining of Sequence
int Sequence::push_front( int nt )
{	
	assert( nt >= 0 && nt < ALPHABET_SIZE );
	nts.insert( nts.begin(), nt);
}

// insert a nt. at the end of Sequence
int Sequence::push_back( int nt )
{	
	assert( nt >= 0 && nt < ALPHABET_SIZE );
	nts.push_back( nt );
}

// output the sequence
void Sequence::dumpSequence( ostream& os) const
{
	// output the nts
	for ( int i = 0; i < this->size(); i++ ) {
		os << ALPHABET[ this->getNt( i ) ];	
	}
}

/***************************************
* SeqElement class
****************************************/

// SeqElement constructor:
// from S[ start, start + length - 1 ] where S is a Sequence
SeqElement::SeqElement( const Sequence& seq, int start, int length )
{
	assert( start >= 0 && length >= 0 && ( start + length ) <= seq.size() );
	
	for ( int i = 0; i < length; i++ ) {
		nts.push_back( seq[ start + i ] );	
	}
}

// SeqElement: insert a nt. at the end of sequence
int SeqElement::push_back( int nt )
{
	assert( nt >= 0 && nt < ALPHABET_SIZE );
	
	nts.push_back( nt );		
}

// SeqElement: remove gaps, i.e. restore the sequence element
SeqElement SeqElement::restoreElem() const
{
	SeqElement result;
	for ( int i = 0; i < nts.size(); i++ ) {
		if ( nts[ i ] != GAP ) result.push_back( nts[ i ] );	
	}
	
	return result;
}

SeqElement SeqElement::compRevCompl() const
{
	SeqElement rcElem;
	for ( int i = nts.size() - 1; i >= 0; i-- ) {
		rcElem.push_back( myString::complement( nts[ i ] ) );	
	}
	
	return rcElem;
}

double SeqElement::comp_ll( const vector< double >& pi ) const
{
	assert( pi.size() == 4 && Stat::isPmf( pi ) );
	
	double result = 0;
	for ( int i = 0; i < nts.size(); i++ ) {
		result += log( pi[ nts[ i ] ] );
	}	
	
	return result;
}

/*****************************************************
* DNA Sequence Motifs
******************************************************/

// Motif constructor: construct PWM from the count matrix
// countMatrix in Transfac format
Motif::Motif( const Matrix& countMatrix, double pseudoCount ) : pwm( countMatrix.getRows(), NBASES )
{
	assert( countMatrix.getCols() == NBASES && pseudoCount >= 0 );
	
	int l = countMatrix.getRows();		// l: the length of motif
	
	for ( int i = 0; i < l; i++ ) {
		double count = 0;
		for ( int j = 0; j < NBASES; j++ ) {
			count += countMatrix( i, j );
		}
		// the multinomial distribution at each column
		for ( int j = 0; j < NBASES; j++ ) {
			pwm( i, j ) = ( countMatrix( i, j ) + pseudoCount ) / ( count + 4.0 * pseudoCount );
		}
	}
}

/*Motif::Motif( const Matrix& countMatrix, double pseudoCount ) : pwm( countMatrix.getRows(), NBASES )
{
	assert( countMatrix.getCols() == NBASES && pseudoCount >= 0 );
	
	int l = countMatrix.getRows();		// l: the length of motif
	
	// the sum of each position/column should be a const. (number of sequences)
	double n = 0;		// number of sites used in the count matrix
	for ( int j = 0; j < NBASES; j++ ) {
		n += countMatrix( 0, j );
	}
	for ( int i = 1; i < l; i++ ) {
		double count = 0;
		for ( int j = 0; j < NBASES; j++ ) {
			count += countMatrix( i, j );
		}
		if ( fabs(count - n) > EPS ) { cerr << "count matrix incorrect" << endl; exit( INPUT_ERROR ); }
	}
	
	// the multinomial distribution at each column
	for ( int i = 0; i < l; i++ ) {
		for ( int j = 0; j < NBASES; j++ ) {
			pwm( i, j ) = ( countMatrix( i, j ) + pseudoCount ) / ( n + 4.0 * pseudoCount );
		}	
	}
}*/

// Motif: sample a site from PWM
void Motif::sample( const gsl_rng* rng, SeqElement& elem ) const
{
	assert( rng != NULL );
	elem.clear();
	
	int l = pwm.getRows();
	for ( int i = 0; i < l; i++ ) {
		// nt. distribution at position i
		vector< double > distr = pwm.getRow( i );
		
		// sample nt. from this distribution	
		int nt = Stat::sampleMul( rng, distr );
		elem.push_back( nt );
	}		
}

// output the Motif
void Motif::dumpPWM( ostream& os)
{
	this->pwm.dumpMatrix(os);
}

/*****************************************************
* DNA TFBS Motif
* add energy computation to Motif
******************************************************/

// TfbsMotif constructor
TfbsMotif::TfbsMotif( const Matrix& _pwm, const vector< double >& _background ) : Motif( _pwm ), background( _background ), energyMat( pwm.getRows(), NBASES )
{
	assert( background.size() == NBASES );	
	
	init();
}

// TfbsMotif constructor: construct PWM from the count matrix
// countMatrix in Transfac format
TfbsMotif::TfbsMotif( const Matrix& countMatrix, double pseudoCount, const vector< double >& _background ) : Motif( countMatrix, pseudoCount ), background( _background ), energyMat( pwm.getRows(), NBASES )
{
	assert( background.size() == NBASES );
	
	init();
}

TfbsMotif TfbsMotif::compRevCompl() const
{
	// compute PWM of the rev. compl. motif
	int l = length();
	Matrix rc_pwm( l, NBASES );
	for ( int i = 0; i < l; i++ ) {
		for ( int j = 0; j < NBASES; j++ ) {
			rc_pwm( i, j)=pwm( l - 1 - i, myString::complement( j ) );
		}	
	}
	
	// construct the rev. compl. motif
	return TfbsMotif( rc_pwm, background );
}

// TfbsMotif: compute the energy (log-likelihood) of a site 
double TfbsMotif::energy( const SeqElement& elem ) const
{
	int l = pwm.getRows();
	if( elem.size() != l ) return GSL_NEGINF;
	
	double result = 0;
	for ( int i = 0; i < l; i++ ) {
		// energy at position i
		int nt = elem[ i ];
		result += energyMat( i, nt ); 	
	}
	
	return result;
}

// TfbsMotif: compute the energy (log-likelihood) of a site 
double TfbsMotif::energy( const deque<int>& elem ) const
{
	int l = pwm.getRows();
	if( elem.size() != l ) return GSL_NEGINF;
	
	double result = 0;
	for ( int i = 0; i < l; i++ ) {
		// energy at position i
		int nt = elem[ i ];
		result += energyMat( i, nt ); 	
	}
	
	return result;
}

double TfbsMotif::comp_ll( const SeqElement& elem ) const
{
	int l = pwm.getRows();
	assert( elem.size() == l );
	
	double result = 0;
	for ( int i = 0; i < l; i++ ) {
		int nt = elem[ i ];
		result += log( pwm( i, nt ) );
	}
	
	return result;
}

// TfbsMotif: sample a site whose energy is larger than a threshold
void TfbsMotif::sampleGoodSite( const gsl_rng* rng, SeqElement& elem, double thr ) const
{
	assert( rng != NULL );
	double curr_energy = GSL_NEGINF;
	
	while ( curr_energy < thr ) {
		sample( rng, elem );
		curr_energy = energy( elem );
	}
}

// TfbsMotif: initialization
void TfbsMotif::init()
{
	int l = pwm.getRows();
	
	// compute the energy matrix
	for ( int i = 0; i < l; i++ ) {
  	// nt. distribution at position i
		vector< double > distr = pwm.getRow( i );
		for ( int j = 0; j < NBASES; j++ ) {
			// energy of nt. j at position i
			energyMat( i, j ) = log( distr[ j ] / background[ j ] );
		}
	}
	
	energyComputed = true;
}

/*****************************************************
* Alignment of DNA Sequences
******************************************************/

Alignment::Alignment( const vector< Sequence >& _seqs ) : alignedSeqs( _seqs ), seqNames()
{
	// check the sequences' length
	if( this->alignedSeqs.size() == 0) {
		this->length = 0;
		return;
	}
	this->length = this->alignedSeqs[0].size(); 
	for ( int i = 1; i < this->alignedSeqs.size(); i++ ) {
		if ( this->alignedSeqs[i].size() != this->length ) {
			cerr<<"ERROR: Input sequence alignment are not with same lengths!"<<endl;
			exit(INPUT_ERROR);
		}
	}
/*	
	// check the alignment to make sure no all-GAP columns
	for(int j=0; j<this->length; j++) {
		bool notGap = false;
		for(int i=0; i<this->alignedSeqs.size(); i++) {
			if ( this->alignedSeqs[i][j] != GAP ) {
				notGap = true;
				break;
			}
		}
		if (! notGap) {
			cerr<<"ERROR: Input sequence alignment has no n.t. at position " << j <<"!"<<endl;
			exit(INPUT_ERROR);
		}
	}
*/
}

Alignment::Alignment( const vector< Sequence >& _seqs, const vector< string >& names) : alignedSeqs( _seqs ), seqNames(names)
{
	// check the sequences' length
	if( this->alignedSeqs.size() == 0) {
		this->length = 0;
		return;
	}
	this->length = this->alignedSeqs[0].size(); 
	for ( int i = 1; i < this->alignedSeqs.size(); i++ ) {
		if ( this->alignedSeqs[i].size() != this->length ) {
			cerr<<"ERROR: Input sequence alignment are not with same lengths!"<<endl;
			exit(INPUT_ERROR);
		}
	}
/*	
	// check the alignment to make sure no all-GAP columns
	for(int j=0; j<this->length; j++) {
		bool notGap = false;
		for(int i=0; i<this->alignedSeqs.size(); i++) {
			if ( this->alignedSeqs[i][j] != GAP ) {
				notGap = true;
				break;
			}
		}
		if (! notGap) {
			cerr<<"ERROR: Input sequence alignment has no n.t. at position " << j <<"!"<<endl;
			exit(INPUT_ERROR);
		}
	}
*/
}

// extract one sigle column from the alignment
void Alignment::getCol( int pos, vector<int>& col ) const
{
	assert( pos >= 0 && pos < this->length );

	col.clear();
	int numSeqs = this->alignedSeqs.size();
	for(int i=0; i<numSeqs; i++) {
		col.push_back(this->alignedSeqs[i][pos]);
	}
}

// get counts of NBASES nts in the alignment
void Alignment::getNtCounts( vector< int >& counts ) const
{
	counts.clear();
	for ( int i = 0; i < NBASES; i++ ) {
		counts.push_back( 0 );
	}
	
	for ( int i=0; i<this->alignedSeqs.size(); i++) {
		for ( int j = 0; j < this->length; j++ ) {
			int x = this->alignedSeqs[i][j];
			if( myString::isNt(x) ) counts[x]++;
		}
	}
}

// extract the original sequences
void Alignment::extractOrigSeqs( vector<Sequence>& seqs ) const
{
	int numSeqs = this->alignedSeqs.size();
	seqs.resize(numSeqs);
	for ( int i=0; i<numSeqs; i++) {
		for ( int j = 0; j < this->length; j++ ) {
			int x = this->alignedSeqs[i][j];
			if ( myString::isNtOrExtended(x) ) seqs[i].push_back(x);
		}
	}
}

// insert a column at the beginning of alignment
void Alignment::push_front( const vector<int>& col )
{
	bool notGap = false;
	for(int i=0; i<col.size(); i++) {
		assert( myString::inAlphabet(col[i]) );
		if( myString::isNtOrExtended(col[i]) ) notGap=true;
	}
	assert(notGap);

	for(int i=0; i<this->alignedSeqs.size(); i++) {
		this->alignedSeqs[i].push_front( col[i] );
	}
	this->length ++;
}

// insert a column at the end of alignment
void Alignment::push_back( const vector<int>& col )
{
	bool notGap = false;
	for(int i=0; i<col.size(); i++) {
		assert( myString::inAlphabet(col[i]) );
		if( myString::isNtOrExtended(col[i]) ) notGap=true;
	}
	assert(notGap);

	for(int i=0; i<this->alignedSeqs.size(); i++) {
		this->alignedSeqs[i].push_back( col[i] );
	}
	this->length ++;
}

// Alignment: append another alignment at the front
int Alignment::append_front( const Alignment& other )
{
	vector<int> col;
	for ( int i = other.size() - 1; i >= 0; --i ) {
		other.getCol(i, col);
		this->push_front( col );	
	}

	return other.size();
}

// append another alignment at the back
int Alignment::append_back( const Alignment& other )
{
	vector<int> col;
	for ( int i = 0; i < other.size(); ++i ) {
		other.getCol(i, col);
		this->push_back( col );				
	}

	return other.size();
}

// Alignment: output operator
void Alignment::dumpAlignedSeqs( ostream& os )
{
	int nSegments = (int) ceil( (float) this->length / SEQ_PRINT_LINE_LENGTH );
	for ( int n=0; n<nSegments; n++) {
		for ( int i = 0; i < this->alignedSeqs.size(); i++ ) {
			int start = n * SEQ_PRINT_LINE_LENGTH;
			int end = min( (start + SEQ_PRINT_LINE_LENGTH), this->length );
			for ( int j = start; j < end; j++ ) {
				os << ALPHABET[ this->alignedSeqs[i][j] ];
			}
			os << endl;
		}
		os << endl;
	}
}

// print alignment block
void Alignment::printLine( ostream& os, int pos, vector<int>& ntPos, int lineHead, int lineMax) const
{
	int end = min( (pos + lineMax), this->length );
	for (int i=0; i<this->alignedSeqs.size(); ++i)
	{
		if (lineHead >0)
		{
			string name = this->seqNames[i].substr(0, lineHead);
			if (lineHead > name.length()) name.append(lineHead-name.length(), ' ');
			os << name;
		}
		int ntCount = 0;
		for (int n=pos; n<end; ++n) {
			os << ALPHABET[ this->alignedSeqs[i][n] ];
			if (this->alignedSeqs[i][n] != GAP) ++ntCount;
		}
		ntPos[i] += ntCount;

		os << "  " << ntPos[i]<<endl;
	}
}

/*
// Alignment: load Alignment from a file
int Alignment::load( const string& file, vector< string >& names, int format )
{
	// read the two sequences
	vector< Sequence > seqs;
	int rval = IO::readSequences( file, seqs, names, format );
	if ( rval == INPUT_ERROR ) return INPUT_ERROR;

	// construct the alignment
	this->alignedSeqs.clear();
	this->alignedSeqs = seqs;

	// check the sequences' length
	if( this->alignedSeqs.size() == 0) {
		this->length = 0;
		return 0;
	}
	this->length = this->alignedSeqs[0].size(); 
	for ( int i = 1; i < this->alignedSeqs.size(); i++ ) {
		if ( this->alignedSeqs[i].size() != this->length ) {
			cerr<<"ERROR: Input sequence alignment are not with same lengths!"<<endl;
			exit(INPUT_ERROR);
		}
	}
	
	// check the alignment to make sure no all-GAP columns
	for(int j=0; j<this->length; j++) {
		bool notGap = false;
		for(int i=0; i<this->alignedSeqs.size(); i++) {
			if ( this->alignedSeqs[i][j] != GAP ) {
				notGap = true;
				break;
			}
		}
		if (! notGap) {
			cerr<<"ERROR: Input sequence alignment has no n.t. at position " << j <<"!"<<endl;
			exit(INPUT_ERROR);
		}
	}
	
	return 0;
}

// Alignment: load Alignment from a file
int Alignment::load( const string& file, int format )
{
	vector< string > names;
	int rval = load( file, names, format );
	
	return rval;
}
*/

/*****************************************************
* CrmAnnotation of Aligned DNA Sequences
* Based on the Annotation by HMM
******************************************************/

void CrmAnnotator::print( ostream& os, const int lineMax ) const
{
	// find the max length of sequence names
	int nameLen = 0;
	for (int i=0; i<this->seqNames.size(); ++i)
		if (nameLen < this->seqNames[i].length()) nameLen = this->seqNames[i].length();
	nameLen += 4;
	string str = "";
	str.append(nameLen,' ');
	
	int pos = 0;
	int len = 0;
	vector<char>::const_iterator antIt = this->antStr.begin();
	vector<int> ntPos(this->seqNames.size(), 0);
	while ( pos < this->antStr.size() ) {
		// print the annotation
		len = min( (pos + lineMax), (int)this->antStr.size() ) - pos;
		os << str;
		copy(antIt+pos, antIt+len+pos, ostream_iterator<char>(os, ""));
		os << "  "<<pos+len<<endl;
		// print the alignment
		this->alignment.printLine(os, pos, ntPos, nameLen, len);
		os << endl;
		pos += len;
	}
}

void CrmAnnotator::print4Diag( ostream& os, const vector<char>& llrStr, const int lineMax ) const
{
	// find the max length of sequence names
	int nameLen = 3;	// for "LLR"
	for (int i=0; i<this->seqNames.size(); ++i)
		if (nameLen < this->seqNames[i].length()) nameLen = this->seqNames[i].length();
	nameLen += 4;
	string str = "";
	str.append(nameLen,' ');
	
	int pos = 0;
	int len = 0;
	vector<char>::const_iterator llrIt = llrStr.begin();
	vector<char>::const_iterator antIt = this->antStr.begin();
	vector<int> ntPos(this->seqNames.size(), 0);
	while ( pos < this->antStr.size() ) {
		// print the annotation
		len = min( (pos + lineMax), (int)this->antStr.size() ) - pos;
		os << "LLR    ";
		copy(llrIt+pos, llrIt+len+pos, ostream_iterator<char>(os, ""));
		os << endl;
		os << str;
		copy(antIt+pos, antIt+len+pos, ostream_iterator<char>(os, ""));
		os << "  "<<pos+len<<endl;
		// print the alignment
		this->alignment.printLine(os, pos, ntPos, nameLen, len);
		os << endl;
		pos += len;
	}
}
