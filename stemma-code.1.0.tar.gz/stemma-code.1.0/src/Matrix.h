// Matrix.h: interface for the Matrix class.
//
//////////////////////////////////////////////////////////////////////

#ifndef MATRIX_H
#define MATRIX_H

#include <vector>
#include <iostream>
#include <fstream>
#include <cassert>

#include <gsl/gsl_vector.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_linalg.h>

using namespace std;

class Matrix {
private:
	gsl_matrix* data;	// data

	/* functions for gsl_vector */
	static vector< double > gsl2vector( const gsl_vector* v );
public:
	// constructors
	Matrix() : data( NULL ) {}
	Matrix( int nRows, int nCols );
	Matrix( const gsl_matrix* _data );
	Matrix( const double **_data, int nRows, int nCols );
	Matrix( const vector< double * >& _data, int nCols);
	void copy( const Matrix& other ) 
	{
		setDimensions( other.getRows(), other.getCols() ); 
		gsl_matrix_memcpy( data, other.data );
	}
	Matrix( const Matrix& other ) { data=NULL; copy( other ); }

	// destructor
	~Matrix();
	
	// assignment
	Matrix& operator=( const Matrix& other ) { copy(other); return *this; }
			
	// access methods
	int getRows() const { if(data) return data->size1; else return 0; }
	int getCols() const { if(data) return data->size2; else return 0; }
	double getElement( int row, int col ) const { return gsl_matrix_get( data, row, col ); } 
	void setElement( int row, int col, double v ) { gsl_matrix_set( data, row, col, v ); }
	const double& operator()( int row, int col) const {
		assert( row >= 0 && row < data->size1  && col >= 0 && col < data->size2 );
		return *gsl_matrix_ptr( data, row, col );		
	}
	double& operator()( int row, int col ) {
		assert( row >= 0 && row < data->size1  && col >= 0 && col < data->size2 );
		return *gsl_matrix_ptr( data, row, col );
	}
	gsl_matrix* getData() const { return data; }
	void setDimensions( int nRows, int nCols);
	vector< double > getRow( int row ) const;
	vector< double > getCol( int col ) const;

	// information
	bool operator==( const Matrix& other ) const;
	bool isSquare() const;
	
	// set matrix elements
	void setZero() { gsl_matrix_set_zero( data ); }
	void setElements( double v ) { gsl_matrix_set_all( data, v ); }
	void setRow( int row, const vector< double >& v );
	void setCol( int col, const vector< double >& v );
	void setRows( const vector< double >& v );
	void setCols( const vector< double >& v );
	
	// set special matrices 
	void setIdentityMatrix( int n );		// identity matrix of dimension n 
	void setDiagonalMatrix( const vector< double >& diag );	// diagonal matrix

	// transpose
	Matrix transpose() const; 
	
	// addition
	Matrix operator+( const Matrix& other ) const;
	Matrix& operator+=( const Matrix& other );
	
	// multiplication of a constant
	Matrix operator*( const double c ) const;
	Matrix& operator*=( const double c ); 
	
	// matrix multiplication
	Matrix operator*( const Matrix& other ) const;	
 	
	// load Matrix from a file
	// If readDims = true, read dimensions (first row of the file);
	// o/w, only read data, assuming the correct dimensions are known
	int load( const string& fileName, bool readDims = false );
	
	// save Matrix to a file
	void save( const string& fileName ) const;

	// output Matrix
	void dumpMatrix( ostream& os ) const;
	friend ostream& operator<<(ostream& os, const Matrix& matrix);
};

#endif
