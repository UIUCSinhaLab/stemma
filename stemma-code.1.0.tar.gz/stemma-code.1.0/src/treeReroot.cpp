// treeExtractor.cpp : Defines the entry point for the console application of treeExtractor.
//

#include "common.h"
#include "Tools.h"
#include "PhyloTree.h"

void printUsage(char * cmd);
void parseCMDLine(int argc, char* argv[]);

string TreeFile="";
string newRoot="";

int main(int argc, char* argv[])
{
	// command line processing
	parseCMDLine(argc, argv);
	
	// read tree file
	PhyloTree phyloTree;
	phyloTree.load(TreeFile);
	
	PhyloTree newTree;
	phyloTree.reroot(newRoot, newTree);
	newTree.Print(cout);

	return 0;
}

void printUsage(char * cmd)
{
	cerr<<"Usage: "<<endl;
	cerr<< cmd << " <Options>"<<endl;
	cerr<< "\t-tree <TreeFile> (required, for accepting a single file input)"<<endl;
	cerr<< "\t-node <noteToReroot> (required, for accepting a string of node names)"<<endl;
}

void parseCMDLine(int argc, char* argv[])
{
	int i=1;
	while(i<argc)
	{
		if (!strcmp(argv[i], "-tree"))
		{
			TreeFile = argv[++i];
		}
		else if (!strcmp(argv[i], "-node"))
		{
			newRoot = argv[++i];
		}
		else{
			cerr<<"ERROR: Unrecognizable options: "<<argv[i]<<endl;
			printUsage(argv[0]);
			exit(CMDLINE_ERROR);
		}
		i++;
	}
	
	// check required arguments
	if(TreeFile.size() && newRoot.size()) return;
	else {
		cerr<<"ERROR: please specify: -tree and -node" << endl;
		printUsage(argv[0]);
		exit(CMDLINE_ERROR);
	}
}
