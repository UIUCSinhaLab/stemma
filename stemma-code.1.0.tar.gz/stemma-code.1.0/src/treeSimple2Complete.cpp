// treeExtractor.cpp : Defines the entry point for the console application of treeExtractor.
//

#include "common.h"
#include "Tools.h"
#include "PhyloTree.h"

void printUsage(char * cmd);
void parseCMDLine(int argc, char* argv[]);

string TreeFile="";

int main(int argc, char* argv[])
{
	// command line processing
	parseCMDLine(argc, argv);
	
	// read tree file
	PhyloTree phyloTree;
	phyloTree.load(TreeFile);
	phyloTree.Print_full(cout);

	return 0;
}

void printUsage(char * cmd)
{
	cerr<<"Usage: "<<endl;
	cerr<< cmd << " <Options>"<<endl;
	cerr<< "\t-tree <TreeFile> (required, for accepting a single file input)"<<endl;
}

void parseCMDLine(int argc, char* argv[])
{
	int i=1;
	while(i<argc)
	{
		if (!strcmp(argv[i], "-tree"))
		{
			TreeFile = argv[++i];
		}
		else{
			cerr<<"ERROR: Unrecognizable options: "<<argv[i]<<endl;
			printUsage(argv[0]);
			exit(CMDLINE_ERROR);
		}
		i++;
	}
	
	// check required arguments
	if(TreeFile.size()) return;
	else {
		cerr<<"ERROR: please specify: -tree" << endl;
		printUsage(argv[0]);
		exit(CMDLINE_ERROR);
	}
}
