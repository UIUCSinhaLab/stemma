// Felsenstein.h: interface for the Felsenstein algorithm class.
//
//////////////////////////////////////////////////////////////////////

#ifndef FELSENSTEIN_H
#define FELSENSTEIN_H

#include "PhyloTree.h"
#include "Sequence.h"
#include "EvolModels.h"

/*****************************************************
* DynamicArray class
******************************************************/

template <typename T>
class DynamicArray
{
public:
	// constructors
	DynamicArray(){};
	DynamicArray(int rows, int cols)
	{
		for(int i=0; i<rows; ++i)
		{
			data_.push_back(std::vector<T>(cols));
		}
	}
	~DynamicArray() { clear(); };
	
	// accessors
	inline std::vector<T> & operator[](int i) { return data_[i]; }
	inline const std::vector<T> & operator[] (int i) const { return data_[i]; }
	void resize(int rows, int cols)
    {
		data_.clear();
		data_.resize(rows);
		for(int i = 0; i < rows; ++i)
			data_[i].resize(cols);
	}
	void resize(int rows, int cols, const T &element)
    {
		data_.clear();
		data_.resize(rows);
		for(int i = 0; i < rows; ++i)
			data_[i].resize(cols, element);
	}
	void clear()
	{
		for(int i = 0; i < data_.size(); ++i)
			data_[i].clear();
		data_.clear();
	}
	int rows() const { return data_.size(); }
	int cols() const
	{
		if (data_.size()) return data_[0].size();
		else return 0;
	}

	friend ostream& operator<<(ostream& os, const DynamicArray& da)
	{
		for (int i=0; i<da.data_.size(); i++)
		{
			for (int j=0; j<da.data_[i].size(); j++)
			{
				os << da.data_[i][j];
			}
			os << endl;
		}
		return os;
	}
	
	void dump(ostream & os) const
	{
		for (int i=0; i<data_.size(); i++)
		{
			for (int j=0; j<data_[i].size(); j++)
			{
				os << data_[i][j];
			}
			os << endl;
		}
	}

	void dump(ostream & os, const int start, const int end) const
	{
		for (int i=0; i<data_.size(); i++)
		{
			assert( end<data_[i].size() );
			for (int j=start; j<=end; j++)
			{
				os << data_[i][j];
			}
			os << endl;
		}
	}

private:
	std::vector< std::vector<T> > data_;
};

/*****************************************************
* Felsenstein class
*****************************************************/

class Felsenstein
{
private:
	struct DataBranchCell
	{
		double branchLen;
		int seqIndex;	// index of the indel sequences
		vector< int > childrenIndex;	// index of the children
		int parentIndex;	// index of the parent;
		
		DataBranchCell()
		{
			branchLen = 0.0;
			seqIndex = -1;
			childrenIndex.clear();
			parentIndex=-1;
		}
		~DataBranchCell()
		{
			childrenIndex.clear();
		}
		DataBranchCell(const double blen, const int seqInd, const int indelInd, const vector<int> &children)
			: branchLen(blen), seqIndex(seqInd), childrenIndex(children) {};
		friend ostream& operator<<(ostream& os, const DataBranchCell& c)
		{
			os << "( " << c.branchLen << ", " << c.seqIndex << ", " << c.parentIndex << ", <";
			for (int i=0; i<c.childrenIndex.size(); ++i)
				os << " " << c.childrenIndex[i];
			os << " > )" <<endl;
			return os;
		}
	};
	
	struct ParBranchCell
	{
		DynamicArray< Matrix > CrmSubstProbMatrix;		// matrix of pre-computed crm substitution prob
		DynamicArray< Matrix > CrmSubstProbMatrix_mid;	// matrix of pre-computed crm substitution prob with half branch length
		Matrix NcrmSubstProbMatrix;	// matrix of pre-computed ncrm substitution prob
		double o2oSubstProb;	// 1 - \lambda_o t_ab

		ParBranchCell()
		{
			CrmSubstProbMatrix.clear();
			CrmSubstProbMatrix_mid.clear();
			o2oSubstProb = 0.0;
		}
		~ParBranchCell()
		{
			CrmSubstProbMatrix.clear();
			CrmSubstProbMatrix_mid.clear();
		}
		friend ostream& operator<<(ostream& os, const ParBranchCell& c)
		{
			os << "(" <<endl;
			os << c.CrmSubstProbMatrix;
			os << c.CrmSubstProbMatrix_mid;
			os << c.NcrmSubstProbMatrix;
			os << c.o2oSubstProb << endl;
			os << ")" << endl;
			return os;
		}
	};
	
	// settings for approximate computing block prob
	const int StateSwitchAprxMode;	// 2: turnover at middle of the branch
									// 3: turnover at the begining of the branch
	const int StateHistAprxMode;	// 0: only background
									// 1: no gain/loss = all or none
									// 2: only one event per tree + one approximate history
									// 3: only the approximate history

	// data and parameters
	vector< Indel > indels;
	vector< Sequence > sequences;
	const vector< double > lambda;
	const vector< double > mu;
	vector< double > omega;
	vector< int > motifLen;
	
	// for branch related computation
	int mNumOfNodes;
	DataBranchCell * mBranchData;
	ParBranchCell * mBranchParam;
	vector< vector < double *** > > mConservedBranchProb;	// cache the conserved branches prob for all motifs
	vector< vector < double *** > > mGainBranchProb;	// cache the TFBS gain branches prob for all motifs
	vector< vector < double *** > > mLossBranchProb;	// cache the TFBS loss branches prob for all motifs
	
	// for compute state history prob
	vector< BitMapOfStates > StateHists;	// each element is a possible state history
	vector< BitMapOfStates > BranchStates;	// each element is a state history of a branch ended with the corresponding node
											// 0=no turnover; 1=turnover
	DynamicArray< double > cacheStateHistProb;	// each element is part of the state history prob to cache
	DynamicArray< double > BranchValidCols;	// each element is the valid column value of each branch at a certain pos
	
	enum BranchType { o2o=0, o2k=1, k2o=2, k2k=3 };

	bool *** TfbsPositions;	//k(motif index), i(seqIndex), n(column position)

	double (Felsenstein::*cmptCrmBlockProbFuncPtr)(const int len, const int n, const int k) const;
	double (Felsenstein::*printCrmBlockProbFuncPtr)(ostream &os, const int len, const int n, const int k) const;

public:
	// Construction/Destruction
	Felsenstein(const PhyloTree &pt, const vector< Indel > &idls, const vector< TfbsMotif > &mots, const vector< Sequence > &seqs
		, const DynamicArray<SubstModel*> &motifModels, SubstModel* ncrmModel
		, const vector< double > &Lambda, const vector< double > &Mu
		, const int stateHistMode=2, const int stateSwitchMode=3); 
	Felsenstein(bool *** tfbsPos, const PhyloTree &pt, const vector< Indel > &idls, const vector< TfbsMotif > &mots, const vector< Sequence > &seqs
		, const DynamicArray<SubstModel*> &motifModels, SubstModel* ncrmModel
		, const vector< double > &Lambda, const vector< double > &Mu
		, const int stateHistMode=2, const int stateSwitchMode=3); 
	~Felsenstein();

	void loadSequence(const PhyloTree &pt, const vector< Indel > &idls, const vector< Sequence > &seqs);
	void loadSequence(bool *** tfbsPos, const PhyloTree &pt, const vector< Indel > &idls, const vector< Sequence > &seqs);
	void dumpStateHists(ostream &os) const;
	double cmptNcrmColProb(const int n) const;
	void getStateHistNodeIndex(vector< int > &seqIndex) const;
	double cmptCrmBlockProb(const int len, const int n, const int k) const;
	double printCrmBlockProb(ostream &os, const int len, const int n, const int k) const;
	
private:
	void cmptCrmBranchProb_conserved();
	void cmptCrmBranchProb_turnover();
	double** cmptConservedBranchProb(const int k, const int motifCol, const int cInd) const;
	double cmptConservedBranchProb(const int k, const int motifCol, const int headNT, const int tailNT, const int cInd) const;
	double** cmptTurnoverBranchProb_2(const int k, const int motifCol, const int cInd, const int tailState) const;
	double cmptTurnoverBranchProb_2(const int k, const int motifCol, const int headNT, const int tailNT, const int cInd, const int tailState) const;
	double** cmptTurnoverBranchProb_3(const int k, const int motifCol, const int cInd, const int tailState) const;
	double cmptTurnoverBranchProb_3(const int k, const int motifCol, const int headNT, const int tailNT, const int cInd, const int tailState) const;
	
	void cmptStateHists_1();
	void cmptStateHists_2();
	void cmptStateHists_3();
	void updateBranchCells_seqIndex(const PhyloTree &pt);
	void recUpdtBranchCell(int &index, const PhyloTree::Node *root);
	void InitBranchCells(const double lambda_o, const PhyloTree &pt, const DynamicArray< SubstModel* >& motifModels, SubstModel* ncrmModel);
	void recInitBranchCell(const double lambda_o, int &index, const PhyloTree::Node *root, const DynamicArray<SubstModel *> &motifModels, SubstModel* ncrmModel);
	void cmptOmega();
	void cmptPartOfStateHistProb();
	void cmptPartOfStateHistProb_2();
	void cmptPartOfStateHistProb_3();
	void cmptValidBranchCols();
	bool isMotifState(const int nodeInd, const int histInd) const;
	void dumpStateHist(ostream &os, BitMapOfStates value) const;
	double cmptStateHistProb_2(const int len, const int n, const int stInd, const int k) const;
	double cmptStateHistProb_3(const int len, const int n, const int stInd, const int k) const;
	bool isValidStateHist(const int len, const int n, BitMapOfStates stateHist, const int k) const;
	double cmptCrmBlockProbGivenSH(const int len, const int n, BitMapOfStates stateHist, BitMapOfStates branchState, const int k, int ** motifColInd) const;
	double cmptCrmBlockProbGivenSH_2(const int len, const int n, BitMapOfStates stateHist, BitMapOfStates branchState, const int k, int ** motifColInd) const;
	double cmptCrmBlockProbGivenSH_3(const int len, const int n, BitMapOfStates stateHist, BitMapOfStates branchState, const int k, int ** motifColInd) const;
	double cmptCrmColProbGivenSH_Bkg(const int n) const;
	double cmptCrmColProbGivenSH_Motif(const int n, BitMapOfStates stateHist, BitMapOfStates branchState, const int k, int * motifColInd) const;
	double cmptCrmColProbGivenSH_2(const int n, BitMapOfStates stateHist, BitMapOfStates branchState, const int k, int * motifColInd) const;
	double cmptCrmColProbGivenSH_3(const int n, BitMapOfStates stateHist, BitMapOfStates branchState, const int k, int * motifColInd) const;
	BitMapOfStates TfbsAnt2ValidStateHist(const int len, const int n, const int k) const;
	BitMapOfStates StateHist2BranchState(BitMapOfStates st) const;
	double cmptFullStateHistProb_2(const int len, const int n, BitMapOfStates stateHist, const int k) const;
	double cmptFullStateHistProb_3(const int len, const int n, BitMapOfStates stateHist, const int k) const;
	double cmptCrmBlockProb_3(const int len, const int n, const int k) const;
	double cmptCrmBlockProb_2(const int len, const int n, const int k) const;
	double printCrmBlockProb_3(ostream &os, const int len, const int n, const int k) const;
	double printCrmBlockProb_2(ostream &os, const int len, const int n, const int k) const;

};

#endif

