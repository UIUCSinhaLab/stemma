// treeExtractor.cpp : Defines the entry point for the console application of treeExtractor.
//

#include "common.h"
#include "Tools.h"
#include "PhyloTree.h"

void printUsage(char * cmd);
void parseCMDLine(int argc, char* argv[]);

string TreeFile="";
string subtreeNodes="";

int main(int argc, char* argv[])
{
	// command line processing
	parseCMDLine(argc, argv);
	
	// read tree file
	PhyloTree phyloTree;
	phyloTree.load(TreeFile);

	// read the subtree nodes
	vector< string > nodeNames;
	myString::split( nodeNames, subtreeNodes, " " );

	// extract the subtree with the target nodes
	PhyloTree newTree;
	phyloTree.subTree(nodeNames, newTree);
	newTree.Print(cout);

	return 0;
}

void printUsage(char * cmd)
{
	cerr<<"Usage: "<<endl;
	cerr<< cmd << " <Options>"<<endl;
	cerr<< "\t-tree <TreeFile> (required, for accepting a single file input)"<<endl;
	cerr<< "\t-nodes <\"a b c\"> (required, for accepting a string (in double quote) of node names, seperated by spaces)"<<endl;
}

void parseCMDLine(int argc, char* argv[])
{
	int i=1;
	while(i<argc)
	{
		if (!strcmp(argv[i], "-tree"))
		{
			TreeFile = argv[++i];
		}
		else if (!strcmp(argv[i], "-nodes"))
		{
			subtreeNodes = argv[++i];
		}
		else{
			cerr<<"ERROR: Unrecognizable options: "<<argv[i]<<endl;
			printUsage(argv[0]);
			exit(CMDLINE_ERROR);
		}
		i++;
	}
	
	// check required arguments
	if(TreeFile.size() && subtreeNodes.size()) return;
	else {
		cerr<<"ERROR: please specify: -tree, -nodes" << endl;
		printUsage(argv[0]);
		exit(CMDLINE_ERROR);
	}
}
