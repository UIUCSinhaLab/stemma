// IO.h: interface for the IO class.
//
//////////////////////////////////////////////////////////////////////

#ifndef IO_H
#define IO_H

#include <iostream>
#include <fstream>
#include <map>

#include <gsl/gsl_vector.h>
#include <gsl/gsl_matrix.h>

#include "common.h"
#include "Sequence.h"
#include "Tools.h"

using namespace std;
using namespace myUtilities;

class IO {
public:
	IO(){}
	~IO(){}

	// control the output format
	static string vector_delimiter;
	static string map_delimiter;	
	static string field_separator;

	// read parameter file into a <field, value> table. Return 0 if successful, -1 otherwise
	// Format: field = value [# ...] where # indicates the start of comments (ignored)
	// Ex. kappa = 2.0 # kappa: the transition/transversion bias
	static void readParams( const string& file, map< string, string >& params, const char* comment = "#" );

	// print matrix
	template< class T >
	static void printMatrix( ostream& os, T** &x, int m, int n )
	{	
		for ( int i = 0; i < m; i++ ) {
			for ( int j = 0; j < n; j++ ) {
				os << x[ i ][ j ] << " ";	
			}	
			os << endl;
		}	
	}

	// read the table of strings from a file
	static void readTable( const string& file, vector< vector< string > >& table, const char* comment = "#" );
	
	
	// read indel annotations from a file
	static int readIndelAnts( const string& file, vector< Indel >& indelAnts, vector< string >& names, int format = FASTA );
	static int readIndelAnts( const string& file, vector< Indel >& indelAnts, int format = FASTA );

	// write indel annotations to a file
	static void writeIndelAnts( const string& file, const vector< Indel >& indelAnts, const vector< string >& names, int format = FASTA );
	static void writeIndelAnts( const string& file, const vector< Indel >& indelAnts, int format = FASTA );
	
	// read sequences from a file
	static int readSequences( const string& file, vector< Sequence >& seqs, vector< string >& names, int format = FASTA );
	static int readSequences( const string& file, vector< Sequence >& seqs, int format = FASTA );

	// write sequences to a file
	static void writeSequences( const string& file, const vector< Sequence >& seqs, const vector< string >& names, int format = FASTA );
	static void writeSequences( const string& file, const vector< Sequence >& seqs, int format = FASTA );
	static void writeAlignment( const string& file, const Alignment& align, const vector< string >& names, int format = FASTA );  
	static void writeAlignment( const string& file, const Alignment& align, int format = FASTA );

	// read the motifs (PWMs) in a FASTA-like format:
	// pseudocounts within the file
	static int readMotifs( const string& file, vector< Motif >& motifs, vector< string >& names, int format = FM);
	static int readMotifs( const string& file, vector< Motif >& motifs, int format = FM );
	static int readMotifs( const string& file, const vector< double >& background, vector< TfbsMotif >& motifs, vector< string >& names, int format = FM );
	static int readMotifs( const string& file, const vector< double >& background, vector< TfbsMotif >& motifs, int format = FM );
private:
	static int readFmMotifs( const string& file, vector< Motif >& motifs, vector< string >& names );
	static int readWtmxMotifs( const string& file, vector< Motif >& motifs, vector< string >& names );

};	

/*
// output vector< T >
template< class T >
ostream& operator<<( ostream& os, const vector< T >& v );

// output map< T1, T2 >
template< class T1, class T2 >
ostream& operator<<( ostream& os, const map< T1, T2 >& table );
*/

#endif
