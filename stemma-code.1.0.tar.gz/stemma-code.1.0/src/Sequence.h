// Sequence.h: interface for the n.t sequence related classes.
//
//////////////////////////////////////////////////////////////////////

#ifndef SEQUENCE_H
#define SEQUENCE_H

#include <math.h>
#include <algorithm>

#include "common.h"
#include "Tools.h"

using namespace std;
using namespace myUtilities;

/*****************************************************
* Indel annotation class
******************************************************/

class Indel {
private:
	vector< bool > indels;	// indels[i]: the i-th position indel annotation
	vector< int > ntCounts;	// ntCounts[i]: number of n.t. till the i-th position 

public:
	// constructors
	Indel() : indels() {}
	Indel( const vector< bool >& _indels ) : indels(_indels) {}
	void copy( const Indel & other ) { indels = other.indels; ntCounts = other.ntCounts; }
	Indel ( const Indel& other ) { copy( other ); }

	~Indel(){ this->indels.clear(); this->ntCounts.clear(); }

	// assignment
	Indel& operator=( const Indel& other ) { copy( other ); return *this; }

	// access methods
	int size() const { return indels.size(); }
	bool getIndelAnt( int pos ) const {
		assert( pos >=0 && pos < size() );
		return indels[ pos ];
	}
	const bool operator[]( int pos ) const {
		assert( pos >= 0 && pos < size() );
		return indels[ pos ];	
	}
	const vector< bool >& getIndelAnts() const { return indels; }
	const int getNtCounts(int n) const { return ntCounts[n+1]; }

	// check if contain gap/indel
	bool containsIndel() const;
	
	// clear the sequence
	void clear() { this->indels.clear(); this->ntCounts.clear(); }

	// output the sequence
	void dumpIndelAnt( ostream& os, const int length = SEQ_PRINT_LINE_LENGTH) const;

	// count the number of nts of the "len"-column subsequence ended at "n"
	int countNts( int len, int n ) const;

	// compute the ntCounts vector
	void InitNtCounts();

	// insert an indel annotation at the end
	void push_back( bool indel );	

	/* Be careful when using these method, coz ntCounts need to be updated accordingly
	void setIndelAnt( int pos, bool indel) { 
		assert( pos >= 0 && pos < size() );
		indels[ pos ] = indel; 
	}
	BoolRef operator[]( int pos ) {
		assert( pos >= 0 && pos < size() );
		return this->indels[ pos ];	
	}
	// insert an indel annotation at the begining
	void push_front( bool indel );
	
	*/	


};


/*****************************************************
* DNA Sequence class
******************************************************/

class Sequence {

protected:
	vector< int > nts;		// nts[ i ]: the i-th nt.
public:
	// constructors
	Sequence() : nts() {}
	Sequence( const vector< int >& _nts );
	virtual void copy( const Sequence& other ) { nts = other.nts; }
	Sequence( const Sequence& other ) { copy( other ); }
	
	~Sequence(){ this->nts.clear(); }
	
	// assignment
	Sequence& operator=( const Sequence& other ) { copy( other ); return *this; }

	// access methods
	int size() const { return nts.size(); }
	int getNt( int pos ) const { 
		assert( pos >= 0 && pos < size() );
		return nts[ pos ]; 
	}
	void setNt( int pos, int nt ) { 
		assert( pos >= 0 && pos < size() && myString::isNtOrExtended( nt ) );
		nts[ pos ] = nt; 
	}
	const int& operator[]( int pos ) const {
		assert( pos >= 0 && pos < size() );
		return nts[ pos ];	
	}
	int& operator[]( int pos ) {
		assert( pos >= 0 && pos < size() );
		return nts[ pos ];	
	}
	const vector< int >& getNts() const { return nts; }
	
	// check if a BaseSequence contains gap
	bool containsGap() const;
	
	// information of the sequence
	void getNtCounts( vector< int >& counts ) const;
	
	// insert a nt. at the begining of Sequence
	virtual int push_front( int nt );
	
	// insert a nt. at the end of sequence
	virtual int push_back( int nt );	
	
	// clear the sequence
	void clear() { nts.clear(); }

	// output the sequence
	void dumpSequence( ostream& os) const;
};

/***************************************
* SeqElement class
****************************************/

class SeqElement : public Sequence {
public:
	// constructor
	SeqElement() : Sequence() {}
	SeqElement( const vector< int >& _nts ) : Sequence( _nts ) {}
	SeqElement( const Sequence& seq, int start, int length );
	void copy( const SeqElement& other ) { nts = other.nts; }
	SeqElement( const SeqElement& other ) { copy( other ); }

	// assignment
	SeqElement& operator=( const SeqElement& other ) { copy( other ); return *this; }
	
	// equality test
	bool operator==( const SeqElement& other ) const { return nts == other.nts; }
			
	// insert a nt. at the end of sequence
	int push_back( int nt );

	// remove gaps, i.e. restore the sequence element
	SeqElement restoreElem() const; 

	// reverse complement of a sequence element
	SeqElement compRevCompl() const;
		
	// compute the log-likelihood of generating this sequence element with some distribution
	double comp_ll( const vector< double >& pi ) const;
	
};

/*****************************************************
* DNA Sequence Motifs
******************************************************/

/* Motif class: position-specific multinomial distributions */
class Motif {
protected:
	Matrix pwm;	// the position weight matrix
public:	
	// constructors
	Motif() : pwm() {}
	Motif( int _length ) : pwm( _length, NBASES ) { assert( _length > 0 ); }
	Motif( const Matrix& _pwm ) : pwm( _pwm ) { assert( pwm.getCols() == NBASES ); }
	Motif( const Matrix& countMatrix, double pseudoCount );	// countMatrix in Transfac format
	void copy( const Motif& other ) { pwm = other.pwm; }
	Motif( const Motif& other ) { copy( other ); }
	
	// assignment
	Motif& operator=( const Motif& other ) { copy( other ); return *this; }
	
	// access methods
	int length() const { return pwm.getRows(); }
	const Matrix& getPwm() const { return pwm; } 
	
	// sample a site from PWM
	void sample( const gsl_rng* rng, SeqElement& elem ) const;
		
	// output
	void dumpPWM( ostream& os);
};

/*****************************************************
* DNA TFBS Motif
* add energy computation to Motif
******************************************************/

class TfbsMotif : public Motif {
	// background distribution
	vector< double > background;
	
	// energy matrix, defined as: E(i,a) = energy of nt. a at position i
	Matrix energyMat;
public:
	// constructors
	TfbsMotif() : Motif(), energyComputed( false ) {}
	TfbsMotif( int _length ) : Motif( _length ), energyMat( _length, 4 ), energyComputed( false ) {}	
	TfbsMotif( const Matrix& _pwm, const vector< double >& _background ); 
	TfbsMotif( const Matrix& countMatrix, double pseudoCount, const vector< double >& _background );		// countMatrix in Transfac format
	void copy( const TfbsMotif& other ) { pwm = other.pwm; background = other.background; energyMat = other.energyMat; }
	TfbsMotif( const TfbsMotif& other ) { copy( other ); }

	// assignment
	TfbsMotif& operator=( const TfbsMotif& other ) { copy( other ); return *this; }
	
	// access methods
	const vector< double >& getBackground() const { return background; }
	const Matrix& getEnergyMat() const { return energyMat; }
	
	// the reverse complement of this motif
	TfbsMotif compRevCompl() const;

	// compute the energy (log-likelihood ratio) of a site 
	double energy( const SeqElement& elem ) const;
	double energy( const deque<int>& elem ) const;
	
	// compute the log-likelihood of generating a site 
	double comp_ll( const SeqElement& elem ) const;
	
	// sample a site whose energy is larger than a threshold
	void sampleGoodSite( const gsl_rng* rng, SeqElement& elem, double thr ) const;
	
private:
	bool energyComputed;	// whether energy matrix has been computed
	void init();	
};

/*****************************************************
* Alignment of DNA Sequences
******************************************************/

/* Alignment class */
class Alignment {
	vector< Sequence > alignedSeqs;
	vector< string > seqNames;
	int length;
public:
	// constructors
	Alignment() : alignedSeqs(), length(0), seqNames() {}
	Alignment( const vector< Sequence >& _seqs );
	Alignment( const vector< Sequence >& _seqs, const vector< string >& names);
	
	~Alignment() { this->alignedSeqs.clear(); this->seqNames.clear(); }
	
	/****** access methods *******/

	int size() const { return this->length; }
	
	// extract one sigle column from the alignment
	void getCol( int pos, vector<int>& col ) const;
	
	// get counts of NBASES nts in the alignment
	void getNtCounts( vector< int >& counts ) const;
	
	// extract the original sequences
	void extractOrigSeqs( vector<Sequence>& seqs ) const;
	
	// insert a column to the alignment
	void push_front( const vector<int>& col ); 	// at the beginning 
	void push_back( const vector<int>& col ); 	// at the end 
	
	// append another alignment
	int append_front( const Alignment& other );
	int append_back( const Alignment& other );
	
	// clear the alignment
	void clear() { alignedSeqs.clear(); length=0; }
	
	// output operator
	void dumpAlignedSeqs( ostream& os );

	// print alignment block
	void printLine( ostream& os, int pos, vector<int>& ntPos, int lineHead=0, int lineMax=SEQ_PRINT_LINE_LENGTH) const;
	
	/*
	// load Alignment from a file
	int load( const string& file, vector< string >& names, int format = FASTA );
	int load( const string& file, int format = FASTA );
	*/

	// print Alignment
	//void print( const string& file, const vector< string >& names, int format = FASTA ) const;
};

/*****************************************************
* CrmAnnotation of Aligned DNA Sequences
* Based on the Annotation by HMM
******************************************************/

class CrmAnnotator {
	Alignment alignment;
	const vector<char>& antStr;
	const vector<string>& seqNames;
public:
	// constructor
	CrmAnnotator( const vector<Sequence>& _seqs, const vector<char>& _antStr, const vector< string >& names ) : alignment(Alignment(_seqs, names)), antStr( _antStr ), seqNames( names )
	{
		assert( this->antStr.size() == this->alignment.size() );
	}
	
	// print the annotated alignment
	void print( ostream& os, const int lineMax = SEQ_PRINT_LINE_LENGTH ) const;
	void print4Diag( ostream& os, const vector<char>& llrStr, const int lineMax = SEQ_PRINT_LINE_LENGTH ) const;
};

#endif
