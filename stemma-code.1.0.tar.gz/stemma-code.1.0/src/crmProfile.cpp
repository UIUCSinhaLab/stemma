// crmProfile.cpp : Defines the entry point for the console application of crmscan.
//

#include "common.h"
#include "Tools.h"
#include "IO.h"
#include "Param.h"
#include "PhyloTree.h"
#include "HMM.h"

void printUsage(char * cmd);
void parseCMDLine(int argc, char* argv[]);

int winLen=500;
int sftLen=50;
string outFilePrefix="";
string refSeq="";
string SeqPathFile="";
string SeqFile="";
string MotifFile="";
string TreeFile="";
string IndelFile="";
string ParameterFile="";
int LinageChangeMode=2;	// 0: only background
						// 1: no gain/loss = all or none
						// 2: only one event per tree + one approximate history
						// 3: only the approximate history
int SwitchTimeMode=3;	// 2: t'= t/2
						// 3: t'= 0

int main(int argc, char* argv[])
{
	// command line processing
	parseCMDLine(argc, argv);
	
	// read parameter file
	Param param;
	param.loadParameters(ParameterFile);
	//cerr << "Parameters:" <<endl;
	//param.dumpParameters(cerr);
	
	// read motif file
	vector< TfbsMotif > motifs;
	vector< string > motifNames;
	IO::readMotifs( MotifFile, param.BgPWM, motifs, motifNames, WTMX);
	//cerr<< "Read in " << motifs.size() << " motifs:"<<endl;
	//for(int i=0; i<motifs.size(); i++)
	//{
	//	cerr<< ">" << motifNames[i] <<endl;
	//	motifs[i].dumpPWM(cerr);
	//}

	// read tree file
	PhyloTree phyloTree;
	phyloTree.load(TreeFile);
	//cerr<< "The phylogeny:" << endl;
	//phyloTree.Print(cerr);	

	// Prepare the log-add algorithm class for log-add computaion.
	myUtilities::LogAddAlgorithm::Init( -10.0, 0, 500 );

	if (SeqFile.size() && IndelFile.size())	// scan single file
	{
		// read sequence file
		vector< Sequence > sequences;
		vector< string > seqNames;
		IO::readSequences( SeqFile, sequences, seqNames );
		// read indel file
		vector< Indel > indelAnts;
		vector< string > indelSeqNames;
		IO::readIndelAnts( IndelFile, indelAnts, indelSeqNames );
		GeneralUtil::ReorderVectorByString(indelAnts, indelSeqNames, seqNames);
		// alingn tree node index with the indel sequence index
		phyloTree.indexNode(indelSeqNames);

		HMM * myHmm;
		if (refSeq.compare("")==0)
		{
			myHmm = new HMM(sequences, motifs, indelAnts, seqNames);
		}
		else
		{
			int i=0;
			for(; i<indelSeqNames.size(); i++)
			{
				if (indelSeqNames[i].compare(refSeq)==0)
				{
					myHmm = new HMM(sequences, motifs, indelAnts, seqNames, i);
					break;
				}
			}
			if (i == indelSeqNames.size())
			{
				cerr<< "Error: reference sequence name not found!"<<endl;
				exit(INPUT_ERROR);
			}
		}
		myHmm->Init(phyloTree, param, LinageChangeMode, SwitchTimeMode);
		myHmm->scanCrmByWindows(outFilePrefix, winLen, sftLen);
	}
	else if (SeqPathFile.size())	// scan multiple files with the same parameter setting
	{
		HMM * myHmm = NULL;
		vector< vector< string > > filePaths;
		IO::readTable(SeqPathFile, filePaths);
		
		if (refSeq.compare("")==0)
		{
			for(int i=0; i<filePaths.size(); ++i)
			{
				if(filePaths[i].size() == 4)
				{
					// read sequence file
					vector< Sequence > sequences;
					vector< string > seqNames;
					IO::readSequences( filePaths[i][1], sequences, seqNames );
					// read indel file
					vector< Indel > indelAnts;
					vector< string > indelSeqNames;
					IO::readIndelAnts( filePaths[i][2], indelAnts, indelSeqNames );
					GeneralUtil::ReorderVectorByString(indelAnts, indelSeqNames, seqNames);
					
					if (TreeFile.compare(filePaths[i][3]) == 0)
					{
						// alingn tree node index with the indel sequence index
						phyloTree.indexNode(indelSeqNames);

						if(! myHmm)
						{
							myHmm = new HMM(sequences, motifs, indelAnts, seqNames);
							myHmm->Init(phyloTree, param, LinageChangeMode, SwitchTimeMode);
						}
						else
						{
							myHmm->loadSequence(phyloTree, sequences, indelAnts, seqNames);
						}
						myHmm->scanCrmByWindows(string(outFilePrefix).append("/").append(filePaths[i][0]), winLen, sftLen);
					}
					else
					{
						// read tree file
						PhyloTree tmp_phyloTree;
						tmp_phyloTree.load(filePaths[i][3]);
						// alingn tree node index with the indel sequence index
						tmp_phyloTree.indexNode(indelSeqNames);

						HMM * tmpHmm = new HMM(sequences, motifs, indelAnts, seqNames);
						tmpHmm->Init(tmp_phyloTree, param, LinageChangeMode, SwitchTimeMode);
						tmpHmm->scanCrmByWindows(string(outFilePrefix).append("/").append(filePaths[i][0]), winLen, sftLen);
						delete tmpHmm;
					}
					sequences.clear();
					seqNames.clear();
					indelAnts.clear();
					indelSeqNames.clear();
				}
				else
				{
					cout << endl;
					cerr << "Wrong path information for: " << filePaths[i][0] << ", at line: \"";
					copy(filePaths[i].begin(), filePaths[i].end(), ostream_iterator<string>(cerr, "\t"));
					cerr << "\""<<endl;
				}
			}
		}
		else
		{
			for(int i=0; i<filePaths.size(); ++i)
			{
				if(filePaths[i].size() == 4)
				{
					// read sequence file
					vector< Sequence > sequences;
					vector< string > seqNames;
					IO::readSequences( filePaths[i][1], sequences, seqNames );
					// read indel file
					vector< Indel > indelAnts;
					vector< string > indelSeqNames;
					IO::readIndelAnts( filePaths[i][2], indelAnts, indelSeqNames );
					GeneralUtil::ReorderVectorByString(indelAnts, indelSeqNames, seqNames);
					
					int ref=0;
					for(; ref<indelSeqNames.size(); ref++)
					{
						if (indelSeqNames[ref].compare(refSeq)==0)
						{
							break;
						}
					}
					if (ref == indelSeqNames.size())
					{
						cerr<< "Error: reference sequence name not found!"<<endl;
						exit(INPUT_ERROR);
					}					

					if (TreeFile.compare(filePaths[i][3]) == 0)
					{
						// alingn tree node index with the indel sequence index
						phyloTree.indexNode(indelSeqNames);
						if(! myHmm)
						{
							myHmm = new HMM(sequences, motifs, indelAnts, seqNames, ref);
							myHmm->Init(phyloTree, param, LinageChangeMode, SwitchTimeMode);
						}
						else
						{
							myHmm->loadSequence(phyloTree, sequences, indelAnts, seqNames, ref);
						}
						myHmm->scanCrmByWindows(string(outFilePrefix).append("/").append(filePaths[i][0]), winLen, sftLen);
					}
					else
					{
						// read tree file
						PhyloTree tmp_phyloTree;
						tmp_phyloTree.load(filePaths[i][3]);
						// alingn tree node index with the indel sequence index
						tmp_phyloTree.indexNode(indelSeqNames);

						HMM * tmpHmm = new HMM(sequences, motifs, indelAnts, seqNames, ref);
						tmpHmm->Init(tmp_phyloTree, param, LinageChangeMode, SwitchTimeMode);
						tmpHmm->scanCrmByWindows(string(outFilePrefix).append("/").append(filePaths[i][0]), winLen, sftLen);
						delete tmpHmm;
					}
					sequences.clear();
					seqNames.clear();
					indelAnts.clear();
					indelSeqNames.clear();
				}
				else
				{
					cout << endl;
					cerr << "Wrong path information for: " << filePaths[i][0] << ", at line: \"";
					copy(filePaths[i].begin(), filePaths[i].end(), ostream_iterator<string>(cerr, "\t"));
					cerr << "\""<<endl;
				}
			}
		}

	}

	return 0;
}

void printUsage(char * cmd)
{
	cerr<<"Usage: "<<endl;
	cerr<< cmd << " <Options>"<<endl;
	cerr<< "\t-s <InputSeqFile> (required, for accepting a single file input)"<<endl;
	cerr<< "\t\tor -path <file of the path to InputSeqFile and InputIndelFile>"<<endl;
	cerr<< "\t-m <InputMotifFile> (required, for accepting a single file input)"<<endl;
	cerr<< "\t-a <InputIndelFile> (required, for accepting a single file input)"<<endl;
	cerr<< "\t-o <outFilePrefix> (required, for accepting output file prefix)"<<endl;
	cerr<< "\t-t <TreeFile> (required, for accepting a single file input)"<<endl;
	cerr<< "\t-p <ParameterFile> (required, for accepting a single file input)"<<endl;
	cerr<< "\t-lcm <LinageChangeMode> (optional, 0=background only; 1=fully conserved; 2=one event approximation; 3=only one approximate history})"<<endl;
	cerr<< "\t-stm <SwitchTimeMode> (optional, 2: t'=t/1; 3: t'=0)"<<endl;
	cerr<< "\t-r <RefSeqName> (optional, for accepting a string)"<<endl;
	cerr<< "\t-win <windowLength> (optional, 500, by default)"<<endl;
	cerr<< "\t-sft <shiftLength> (optional, 50, by default)"<<endl;
}

void parseCMDLine(int argc, char* argv[])
{
	int i=1;
	while(i<argc)
	{
		if (!strcmp(argv[i], "-s"))
		{
			SeqFile = argv[++i];
		}
		else if (!strcmp(argv[i], "-m"))
		{
			MotifFile = argv[++i];
		}
		else if (!strcmp(argv[i], "-a"))
		{
			IndelFile = argv[++i];
		}
		else if (!strcmp(argv[i], "-o"))
		{
			outFilePrefix = argv[++i];
		}
		else if (!strcmp(argv[i], "-p"))
		{
			ParameterFile = argv[++i];
		}
		else if (!strcmp(argv[i], "-t"))
		{
			TreeFile = argv[++i];
		}
		else if (!strcmp(argv[i], "-lcm"))
		{
			LinageChangeMode = atoi(argv[++i]);
		}
		else if (!strcmp(argv[i], "-stm"))
		{
			SwitchTimeMode = atoi(argv[++i]);
		}
		else if (!strcmp(argv[i], "-path"))
		{
			SeqPathFile = argv[++i];
		}
		else if (!strcmp(argv[i], "-r"))
		{
			refSeq = argv[++i];
		}
		else if (!strcmp(argv[i], "-win"))
		{
			winLen = atoi(argv[++i]);
		}
		else if (!strcmp(argv[i], "-sft"))
		{
			sftLen = atoi(argv[++i]);
		}
		else{
			cerr<<"ERROR: Unrecognizable options: "<<argv[i]<<endl;
			printUsage(argv[0]);
			exit(CMDLINE_ERROR);			
		}
		i++;
	}
	
	// check required arguments
	if((SeqFile.size() && IndelFile.size() || SeqPathFile.size()) && outFilePrefix.size() && TreeFile.size() && MotifFile.size() && ParameterFile.size()) return;
	else {
		cerr<<"ERROR: please specify: (s, a)/path, o, m, p, t" << endl;
		printUsage(argv[0]);
		exit(CMDLINE_ERROR);
	}
}

