// phylohmm.cpp : Defines the entry point for the console application phylohmm.
//

#include "common.h"
#include "Tools.h"
#include "IO.h"
#include "Param.h"
#include "PhyloTree.h"
#include "HMM.h"

void printUsage(char * cmd);
void parseCMDLine(int argc, char* argv[]);

string SeqFile="";
string OutputFile="";
string MotifFile="";
string TreeFile="";
string IndelFile="";
string ParameterFile="";
int LinageChangeMode=2;

int main(int argc, char* argv[])
{
	// command line processing
	parseCMDLine(argc, argv);
	
	// read parameter file
	Param param;
	param.loadParameters(ParameterFile);
	cerr << "Parameters:" <<endl;
	param.dumpParameters(cerr);
	
	// read sequence file
	vector< Sequence > sequences;
	vector< string > seqNames;
	IO::readSequences( SeqFile, sequences, seqNames );
	cerr<< "Read in " << seqNames.size() << " sequences:"<<endl;
	//for(int i=0; i<seqNames.size(); i++)
	//{
	//	cerr<< ">" << seqNames[i] <<endl;
	//	sequences[i].dumpSequence(cerr); cerr<< endl;
	//}
		
	// read motif file
	vector< TfbsMotif > motifs;
	vector< string > motifNames;
	IO::readMotifs( MotifFile, param.BgPWM, motifs, motifNames, WTMX);
	cerr<< "Read in " << motifs.size() << " motifs:"<<endl;
	//for(int i=0; i<motifs.size(); i++)
	//{
	//	cerr<< ">" << motifNames[i] <<endl;
	//	motifs[i].dumpPWM(cerr);
	//}

	// read indel file
	vector< Indel > indelAnts;
	vector< string > indelSeqNames;
	IO::readIndelAnts( IndelFile, indelAnts, indelSeqNames );
	cerr<< "Read in " << indelSeqNames.size() << " indel sequences:"<<endl;
	GeneralUtil::ReorderVectorByString(indelAnts, indelSeqNames, seqNames);
	//for(int i=0; i<indelSeqNames.size(); i++)
	//{
	//	cerr<< ">" << indelSeqNames[i] <<endl;
	//	indelAnts[i].dumpIndelAnt(cerr);
	//}

	// read tree file
	PhyloTree phyloTree;
	phyloTree.load(TreeFile);
	phyloTree.indexNode(indelSeqNames);
	cerr<< "The phylogeny:" << endl;
	phyloTree.Print(cerr);	

	// Prepare the log-add algorithm class for log-add computaion.
	myUtilities::LogAddAlgorithm::Init( -10.0, 0, 500 );
	
	//Felsenstein felsen(phyloTree);
	//felsen.compStateHists();
	//felsen.dumpStateHists(cerr);
	HMM * myHmm = new HMM(sequences, motifs, indelAnts, seqNames);
	myHmm->Init(phyloTree, param, LinageChangeMode);
	//double prob = myHmm->Viterbi_CRM();
//cerr<<"prob="<<prob<<endl;
	
	int _start[] = {1213, 3518, 5240};
	int _end[] = {1495, 3974, 5754};
	vector<int> crm_start( _start, _start+sizeof(_start)/sizeof(int) );
	vector<int> crm_end( _end, _end+sizeof(_end)/sizeof(int) );
	for(int i=0; i<crm_start.size(); i++)
	{
		myHmm->Viterbi_CRM_block(crm_start[i], crm_end[i]);
	}
	//myHmm->printViterbiPath(cerr);
	myHmm->printCrmAnnotation(cout, crm_start, crm_end);

	cerr<<"Done!"<<endl;
	return 0;
}

void printUsage(char * cmd)
{
	cerr<<"Usage: "<<endl;
	cerr<< cmd << " <Options>"<<endl;
	cerr<< "\t-s <InputSeqFile> (required, for accepting a single file input)"<<endl;
	cerr<< "\t-m <InputMotifFile> (required, for accepting a single file input)"<<endl;
	cerr<< "\t-a <InputIndelFile> (required, for accepting a single file input)"<<endl;
	cerr<< "\t-o <OutputFile> (required, for accepting a single file output)"<<endl;
	cerr<< "\t-t <TreeFile> (required, for accepting a single file input)"<<endl;
	cerr<< "\t-p <ParameterFile> (required, for accepting a single file input)"<<endl;
	cerr<< "\t-lcm <LinageChangeMode> (optional, for accepting an integer in {1,4})"<<endl;
}

void parseCMDLine(int argc, char* argv[])
{
	int i=1;
	while(i<argc)
	{
		if (!strcmp(argv[i], "-s"))
		{
			SeqFile = argv[++i];
		}
		else if (!strcmp(argv[i], "-m"))
		{
			MotifFile = argv[++i];
		}
		else if (!strcmp(argv[i], "-a"))
		{
			IndelFile = argv[++i];
		}
		else if (!strcmp(argv[i], "-o"))
		{
			OutputFile = argv[++i];
		}
		else if (!strcmp(argv[i], "-p"))
		{
			ParameterFile = argv[++i];
		}
		else if (!strcmp(argv[i], "-t"))
		{
			TreeFile = argv[++i];
		}
		else if (!strcmp(argv[i], "-lcm"))
		{
			LinageChangeMode = atoi(argv[++i]);
		}
		else{
			cerr<<"ERROR: Unrecognizable options: "<<argv[i]<<endl;
			printUsage(argv[0]);
			exit(CMDLINE_ERROR);			
		}
		i++;
	}
	
	// check required arguments
	if(SeqFile.size() && TreeFile.size() && OutputFile.size() && MotifFile.size() && IndelFile.size() && ParameterFile.size()) return;
	else {
		cerr<<"ERROR: please specify: s, m, a, p, o, t" << endl;
		printUsage(argv[0]);
		exit(CMDLINE_ERROR);
	}
}

