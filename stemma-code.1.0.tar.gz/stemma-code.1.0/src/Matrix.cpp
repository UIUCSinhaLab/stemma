// Matrix.cpp: implementation of the Matrix class.
//
//////////////////////////////////////////////////////////////////////

#include "Matrix.h"

// create a vector from gsl_vector
vector< double > Matrix::gsl2vector( const gsl_vector* v )
{
	vector< double > result;
	for ( int i = 0; i < v->size; i++ ) result.push_back( gsl_vector_get( v, i ) );
	return result;	
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

// Matrix constructor
Matrix::Matrix( int nRows, int nCols ) 
{
	data = NULL;
	setDimensions( nRows, nCols );
}

Matrix::Matrix( const gsl_matrix* _data )
{
	data = NULL;
	setDimensions( _data->size1, _data->size2 ); 
	gsl_matrix_memcpy( data, _data );
}

Matrix::Matrix( const double ** _data, int nRows, int nCols )
{
	data = NULL;
	setDimensions( nRows, nCols );
	for ( int i = 0; i < nRows; ++i ) {
		for ( int j = 0; j < nCols; ++j ) {
			gsl_matrix_set( data, i, j, _data[ i ][ j ] ); 	
		}	
	}
}

Matrix::Matrix( const vector< double * >& _data, int nCols)
{
	data = NULL;
	setDimensions( _data.size(), nCols );
	for(int i = 0; i < _data.size(); ++i ) {
		for ( int j = 0; j < nCols; ++j ) {
			gsl_matrix_set( data, i, j, _data[i][j] );
		}
	}
}


// Matrix destructor
Matrix::~Matrix()
{
  if ( data ) gsl_matrix_free( data );
  data = NULL;
}

//////////////////////////////////////////////////////////////////////
// Access Functions
//////////////////////////////////////////////////////////////////////

// get the row vector
vector< double > Matrix::getRow( int row ) const
{
	gsl_vector* v = gsl_vector_alloc( getCols() );
	gsl_matrix_get_row( v, data, row );
	return gsl2vector( v );
}

// get the column vector
vector< double > Matrix::getCol( int col ) const
{
	gsl_vector* v = gsl_vector_alloc( getRows() );
	gsl_matrix_get_col( v, data, col );
	return gsl2vector( v );	
}

// set the matrix dimensions
void Matrix::setDimensions( int nRows, int nCols)
{
	assert( nRows > 0 && nCols > 0 );
	//if ( data && ( getRows() != nRows || getCols() != nCols ) ) gsl_matrix_free( data );
	if ( data )	gsl_matrix_free( data );
	data = gsl_matrix_alloc( nRows, nCols );
}

// equality test
bool Matrix::operator==( const Matrix& other ) const
{
	// compare dimensions
	if ( getRows() != other.getRows() || getCols() != other.getCols() )
		return false;
	
	// compare elements
	for ( int i = 0; i < getRows(); i++ ) {
		for ( int j = 0; j < getCols(); j++ ) {
			if ( getElement( i, j ) != other.getElement( i, j ) ) return false;	
		}	
	}
	
	return true;
}

// check if square
bool Matrix::isSquare() const
{
	if ( getRows() == getCols() ) 
		return true;
	else 
		return false;	
}

// Matrix: set row
void Matrix::setRow( int row, const vector< double >& v )
{
	assert( row >= 0 && row < data->size1 );
	
	for ( int j = 0; j < data->size2; j++ ) 
		setElement( row, j, v[ j ] );	
}

// Matrix: set column
void Matrix::setCol( int col, const vector< double >& v )
{
	assert( col >= 0 && col < data->size2 );
	
	for ( int i = 0; i < data->size1; i++ ) 
		setElement( i, col, v[ i ] );	
		
}

// Matrix: set all rows
void Matrix::setRows( const vector< double >& v )
{
	for ( int i = 0; i < data->size1; i++ )
		setRow( i, v );	
}

// Matrix: set all columns
void Matrix::setCols( const vector< double >& v )
{
	for ( int j = 0; j < data->size2; j++ ) 
		setCol( j, v );	
}

// set the identity matrix of dimension n
void Matrix::setIdentityMatrix( int n )		
{
	assert( n > 0 );
	setDimensions( n, n );	
	setZero();
	for ( int i = 0; i < n; i++ ) setElement( i, i, 1.0 );
}

// set the diagonal matrix
void Matrix::setDiagonalMatrix( const vector< double >& diag )
{
	int n = diag.size();
	
	assert( n > 0 );
	setDimensions( n, n );
	setZero();
	for ( int i = 0; i < n; i++ ) setElement( i, i, diag[ i ] );
}

// Matrix transpose
Matrix Matrix::transpose() const
{
	Matrix result( getCols(), getRows() );
	
	for ( int i = 0; i < getRows(); i++ ) {
		for ( int j = 0; j < getCols(); j++ ) {
			result( j, i ) = getElement( i, j );
		}
	}
	return( result );
}

// matrix addition
Matrix Matrix::operator+( const Matrix& other ) const
{
	// check dimensions
	assert( getRows() == other.getRows() && getCols() == other.getCols() );
	
	// addition
	Matrix result( *this );
	gsl_matrix_add( result.data, other.data );	

	return result;
}

// matrix addition
Matrix& Matrix::operator+=( const Matrix& other )
{
	// check dimensions
	assert( getRows() == other.getRows() && getCols() == other.getCols() );

	// addition
	gsl_matrix_add( data, other.data );
	
	return ( *this );
}

// matrix multiplication by a constant
Matrix Matrix::operator*( const double c ) const
{
	Matrix result( *this );
	gsl_matrix_scale( result.data, c );

	return result;
}	

// matrix multiplication by a constant
Matrix& Matrix::operator*=( const double c )
{
	gsl_matrix_scale( data, c );
	
	return ( *this );	
}

// matrix multiplication
Matrix Matrix::operator*( const Matrix& other ) const
{
	// check dimensions
	assert( getCols() == other.getRows() );
	
	// matrix multiplication
	Matrix result( getRows(), other.getCols() );
	gsl_linalg_matmult( data, other.data, result.data );
	
	return result;
}

// load Matrix from a file
// If readDims = true, read dimensions (first row of the file);
// o/w, only read data, assuming the correct dimensions are known
int Matrix::load( const string& fileName, bool readDims )
{
	// open the file
	ifstream fin( fileName.c_str() );
	if ( !fin ){ cerr << "Cannot open " << fileName << endl;	exit( 1 ); } 
	
	// read the matrix dimensions
	int nRows, nColumns;
	if ( readDims ) {
		fin >> nRows >> nColumns;
		assert( nRows > 0 && nColumns > 0 );
		setDimensions( nRows, nColumns );		
	} else {
		nRows = data->size1;
		nColumns = data->size2;
	}

	// read the matrix 
	for ( int i = 0; i < nRows; i++ ) {
		for ( int j = 0; j < nColumns; j++ ) {
			double elem;
			fin >> elem;
			gsl_matrix_set( data, i, j, elem );
		}
	}
	
	return 0;
}

// save Matrix to a file
void Matrix::save( const string& fileName ) const
{
	// open the file
	ofstream fout( fileName.c_str(), ofstream::out | ofstream::app );
	
	// write the matrix
	dumpMatrix(fout);
}

// output the Matrix
void Matrix::dumpMatrix( ostream& os) const
{
	os.setf( ios::fixed );
	
	for ( int i = 0; i < this->getRows(); i++ ) {
		for ( int j = 0; j < this->getCols(); j++ ) {
			os << this->getElement(i,j);
			if ( j != this->getCols() - 1 ) os << " ";
		}
		os << endl;
	}
}

ostream& operator<<(ostream& os, const Matrix& matrix)
{
	os.setf( ios::fixed );
	
	for ( int i = 0; i < matrix.getRows(); i++ ) {
		for ( int j = 0; j < matrix.getCols(); j++ ) {
			os << matrix.getElement(i,j);
			if ( j != matrix.getCols() - 1 ) os << " ";
		}
		os << endl;
	}
	return os;
}
