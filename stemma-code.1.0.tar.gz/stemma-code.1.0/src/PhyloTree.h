// PhyloTree.h: interface for the PhyloTree class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _PHYLOTREE_H_
#define _PHYLOTREE_H_

#include <iostream>
#include <vector>
#include <string>

#include "common.h"
#include "Tools.h"

using namespace std;
using namespace myUtilities;

class PhyloTree {
public:
	class Node {
		string name;
		string inName;	// nodes without names are named by "Internal#"
		int seqInd;			// -1: undefined
	    double t_branch;	// branch length from the parent node to this node
	public:
		vector<Node *> children;
		Node * parent;

		Node() : name(""), seqInd(-1), t_branch(0.0), children(), inName("") {}
		Node(Node *);
		~Node();
		void Print(FILE *fp) const;
		void Print(ostream &os) const;
		void Print_internal(ostream &os) const;
		string getName() const { return name; }
		string getInternalName() const { return inName; }
		int getSeqInd() const { return seqInd; }
		double getBranchLength() const { return t_branch; }
		void setName( const string& str ) { this->name=str; }
		void setInternalName( const string& str ) { this->inName=str; }
		void setBranchLength( double t ) { this->t_branch = t; }
		void setSeqInd( const int i ) { this->seqInd = i; }
		void indexNode( const vector< string > &seqNames, bool * findLeaf);
		Node *recCopy();
	};

public:
	PhyloTree() : root(NULL), numNodes(0), lineid(0), count(0) {}
	~PhyloTree() { if(this->root) delete this->root; root=NULL; }
	Node* getRoot() const { return this->root; }
	void setRoot(Node* n) { if(this->root) delete this->root; this->root=n; }
	void adjustNumOfNodes(const int i) { this->numNodes+=i; }
	void adjustNumOfNodes();
	void Print(FILE *fp) const;
	void Print(ostream &os) const;
	void Print_full(ostream &os) const;
	void load(const string& filename);
	void indexNode( const vector< string > &seqNames );
	int getNumNodes() const { return this->numNodes;}
	void subTree(const vector<string> &seqNames, PhyloTree &subTree) const;
	void reroot(string nodeName, PhyloTree &newTree) const;

private:
	Node *root;
	int numNodes;

	int lineid;
	int count;
	Node *ReadPhyloTreeHelper(FILE *fp, int depth);
	void get_comment(FILE *f);
	void ReadPhyloTree(FILE *fp);
	Node *findNodeByName(const string& name) const;
};

#endif
