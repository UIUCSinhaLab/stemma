/***************************
* The library of general tools
***************************/

#include "Tools.h"

namespace myUtilities
{

	/***********************
	* Log_add algorithm
	***********************/

	double LogAddAlgorithm::delta;
	vector<double> LogAddAlgorithm::T;
	vector<double> LogAddAlgorithm::x_array;

	// initialize the log_add_table : compute the table used for log_add algorithm
	void LogAddAlgorithm::Init( double a, double b, int N )
	{
		x_array.reserve( N + 1 );
		T.reserve( N + 1 );

		delta = ( b - a ) / N;
		x_array[ 0 ] = a;
		T[ 0 ] = log( 1 + exp( a ) );
		for ( int i = 1; i < N; i++ ) {
			double x = x_array[ i - 1 ] + delta;
			x_array[ i ] = x;
			T[ i ] = log( 1 + exp( x ) );	
		}
		x_array[ N ] = b; 
		T[ N ] = log( 1 + exp( b ) );
	}

	// log_add algorithm
	double LogAddAlgorithm::log_add( double p, double q )
	{
		// check if p or q is -inf
		if ( gsl_isinf( p ) == -1 ) return q;
		if ( gsl_isinf( q ) == -1 ) return p;
		
		// log_add
		int N = x_array.size();
		double x, val;
		if ( p > q ) {
			x = q - p; val = p;
		}
		else {
			x = p - q; val = q;
		}
		if ( x < x_array[ 0 ] ) {
			val += 0;
		} else {
			int k = (int)floor( ( x - x_array[ 0 ] ) / delta );
			val += T[ k ];
			//if ( k == N ) 
			//	val += T[ N ];
			//else 
			//	val += T[ k ] + ( x - x_array[ k ] ) * ( T[ k + 1 ] - T[ k ] ) / delta;	
		}	
		
		return val;
	}

	// log_add algorithm
	double LogAddAlgorithm::log_add( const double * p, int size )
	{
		double result = p[ 0 ];
		
		for ( int i = 1; i < size; i++ ) {
			if ( gsl_isinf( p[ i ] ) == -1 ) continue;
			result = log_add( result, p[ i ] );	
		}	
		
		return result;
	}

	// log_add algorithm
	double LogAddAlgorithm::log_add( double p, double q, double r )
	{
		double result;
		result = log_add( p, q );
		result = log_add( result, r );
		
		return result;	
	}

	/****************************************************
	* Mathematics Miscellaneous 
	*****************************************************/

	// log. of a matrix
	Matrix Math::matrixLog( const Matrix& M )
	{
		int m = M.getRows(), n = M.getCols();
		
		Matrix result( m, n );	
		for ( int i = 0; i < m; i++ ) {
			for ( int j = 0; j < n; j++ ) {
				result( i, j ) = log( M.getElement( i, j ) );
			}
		}
			
		return result;
	}

	// median of a vector
	double Math::median( const vector< double > &x )
	{
		if ( x.size() == 0 ) { return 0; }
		
		vector< double > xCopy( x );
		sort( xCopy.begin(), xCopy.end() );
		int middle = (int)( ( xCopy.size() - 1 ) / 2.0 );
		return xCopy[ middle ];	
	}

	// maximum of a set of numbers
	double Math::max( const vector< double >& v, int &arg )
	{
		double v_max = GSL_NEGINF;
		for ( int i = 0; i < v.size(); ++i ) {
			if ( v[ i ] > v_max ) {
				arg = i;
				v_max = v[ i ];	
			}	
		}
		
		return v_max;
	}

	// minimun of a set of numbers
	double Math::min( const vector< double >& v, int &arg )
	{
		double v_min = GSL_POSINF;
		for ( int i = 0; i < v.size(); ++i ) {
			if ( v[ i ] < v_min ) {
				arg = i;
				v_min = v[ i ];	
			}	
		}
		
		return v_min;
	}

	// the threshold value at a given percentage in a vector of numbers
	// if highest is true, then the value at the highest p; otherwise, the value at the lowest p
	double Math::elementAt( const vector< double >& v, double p, bool highest )
	{
		assert( p >= 0 && p <= 1 );
		
		// create a copy of data because we don't want to modify the original data
		vector< double > vCopy( v );

		// get the threshold
		sort( vCopy.begin(), vCopy.end() );
		int index;
		if ( highest == true ) {
			index = (int)ceil( vCopy.size() * ( 1 - p ) ) - 1;
		} else {
			index = (int)floor( vCopy.size() * p ) - 1;
		}
		if ( index < 0 ) index = 0;
		
		return vCopy[ index ];		
	}

	double Math::trunc( double x )
	{
		double lower = floor( x );
		double upper = ceil( x );
		if ( lower == upper ) return lower;
		
		if ( x - lower < upper - x ) return lower;
		else if ( x - lower > upper - x ) return upper;
		else return x >= 0 ? lower : upper;
	}

	double Math::logit( double x )
	{
		assert( x >= 0 && x <= 1 );
		
		return log( x / ( 1.0 - x ) );	
	}

	double Math::inv_logit( double x )
	{
		return ( exp( x ) / ( 1.0 + exp( x ) ) );
	}

	vector< double > Math::transform( const vector< double > w )
	{
		double w0 = 1.0 - sum( w );
		vector< double > results;
		for ( int k = 0; k < w.size(); k++ ) results.push_back( log( w0 ) - log( w[ k ] ) );
		
		return results;
	}

	vector< double > Math::inverse_transform( const vector< double > u )
	{
		vector< double > neg_expo;
		double neg_expo_tot = 0;
		for ( int k = 0; k < u.size(); k++ ) {
			double temp = exp( -u[ k ] );
			neg_expo.push_back( temp );	
			neg_expo_tot += temp;
		}
		
		vector< double > results;
		for ( int k = 0; k < u.size(); k++ ) 
			results.push_back( neg_expo[ k ] / ( 1.0 + neg_expo_tot ) );
			
		return results;
	}

	void Math::numeric_deriv( gsl_vector* grad, double (*f)( const gsl_vector*, void* ), const gsl_vector* v, void* params, double step )
	{
		int n = v->size;
		double f_val = (*f)( v, params );
		
		gsl_vector* dv = gsl_vector_alloc( n );	
		for ( int i = 0; i < n; i++ ) {
			gsl_vector_memcpy( dv, v );
			gsl_vector_set( dv, i, gsl_vector_get( v, i ) + step );
			double partial_deriv = ( (*f)( dv, params ) - f_val ) / step;
			gsl_vector_set( grad, i , partial_deriv );
		}
	}
	
	/*****************************************************
	* Probablity and Statistics 
	******************************************************/

	// check if a vector of real numbers is probablity mass function: return false if not
	bool Stat::isPmf( const vector< double > &p )
	{
		double sum = 0; 
		for ( int i = 0; i < p.size(); ++i ) {
			sum += p[ i ];	
		}
		if ( fabs( sum - 1.0 ) > numeric_limits< double >::epsilon() ) return false;
		else return true;
	}

	// sample one outcome from a multinomial distribution
	int Stat::sampleMul( const gsl_rng * r, const vector< double > &p )
	{
		int k = p.size();	// # of different outcomes
		
		// sample
		double u = gsl_rng_uniform( r );
		double c = 0;
		for ( int i = 0; i < k; ++i ) {
			c += p[ i ];
			if ( u < c ) { return i; }	
		}			
		
		return k - 1;
	}

	// sample a positive integer from a truncated geometric series: 1, r, r^2, ... r^(n - 1)
	int Stat::sampleTruncatedGeometric( const gsl_rng* rng, double r, int n )
	{
		double factor = ( 1.0 - r ) / ( 1.0 - pow( r, n ) );
		vector< double > probs;
		double curr = 1.0;
		for ( int i = 0; i < n; i++ ) {
			probs.push_back( curr * factor );
			curr *= r;
		}
		
		return 1 + sampleMul( rng, probs );
	}

	// mixture of two multinomial distributions, where the weight of the first one is "weight"
	vector< double > Stat::multinomialMixture( const vector< double >& distr1, const vector< double >& distr2, double weight )
	{
		int size = distr1.size();
		assert( distr2.size() == size && isPmf( distr1 ) && isPmf( distr2 ) );
		
		vector< double > mix;
		for ( int i = 0; i < size; i++ ) {
			mix.push_back( weight * distr1[ i ] + ( 1 - weight ) * distr2[ i ] );	
		}	
		
		return mix;
	}

	/*****************************************************
	* String Functions 
	******************************************************/
	
	// split input string to substrings seperated by [sep]+
	void myString::split( vector< string >& result, const string& str, const string& sep )
	{
		result.clear();
		
		char buffer[ MAX_LINE ];
		strcpy( buffer, str.c_str() );
		char* token;
		token = strtok( buffer, sep.c_str() );
		while ( token ) {
			result.push_back( token );
			token = strtok( NULL, sep.c_str() );
		}
	}

	void myString::stringToVector( vector< string >& result, const string& str, const string& leftBoundary, const string& rightBoundary, const string& sep )
	{
		// find the substring containing the values
		int start = str.find_first_of( leftBoundary );
		int end = str.find_last_of( rightBoundary );
		string sub = str.substr( start + 1, end - start - 1 );

		// split the substring
		split( result, sub, sep );		
	}

	void myString::stringToVector( vector< double >& result, const string& str, const string& leftBoundary, const string& rightBoundary, const string& sep )
	{
		result.clear();
		vector< string > resultStr;
		stringToVector( resultStr, str, leftBoundary, rightBoundary, sep );
		
		for ( int i = 0; i < resultStr.size(); i++ ) {
			result.push_back( atof( resultStr[ i ].c_str() ) );		
		}
	}

	// convert a string to lower case
	void myString::ToLowerCase(string& str)
	{
		for (int i=0; i<strlen(str.c_str()); i++)
		{
			str[i] = tolower( str[i] );
		}
	}

	// convert a string to upper case
	void myString::ToUpperCase(string& str)
	{
		for (int i=0; i<strlen(str.c_str()); i++)
		{
			str[i] = toupper( str[i] );
		}
	}	
	
	/******** sequence related utility functions ***********/

	// test if a is a nucleotide {A,G,C,T}
	bool myString::isNt( int a )
	{
		if ( a < 0 || a >= NBASES ) return false;
		else return true;	
	}

	// test if a is a nucleotide or a gap
	bool myString::isNtOrGap( int a )
	{
		if ( isNt( a ) || a == GAP ) return true;
		else return false;	
	}

	// test if a is an extended symbol (N, Y, R)
	bool myString::isExtendedSymbol( int a )
	{
		if ( a >= NBASES && a < ALPHABET_SIZE && a != GAP ) 
			return true;
		else
			return false;
	}

	// test if a is a nt. or an extended symbol
	bool myString::isNtOrExtended( int a )
	{
		return ( a >= 0 && a < ALPHABET_SIZE && a != GAP);	
	}

	// test if a -> b is transition or transversion where a, b are nts.
	// transition: A <-> G, C <-> T
	// transversion: A/G <-> C/T
	bool myString::isTransition( int a, int b )
	{
		assert( isNt( a ) && isNt( b ) && a != b );
		
		if ( (a+b) == 2 || (a+b) == 4 ) return true;
		return false;
	}

	int myString::complement( int a )
	{
		assert( isNt( a ) || a == GAP );
			
		if ( a < NBASES ) return (NBASES-a-1);
		if ( a == GAP ) return GAP;
	}

	// conversion of a symbol (nt. or gap or N) to its index in ALPHABET
	int myString::symbolToInt( char c )
	{
		char upper = toupper( c );
		for ( int i = 0; i < ALPHABET_SIZE; i++ ) {
			if ( ALPHABET[ i ] == upper ) return i;	
		}
		
		return -1;
	}

	vector< double > myString::createDistr( double GC_content )
	{
		vector< double > result( NBASES );
		result[ 0 ] = result[ 3 ] = ( 1.0 - GC_content ) / 2;
		result[ 1 ] = result[ 2 ] = GC_content / 2;
		
		return result;
	}

	bool myString::IndelToBool( char c )
	{
		if ( c == 'b' || isNtOrExtended(symbolToInt(c)) ) return false;	
		else if ( c == '.' || c == '^' || c == ALPHABET[GAP] ) return true;
		else
		{
			cerr << "Undefined indel symbol: " << c << endl;
			exit( INPUT_ERROR );
		}
	}

}
