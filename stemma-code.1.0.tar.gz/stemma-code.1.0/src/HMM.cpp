// HMM.cpp: implementation of the HMM class.
//
//////////////////////////////////////////////////////////////////////

#include "HMM.h"

// Construction
HMM::HMM(const vector< Sequence >& seqs, const vector< TfbsMotif >& mots, const vector< Indel >& idls, const vector< string >& names, const bool _diagnose)
	: mDiagnose(_diagnose)
{
	this->sequences = seqs;
	//this->motifs = mots;
	for(int i=0; i<mots.size(); ++i)
	{
		this->motifs.push_back(mots[i]);
		this->motifs.push_back(mots[i].compRevCompl());
	}
	this->indels = idls;
	this->seqNames = names;

	this->TfbsPositions = NULL;
	this->refSequence = -1;
}

// Construction
HMM::HMM(const vector< Sequence >& seqs, const vector< TfbsMotif >& mots, const vector< Indel >& idls, const vector< string >& names, const int refSeq, const bool _diagnose)
	: mDiagnose(_diagnose)
{
	this->sequences = seqs;
	//this->motifs = mots;
	for(int i=0; i<mots.size(); ++i)
	{
		this->motifs.push_back(mots[i]);
		this->motifs.push_back(mots[i].compRevCompl());
	}
	this->indels = idls;
	this->seqNames = names;

	this->TfbsPositions = NULL;
	this->refSequence = refSeq;
}

// Destruction
HMM::~HMM()
{
	for(int i=0; i<this->motifEvolModels.rows(); i++)
		for(int j=0; j<this->motifEvolModels.cols(); j++)
			delete motifEvolModels[i][j];
	motifEvolModels.clear();
	delete NCrmBkgModel;

	this->NCrmProb.clear();
	this->CrmProb.clear();
	this->CrmBlockProb.clear();
	this->CrmBlockVCell.clear();
	this->NCrmVCell.clear();
	this->CrmVCell.clear();
	this->vPath.clear();
	this->vPath_CRM_block.clear();

	this->motifs.clear();
	this->Lambda.clear();
	this->Mu.clear();

	this->motifThrs.clear();
	for(int k=1; k<=this->num_motifs; ++k)
	{
		for(int i=0; i<this->sequences.size(); ++i)
		{
			delete [] this->TfbsPositions[k][i];
		}
		delete [] this->TfbsPositions[k];
	}
	delete [] this->TfbsPositions;
}

// Construction
void HMM::loadSequence(const PhyloTree& tree, const vector< Sequence >& seqs, const vector< Indel >& idls, const vector< string >& names)
{
	// clean previous sequence related data
	for(int k=1; k<=this->num_motifs; ++k)
	{
		for(int i=0; i<this->sequences.size(); ++i)
		{
			delete [] this->TfbsPositions[k][i];
		}
		delete [] this->TfbsPositions[k];
	}
	delete [] this->TfbsPositions;
	this->TfbsPositions = NULL;
	this->sequences.clear();
	this->indels.clear();
	this->seqNames.clear();

	// reset new sequence related data
	this->sequences = seqs;
	this->seq_length = this->sequences[0].size();
	this->indels = idls;
	this->seqNames = names;

	// compute the strong TFBS positions
	this->scanTfbsPositions();
	this->refSequence = -1;

	// re-load data to the Felsenstein's Algorithm
	this->felsen->loadSequence(this->TfbsPositions, tree, this->indels, this->sequences);
}

// Construction
void HMM::loadSequence(const PhyloTree& tree, const vector< Sequence >& seqs, const vector< Indel >& idls, const vector< string >& names, const int refSeq)
{
	// clean previous sequence related data
	for(int k=1; k<=this->num_motifs; ++k)
	{
		for(int i=0; i<this->sequences.size(); ++i)
		{
			delete [] this->TfbsPositions[k][i];
		}
		delete [] this->TfbsPositions[k];
	}
	delete [] this->TfbsPositions;
	this->TfbsPositions = NULL;
	this->sequences.clear();
	this->indels.clear();
	this->seqNames.clear();

	// reset new sequence related data
	this->sequences = seqs;
	this->seq_length = this->sequences[0].size();
	this->indels = idls;
	this->seqNames = names;

	// compute the strong TFBS positions
	this->scanTfbsPositions();
	this->refSequence = refSeq;

	// re-load data to the Felsenstein's Algorithm
	this->felsen->loadSequence(this->TfbsPositions, tree, this->indels, this->sequences);
}


void HMM::Init(const PhyloTree& tree, const Param &par, const int _StateHistAprxMode, const int _StateSwitchAprxMode)
{
	this->seq_length = this->sequences[0].size();
	this->num_motifs = this->motifs.size();

	// Initialize substitution models
	// 1). Initialize the NCRM background model
	this->NCrmBkgModel = new SubstModel_HKY(par.BgPWM, par.rate, par.bias);
	int max_motif_length = 0;
	for (int i=0; i<num_motifs; i++) {
		if (max_motif_length < this->motifs[i].length()) {
			max_motif_length = this->motifs[i].length();
		}
	}
	this->motifEvolModels.resize(num_motifs+1, max_motif_length);
	// 2). Initialize the CRM background model
	this->motifEvolModels[0][0] = new SubstModel_HKY(par.BgPWM, par.rate, par.bias);
	for (int j=1; j<max_motif_length; j++) this->motifEvolModels[0][j] = NULL;
	// 3). Initialize the CRM motif model
	for (int i=0; i<num_motifs; i++) {
		int j=0;
		for (; j<this->motifs[i].length(); ++j) {
			vector<double> temp_pi = (this->motifs[i].getPwm()).getRow(j);
			this->motifEvolModels[i+1][j] = new SubstModel_HB(temp_pi, this->motifEvolModels[0][0]->getRateMatrix());
		}
		for (; j<max_motif_length; ++j)
			this->motifEvolModels[i+1][j] = NULL;
	}

	// Other parameters
	this->mu = log(par.mu);
	this->nu = log(par.nu);
	this->one_mu = log(1.0-par.mu);
	this->one_nu = log(1.0-par.nu);
	
	assert(par.Lambda.size()*2 == this->num_motifs);
	assert(par.Mu.size()*2 == this->num_motifs);
	this->Lambda.reserve(this->num_motifs+1);
	this->Mu.reserve(this->num_motifs+1);
	for (int i=0; i<par.Lambda.size(); i++)
	{
		this->Lambda.push_back(par.Lambda[i]/2);
		this->Lambda.push_back(par.Lambda[i]/2);
		this->Mu.push_back(par.Mu[i]);
		this->Mu.push_back(par.Mu[i]);
	}
	this->Lambda.insert(this->Lambda.begin(), Math::sum(this->Lambda));
	//mu_o is never used, assign lambda_o here for later computing omega_k
	this->Mu.insert(this->Mu.begin(), this->Lambda[0]);
	
	// compute the strong TFBS positions
	for(int i=0; i<par.motifThrs.size(); ++i)
	{
		this->motifThrs.push_back(par.motifThrs[i]);
		this->motifThrs.push_back(par.motifThrs[i]);
	}		
	this->scanTfbsPositions();

	// Initialize the Felsenstein's Algorithm
	this->felsen = new Felsenstein(this->TfbsPositions, tree, this->indels, this->motifs, this->sequences
		, this->motifEvolModels, this->NCrmBkgModel
		, this->Lambda, this->Mu, _StateHistAprxMode, _StateSwitchAprxMode);

	return;
}

// Given the parameters of the model, compute the probability of a particular output sequence
// and the probabilities of the CRM state/NCRM values given that output sequence.
double HMM::Forward_CRM()
{
	this->NCrmProb.resize(seq_length);
	this->CrmProb.resize(num_motifs+1, seq_length);
	
	for (int i=0; i<seq_length; i++) {
		Forward_NCRM_Prob(i);
		for (int k=0; k<=num_motifs; k++) {
			Forward_CRM_Prob(i, k);
		}
	}

	// Compute the complete prob of the output sequences.
	double prob = NCrmProb[seq_length-1];
	for (int k=0; k<=num_motifs; k++) {
		prob = LogAddAlgorithm::log_add(prob, CrmProb[k][seq_length-1]);
	}

	return prob;
}


// Given the parameters of the model, compute the probability of a particular output CRM sequence
// and the probabilities of the motif/background state values given that output sequence.
double HMM::Forward_CRM_block(const int start, int end)
{
	this->CrmBlockProb.resize(this->num_motifs+1, this->seq_length);
	
	if (end == -1) { end = this->seq_length-1; }
	else assert(end<this->seq_length);
	for (int i=start; i<=end; i++) {
		for (int k=0; k<=num_motifs; k++) {
			Forward_CRM_block_Prob(i, k, start);
		}
	}

	// Compute the complete prob of the output sequences.
	double prob = CrmBlockProb[0][end];
	for (int k=1; k<=num_motifs; k++) {
		prob = LogAddAlgorithm::log_add(prob, CrmBlockProb[k][end]);
	}

	return prob;
}

// Given the parameters of the model, compute the probability of a particular output CRM sequence
// generated by background states.
double HMM::cmptCRMBackground(const int start, int end) const
{
	if (end == -1) { end = this->seq_length-1; }
	else assert(end<this->seq_length);
	double prob = 0;
	for (int i=start; i<=end; i++) {
		prob += compCrmMotifBlock(1, i, 0);
	}
	
	return prob;
}

//TODO HMM::Backward()
double HMM::Backward()
{
}

// Discover the parameters of the HMM given a dataset of sequences.
double HMM::Baum_Welch()
{
}


// Given the parameters of the model, find the most likely sequence of block states
// that could have generated a given output CRM sequence.
double HMM::Viterbi_CRM_block(const int start, const int end)
{
	this->CrmBlockVCell.resize(num_motifs+1, seq_length);

	assert(end<seq_length);
	for (int i=start; i<=end; i++) {
		for (int k=0; k<=num_motifs; k++) {
			Viterbi_CRM_block_vCell(i, k, start);
		}
	}

	getVPathOfCRM_block(start, end);

	if (! this->mDiagnose) this->CrmBlockVCell.clear();
	return this->vPath_CRM_block.back().back().vLogProb;
}

// Given the parameters of the model, find the most likely sequence of CRM states/NCRM
// that could have generated a given output sequence.
double HMM::Viterbi_CRM()
{
	this->NCrmVCell.resize(seq_length);
	this->CrmVCell.resize(num_motifs+1, seq_length);

//cerr<<"HMM::Viterbi_CRM..."<<endl;
	for (int i=0; i<seq_length; i++) {
//cerr<<"-- compute column: "<<i<<endl;
		Viterbi_NCRM_vCell(i);
		for (int k=0; k<=num_motifs; k++) {
//cerr<<"---- compute vCell of the block of motif: "<<k<<endl;
			Viterbi_CRM_vCell(i, k);
		}
	}
//cerr<<"before releasing memory..."<<endl;
	getVPathOfCRM();
//cerr<<"-- get vLogProb of the viterbiPath"<<endl;
//cerr<<this->vPath.size()<<endl;
//this->dumpNCrmVCells(cout);
//this->dumpCrmVCells(cout);
	this->NCrmVCell.clear();
	this->CrmVCell.clear();
//cerr<<"after releasing memory..."<<endl;
	return this->vPath.back().vLogProb;
}


// Extract the Viterbi path of the CRM annotation
void HMM::getVPathOfCRM()
{
	this->vPath.clear();
	int curPos = this->sequences[0].size()-1;
	double curProb = NCrmVCell[curPos].vLogProb;
	int curMotif = -1;
	for (int k=0; k<=num_motifs; k++)
	{
		if (curProb < CrmVCell[k][curPos].vLogProb)
		{
			curProb = CrmVCell[k][curPos].vLogProb;
			curMotif = k;
		}
	}

	while ( curPos >= 0 )
	{
		if (curMotif == -1)
		{
			curProb = NCrmVCell[curPos].vLogProb;
			vCell pCurCell(curProb, curMotif, curPos);
			this->vPath.push_back(pCurCell);
			curMotif = NCrmVCell[curPos].motifInd;
			curPos = NCrmVCell[curPos].posInd;
		}
		else
		{
			curProb = CrmVCell[curMotif][curPos].vLogProb;
			vCell pCurCell(curProb, curMotif, curPos);
			this->vPath.push_back(pCurCell);
			int preMotif = CrmVCell[curMotif][curPos].motifInd;
			curPos = CrmVCell[curMotif][curPos].posInd;
			curMotif = preMotif;
		}
	}

	reverse(this->vPath.begin(), this->vPath.end());
	
	return;
}

// Extract the Viterbi path of the block annotation within CRM
void HMM::getVPathOfCRM_block(const int START, const int END)
{
	vector<vCell> path;
	int curPos = END;
	double curProb = CrmBlockVCell[0][curPos].vLogProb;
	int curMotif = 0;
	for (int k=1; k<=num_motifs; k++)
	{
		if (curProb < CrmBlockVCell[k][curPos].vLogProb)
		{
			curProb = CrmBlockVCell[k][curPos].vLogProb;
			curMotif = k;
		}
	}

	while ( curPos >= START )
	{
		curProb = CrmBlockVCell[curMotif][curPos].vLogProb;
		vCell pCurCell(curProb, curMotif, curPos);
		path.push_back(pCurCell);
		int preMotif = CrmBlockVCell[curMotif][curPos].motifInd;
		curPos = CrmBlockVCell[curMotif][curPos].posInd;
		curMotif = preMotif;
	}

	reverse(path.begin(), path.end());
	this->vPath_CRM_block.push_back(path);
	return;
}

void HMM::dumpNCrmVCells(ostream & os)
{
	os << "The NCRM Dynamic Array:" <<endl;
	for (int i=0; i<this->seq_length; i++)
		os << NCrmVCell[i];
	os << endl;
}

void HMM::dumpCrmBlockVCells(ostream & os, const int start, const int end)
{
	os << "The CRM Block Dynamic Array:" <<endl;
	this->CrmBlockVCell.dump(os, start, end);
}

void HMM::dumpCrmVCells(ostream & os)
{
	os << "The CRM Dynamic Array:" <<endl;
	this->CrmVCell.dump(os);
}

void HMM::Viterbi_NCRM_vCell(int n)
{
	double blockProb = compNcrmBkgCol(n);
	if (n == 0)
	{
		this->NCrmVCell[n].motifInd = -1;
		this->NCrmVCell[n].posInd = -1;
		this->NCrmVCell[n].vLogProb
			= this->mu - LogAddAlgorithm::log_add(this->mu, this->nu) + blockProb;
		return;
    }
	
	int best_motif = -1;
	int best_pos = n-1;
	double best_vProb = this->one_nu + this->NCrmVCell[n-1].vLogProb;
	
	double tmp_vProb;
	for (int k=0; k<=this->num_motifs; k++) {
		tmp_vProb = this->CrmVCell[k][n-1].vLogProb + this->mu;
		if (best_vProb < tmp_vProb) {
			best_vProb = tmp_vProb;
			best_motif = k;
		}
    }
	this->NCrmVCell[n].vLogProb = best_vProb + blockProb;
	this->NCrmVCell[n].motifInd = best_motif;
	this->NCrmVCell[n].posInd = best_pos;

	return;
}

void HMM::Viterbi_CRM_vCell(int n, int k)
{
	int motif_len = (k==0) ? 1 : this->motifs[k-1].length();
	if ( n - motif_len +1 < 0 )
	{
		this->CrmVCell[k][n].motifInd = 0;
		this->CrmVCell[k][n].posInd = -1;
		this->CrmVCell[k][n].vLogProb = GSL_NEGINF;
		return;
	}

	if ( n - motif_len +1 == 0 )
	{
		this->CrmVCell[k][n].motifInd = 0;
		this->CrmVCell[k][n].posInd = -1;
		this->CrmVCell[k][n].vLogProb
			= compCrmMotifBlock(motif_len, n, k) + this->nu - LogAddAlgorithm::log_add(this->mu, this->nu);
		return;
	}
	
	// compute prob for various block length
	double best_vProb = GSL_NEGINF;
	int best_motif = 0;
	int best_pos = -1;
	int len = motif_len;
	int min_nt_length = getMinNtLen(len, n);	
	while(min_nt_length <= motif_len && n>=len)
	{
		if(k==0 || isMotifBlock(len, n, motif_len, k))
		{
			double curBlockProb = compCrmMotifBlock(len, n, k);
			double tmp_vProb = this->nu + this->NCrmVCell[n-len].vLogProb + curBlockProb;
			if (best_vProb < tmp_vProb) {
				best_vProb = tmp_vProb;
				best_motif = -1;
				best_pos = n-len;
			}
			for (int kk=0; kk<=this->num_motifs; kk++) {
				tmp_vProb = this->CrmVCell[kk][n-len].vLogProb + this->one_mu + curBlockProb;
				if (best_vProb < tmp_vProb) {
					best_vProb = tmp_vProb;
					best_motif = kk;
					best_pos = n-len;
				}
			}
		}
		if(k==0 || min_nt_length == motif_len) break;
		else min_nt_length = getMinNtLen(++len, n);
    }

	this->CrmVCell[k][n].vLogProb = best_vProb;
	this->CrmVCell[k][n].motifInd = best_motif;
	this->CrmVCell[k][n].posInd = best_pos;
	return;
}


void HMM::Viterbi_CRM_block_vCell(int n, int k, const int START)
{
	int motif_len = (k==0) ? 1 : this->motifs[k-1].length();
	if ( n - motif_len +1 < START )
	{
		this->CrmBlockVCell[k][n].motifInd = -1;
		this->CrmBlockVCell[k][n].posInd = START-1;
		this->CrmBlockVCell[k][n].vLogProb = GSL_NEGINF;
		return;
	}

	if ( n - motif_len +1 == START )
	{
		this->CrmBlockVCell[k][n].motifInd = -1;
		this->CrmBlockVCell[k][n].posInd = START-1;
		this->CrmBlockVCell[k][n].vLogProb = compCrmMotifBlock(motif_len, n, k);
		return;
	}

	// compute prob for various block length
	double best_vProb = GSL_NEGINF;
	int best_motif = 0;
	int best_pos = -1;
	int len = motif_len;
	int min_nt_length = getMinNtLen(len, n);	
	while(min_nt_length <= motif_len && n>=(len+START))
	{
		if(k==0 || isMotifBlock(len, n, motif_len, k))
		{
			double curBlockProb = compCrmMotifBlock(len, n, k);
			double tmp_vProb;
			for (int kk=0; kk<=this->num_motifs; kk++) {
				tmp_vProb = this->CrmBlockVCell[kk][n-len].vLogProb + curBlockProb;
				if (best_vProb < tmp_vProb) {
					best_vProb = tmp_vProb;
					best_motif = kk;
					best_pos = n-len;
				}
			}
		}
		if(k==0 || min_nt_length == motif_len) break;
		else min_nt_length = getMinNtLen(++len, n);
    }
	this->CrmBlockVCell[k][n].vLogProb = best_vProb;
	this->CrmBlockVCell[k][n].motifInd = best_motif;
	this->CrmBlockVCell[k][n].posInd = best_pos;
	return;
}

void HMM::Forward_NCRM_Prob(int n)
{
	double blockProb = compNcrmBkgCol(n);
	if (n == 0)
	{
		this->NCrmProb[n] = this->mu - LogAddAlgorithm::log_add(this->mu, this->nu) + blockProb;
		return;
    }
	
	double prob = this->one_nu + this->NCrmProb[n-1];
	double tmpProb;
	for (int k=0; k<=this->num_motifs; k++) {
		tmpProb = this->CrmProb[k][n-1] + this->mu;
		prob = LogAddAlgorithm::log_add(tmpProb, prob);
    }
	this->NCrmProb[n] = prob + blockProb;
	return;
}

void HMM::Forward_CRM_Prob(int n, int k)
{
	int motif_len = (k==0) ? 1 : this->motifs[k-1].length();
	if ( n - motif_len +1 < 0 )
	{
		this->CrmProb[k][n] = GSL_NEGINF;
		return;
	}

	if ( n - motif_len +1 == 0 )
	{
		this->CrmProb[k][n] = this->compCrmMotifBlock(motif_len, n, k) + this->nu - LogAddAlgorithm::log_add(this->mu,this->nu);
		return;
	}	
	
	// compute sum of prob for various block length
	double blockProb = GSL_NEGINF;
	int len = motif_len;
	int min_nt_length = getMinNtLen(len, n);	
	while(min_nt_length <= motif_len && n>=len)
	{
		if(k==0 || isMotifBlock(len, n, motif_len, k))
		{
			double curBlockProb = compCrmMotifBlock(len, n, k);
			double prob = this->nu + this->NCrmProb[n-len];
			double tmpProb;
			for (int kk=0; kk<=this->num_motifs; kk++) {
				tmpProb = this->CrmProb[kk][n-len] + this->one_mu;
				prob = LogAddAlgorithm::log_add(tmpProb, prob);
			}
			blockProb = LogAddAlgorithm::log_add(blockProb, prob + curBlockProb);
		}
		if(k==0 || min_nt_length == motif_len) break;
		else min_nt_length = getMinNtLen(++len, n);
    }

	this->CrmProb[k][n] = blockProb;
	
	return;
}

void HMM::Forward_CRM_block_Prob(int n, int k, const int START)
{
	int motif_len = (k==0) ? 1 : this->motifs[k-1].length();
	if ( n - motif_len +1 < START )
	{
		this->CrmBlockProb[k][n] = GSL_NEGINF;
		return;
	}

	if ( n - motif_len +1 == START )
	{
		this->CrmBlockProb[k][n] = this->compCrmMotifBlock(motif_len, n, k);
		return;
	}	
	
	// compute sum of prob for various block length
	double blockProb = GSL_NEGINF;
	int len = motif_len;
	int min_nt_length = getMinNtLen(len, n);	
	while(min_nt_length <= motif_len && n>=(len+START))
	{
		if(k==0 || isMotifBlock(len, n, motif_len, k))
		{
			double curBlockProb = compCrmMotifBlock(len, n, k);
			double prob = GSL_NEGINF;
			double tmpProb;
			for (int kk=0; kk<=this->num_motifs; kk++) {
				tmpProb = this->CrmBlockProb[kk][n-len];
				prob = LogAddAlgorithm::log_add(tmpProb, prob);
			}
			blockProb = LogAddAlgorithm::log_add(blockProb, prob + curBlockProb);
		}
		if(k==0) break;
		else if (min_nt_length == motif_len) break;
		else min_nt_length = getMinNtLen(++len, n);
    }
	this->CrmBlockProb[k][n] = blockProb;

	return;
}

inline double HMM::compNcrmBkgCol(int n)
{
	return this->felsen->cmptNcrmColProb(n);
}

inline double HMM::compCrmMotifBlock(int len, int end_pos, int k) const
{
	return this->felsen->cmptCrmBlockProb(len, end_pos, k);
}

inline double HMM::printCrmMotifBlock(ostream &os, int len, int end_pos, int k) const
{
	return this->felsen->printCrmBlockProb(os, len, end_pos, k);
}

// Get the length of the shortest "len"-column block sequence ended at position "n"
int HMM::getMinNtLen(int len, int n)
{
	int minLen = len;
	if(this->refSequence == -1)
	{
		for( int i=0; i< this->indels.size(); i++ )
		{
			int nt_len = this->indels[i].countNts(len, n);
			if (minLen > nt_len)
				minLen = nt_len;
		}
	}
	else
	{
		minLen = this->indels[this->refSequence].countNts(len, n);
	}
		
	return minLen;
}

// Check whether it could be a motif block, defined by 
// (1) whether the start and end columns are the ends of candidate TFBSs
// (2) whether contain a strong TFBS
// Or
// (1) given a reference sequence, whether there is a strong TFBS at the reference sequence
bool HMM::isMotifBlock(const int len, const int n, const int motifLen, const int k) const
{
	if(this->refSequence == -1)
	{
		bool start = false;
		bool end = false;
		bool bind = false;
		for (int i=0; i< this->sequences.size(); ++i)
		{
			int nt_len = this->indels[i].countNts(len, n);
			if (motifLen==nt_len)
			{
				if (! this->indels[i][n-len+1])
					start = true;
				if (! this->indels[i][n])
					end = true;
				if (this->TfbsPositions[k][i][n])
					bind = true;
				if (start && end && bind)
					break;
			}
		}

		return (start && end && bind);
	}
	else
	{
		int nt_len = this->indels[this->refSequence].countNts(len, n);
		if (motifLen==nt_len && ! this->indels[this->refSequence][n-len+1] && ! this->indels[this->refSequence][n] && this->TfbsPositions[k][this->refSequence][n])
			return true;
		else
			return false;	
	}
}

void HMM::scanTfbsPositions()
{
	this->TfbsPositions = new bool ** [this->num_motifs+1];
	this->TfbsPositions[0] = NULL;
	for(int k=1; k<=this->num_motifs; ++k)
	{
		TfbsMotif mot = this->motifs[k-1];
		int mot_len = mot.length();
		double mot_thr = this->motifThrs[k-1];
		this->TfbsPositions[k] = new bool * [this->sequences.size()];
		for(int i=0; i<this->sequences.size(); ++i)
		{
			this->TfbsPositions[k][i] = new bool [this->seq_length];
			deque<int> q;
			int n=0;
			while(q.size()<mot_len && n<this->seq_length)
			{
				this->TfbsPositions[k][i][n] = false;
				if(this->sequences[i][n] < NBASES)
					q.push_back(this->sequences[i][n]);
				++n;
			}
			if(q.size() == mot_len) this->TfbsPositions[k][i][n-1] = ( mot.energy(q) >= mot_thr );
			for(; n<this->seq_length; ++n)
			{
				if(this->sequences[i][n] < NBASES)
				{
					q.pop_front();
					q.push_back(this->sequences[i][n]);
					this->TfbsPositions[k][i][n] = ( mot.energy(q) >= mot_thr );
				}
				else
				{
					this->TfbsPositions[k][i][n] = this->TfbsPositions[k][i][n-1];
				}
			}
		}
	}
}

void HMM::printViterbiPath(ostream &os) const
{
	for (vector<vCell>::const_iterator it=this->vPath.begin(); it!=this->vPath.end(); ++it)
	{
		os << (*it) <<endl;
	}
	return;
}

// Convert the vPath to the alignment annotation 
vector<char> HMM::getAnnotationFromVPath() const
{
	vector<char> annotation;
	
	int cur_pos = 0;
	vector<vCell>::const_iterator it=this->vPath.begin();
	bool extend_motif = false;
	while(cur_pos < this->seq_length)
	{
		if (cur_pos == (*it).posInd)
		{
			if ((*it).motifInd == -1)
			{
				annotation.push_back(' ');
			}
			else if ((*it).motifInd == 0)
			{
				annotation.push_back('*');
			}
			else
			{
				annotation.push_back('>');
			}
			++cur_pos;
			++it;
			extend_motif = false;
		}
		else if (cur_pos < (*it).posInd)
		{
			if (extend_motif) {
				annotation.push_back('>');
				++cur_pos;
			}
			else
			{
				char mID[MAX_LINE];
				int id=((*it).motifInd + 1)/2;
				int len;
				if((*it).motifInd % 2) len=sprintf(mID, "+%d", id);
				else len=sprintf(mID, "-%d", id);
				for (int i=0; i<len; ++i) annotation.push_back(mID[i]);
				extend_motif = true;
				cur_pos += len;
				if(cur_pos > (*it).posInd)
				{
					int pos = (*it).posInd+1;
					if(pos<cur_pos) {
						cerr<<"Warning: annotation at position "<<pos<<" is truncated of string '";
						while(pos<cur_pos)
						{
							cerr<<annotation[pos++];
						}
						cerr<<"'"<<endl;
						annotation.erase(annotation.begin()+(*it).posInd+1, annotation.begin()+cur_pos);
						cur_pos = (*it).posInd+1;
					}
					++it;
				}
			}
		}
		else
		{
			cerr<<"Error of annotation before position: "<<cur_pos<<endl;
			exit(ANNOT_ERROR);
		}
	}

	return annotation;
}

// Convert the vPath to the alignment annotation 
vector<char> HMM::getAnnotationFromVPath(const vector< vCell >& vp, const int start, const int end) const
{
	assert(start>=0 && end<=this->seq_length-1);

	vector<char> annotation;
	
	int cur_pos = start;
	vector<vCell>::const_iterator it=vp.begin();
	bool extend_motif = false;
	while(cur_pos <= end)
	{
		if (cur_pos == (*it).posInd)
		{
			if ((*it).motifInd == -1)
			{
				annotation.push_back(' ');
			}
			else if ((*it).motifInd == 0)
			{
				annotation.push_back('*');
			}
			else
			{
				annotation.push_back('>');
			}
			++cur_pos;
			++it;
			extend_motif = false;
		}
		else if (cur_pos < (*it).posInd)
		{
			if (extend_motif) {
				annotation.push_back('>');
				++cur_pos;
			}
			else
			{
				char mID[MAX_LINE];
				int id=((*it).motifInd + 1)/2;
				int len;
				if((*it).motifInd % 2) len=sprintf(mID, "+%d", id);
				else len=sprintf(mID, "-%d", id);
				for (int i=0; i<len; ++i) annotation.push_back(mID[i]);
				extend_motif = true;
				cur_pos += len;
				if(cur_pos > (*it).posInd)
				{
					int pos = (*it).posInd+1;
					if(pos<cur_pos) {
						cerr<<"Warning: annotation at position "<<pos<<" is truncated of string '";
						while(pos<cur_pos)
						{
							cerr<<annotation[pos++];
						}
						cerr<<"'"<<endl;
						annotation.erase(annotation.begin()+(*it).posInd+1, annotation.begin()+cur_pos);
						cur_pos = (*it).posInd+1;
					}
					++it;
				}
			}
		}
		else
		{
			cerr<<"Error of annotation before position: "<<cur_pos<<endl;
			exit(ANNOT_ERROR);
		}
	}

	return annotation;
}

// Convert the vPath to the motif block LLR score 
vector<char> HMM::getLLRscoreFromVPath(const vector< vCell >& vp, const int start, const int end) const
{
	assert(start>=0 && end<=this->seq_length-1);

	vector<char> annotation;
	
	int cur_pos = start;
	vector<vCell>::const_iterator it=vp.begin();
	bool extend_motif = false;
	while(cur_pos <= end)
	{
		if (cur_pos == (*it).posInd)
		{
			annotation.push_back(' ');
			++cur_pos;
			++it;
			extend_motif = false;
		}
		else if (cur_pos < (*it).posInd)
		{
			if (extend_motif) {
				annotation.push_back(' ');
				++cur_pos;
			}
			else
			{
				char score[MAX_LINE];
				double llr = (*it).vLogProb;
				if (it != vp.begin())
				{
					llr -= (*(it-1)).vLogProb;
					for (int i=(*it).posInd; i>(*(it-1)).posInd; --i){
						llr += this->CrmBlockVCell[this->CrmBlockVCell[0][i].motifInd][this->CrmBlockVCell[0][i].posInd].vLogProb - this->CrmBlockVCell[0][i].vLogProb;
					}
				}
				else
				{
					for (int i=(*it).posInd; i>start; --i){
						llr += this->CrmBlockVCell[this->CrmBlockVCell[0][i].motifInd][this->CrmBlockVCell[0][i].posInd].vLogProb - this->CrmBlockVCell[0][i].vLogProb;
					}
					llr -= this->CrmBlockVCell[0][start].vLogProb;
				}
				int len=sprintf(score, "%.4f", llr);
				for (int i=0; i<len; ++i) annotation.push_back(score[i]);
				extend_motif = true;
				cur_pos += len;
				while(cur_pos > (*it).posInd)
				{
					//int pos = (*it).posInd+1;
					//if(pos<cur_pos) {
					//	cerr<<"Warning: annotation at position "<<pos<<" is truncated of string '";
					//	while(pos<cur_pos)
					//	{
					//		cerr<<annotation[pos++];
					//	}
					//	cerr<<"'"<<endl;
					//	annotation.erase(annotation.begin()+(*it).posInd+1, annotation.begin()+cur_pos);
					//	cur_pos = (*it).posInd+1;
					//}
					++it;
				}
			}
		}
		else
		{
			cerr<<"Error of LLR annotation before position: "<<cur_pos<<endl;
			exit(ANNOT_ERROR);
		}
	}

	return annotation;
}

void HMM::printCrmAnnotation(ostream &os) const
{
	vector<char> annt = getAnnotationFromVPath();
	CrmAnnotator crmAnt(this->sequences, annt, this->seqNames);
    crmAnt.print(os);
}

void HMM::printCrmAnnotation(ostream &os, const vector<int>& crm_start, const vector<int>& crm_end) const
{
	vector<char> annt;
	int crm_index = 0;
	int next_start = 0;
	while(crm_index < crm_start.size())
	{
		if(crm_start[crm_index] > next_start)
		{
			vector<char> ncrm_annt(crm_start[crm_index]-next_start, ' ');
			copy(ncrm_annt.begin(), ncrm_annt.end(), back_inserter(annt));
		}
		vector<char> crm_annt = getAnnotationFromVPath(this->vPath_CRM_block[crm_index], crm_start[crm_index], crm_end[crm_index]);
		copy(crm_annt.begin(), crm_annt.end(), back_inserter(annt));
		next_start = crm_end[crm_index]+1;
		crm_index++;
	}
	if (next_start < this->seq_length)
	{
		vector<char> ncrm_annt(this->seq_length-next_start, ' ');
		copy(ncrm_annt.begin(), ncrm_annt.end(), back_inserter(annt));
	}

	CrmAnnotator crmAnt(this->sequences, annt, this->seqNames);
	crmAnt.print(os);
}

void HMM::printCrmAnnotation4Diag(ostream &os, const vector<int>& crm_start, const vector<int>& crm_end) const
{
	vector<char> llrString;
	vector<char> annt;
	int crm_index = 0;
	int next_start = 0;
	while(crm_index < crm_start.size())
	{
		if(crm_start[crm_index] > next_start)
		{
			vector<char> ncrm_annt(crm_start[crm_index]-next_start, ' ');
			copy(ncrm_annt.begin(), ncrm_annt.end(), back_inserter(annt));
			copy(ncrm_annt.begin(), ncrm_annt.end(), back_inserter(llrString));
		}
		vector<char> crm_llr = getLLRscoreFromVPath(this->vPath_CRM_block[crm_index], crm_start[crm_index], crm_end[crm_index]);
		vector<char> crm_annt = getAnnotationFromVPath(this->vPath_CRM_block[crm_index], crm_start[crm_index], crm_end[crm_index]);
		copy(crm_annt.begin(), crm_annt.end(), back_inserter(annt));
		copy(crm_llr.begin(), crm_llr.end(), back_inserter(llrString));
		next_start = crm_end[crm_index]+1;
		crm_index++;
	}
	if (next_start < this->seq_length)
	{
		vector<char> ncrm_annt(this->seq_length-next_start, ' ');
		copy(ncrm_annt.begin(), ncrm_annt.end(), back_inserter(annt));
		copy(ncrm_annt.begin(), ncrm_annt.end(), back_inserter(llrString));
	}

	CrmAnnotator crmAnt(this->sequences, annt, this->seqNames);
	crmAnt.print4Diag(os, llrString);
}

void HMM::printCrmMotifBlockInfo4Diag(ostream &os, const vector<int>& crm_start, const vector<string>& names) const
{
	vector< int > seqIndex;
	this->felsen->getStateHistNodeIndex(seqIndex);
	assert(names.size() == seqIndex.size());
	for(int i=seqIndex.size()-1; i>=0; --i)
	{
		os << names[seqIndex[i]] << " ";
	}
	os << endl;

	int crm_index = 0;
	while(crm_index < crm_start.size())
	{
		int pre_pos = crm_start[crm_index]-1;
		for(vector< vCell >::const_iterator iter = this->vPath_CRM_block[crm_index].begin(); iter != this->vPath_CRM_block[crm_index].end(); ++iter)
		{
			int k = (*iter).motifInd;
			if (k <= 0)
				pre_pos = (*iter).posInd;
			else
			{
				int n = (*iter).posInd;
				os << "==== Block at " << pre_pos+1+1 << " - "<< n+1 << " ====" << endl;
				double prob = this->printCrmMotifBlock(os, n-pre_pos, n, k);
				os << "Prob. under the motif model:\t" << prob << endl;
				prob = this->cmptCRMBackground(pre_pos+1, n);
				os << "Prob. under the background model:\t" << prob << endl;
				pre_pos = n;
			}
		}
		crm_index++;
	}
}

void HMM::printBlockInfo4Diag(ostream &os, const int start, const int end, const int motifIndex, const vector<string>& names) const
{
	vector< int > seqIndex;
	this->felsen->getStateHistNodeIndex(seqIndex);
	assert(names.size() == seqIndex.size());
	for(int i=seqIndex.size()-1; i>=0; --i)
	{
		os << names[seqIndex[i]] << " ";
	}
	os << endl;

	os << "==== Block at " << start+1 << " - "<< end+1 << " ====" << endl;
	double prob = this->printCrmMotifBlock(os, end-start+1, end, motifIndex*2-1);
	os << "Prob. under the POSITIVE motif model:\t" << prob << endl;
	prob = this->printCrmMotifBlock(os, end-start+1, end, motifIndex*2);
	os << "Prob. under the NEGATIVE motif model:\t" << prob << endl;
	prob = this->cmptCRMBackground(start, end);
	os << "Prob. under the background model:\t" << prob << endl;
}

/*
// Given the parameters of the model, compute the probability of sliding windows of a particular output CRM sequence
void HMM::scanCrmByWindows(const int wLen, const int sLen, vector<int>& v_pos, vector<double>& v_score)
{
	vector< DynamicArray<double> > crmWindows_BlockProb;
	vector<int> window_start;
	int num_windows = (int) ceil((double) wLen / (double) sLen);
	for (int i=0; i<num_windows; ++i)
	{
		DynamicArray<double> block(num_motifs+1, wLen);
		crmWindows_BlockProb.push_back(block);
		window_start.push_back(sLen*i);
	}
	
	for (int i=0; i<this->seq_length; i++) {
		for (int k=0; k<=num_motifs; k++) {
			scanCrmByWindows_blockProb(i, k, wLen, sLen, window_start, crmWindows_BlockProb, v_pos, v_score);
		}
		if (i == window_start[0]+wLen-1)
		{
			// Compute the complete prob of the first window.
			vector< DynamicArray<double> >::iterator it=crmWindows_BlockProb.begin();
			double prob = (*it)[0][wLen-1];
			for (int kk=1; kk<=num_motifs; kk++) {
				prob = LogAddAlgorithm::log_add(prob, (*it)[kk][wLen-1]);
			}
			v_pos.push_back(window_start[0]);
			v_score.push_back(prob);
			// remove the finished window and push a new one in
			crmWindows_BlockProb.erase(it);
			DynamicArray<double> block(num_motifs+1, wLen);
			crmWindows_BlockProb.push_back(block);
			window_start.push_back(window_start.back()+sLen);		
			window_start.erase(window_start.begin());
		}
	}

	// Compute the complete prob of the rest of windows.
	for (int i=0; i<num_windows; ++i)
	{
		int end = this->seq_length-1-window_start[i];
		if (end < 0) break;
		double prob = crmWindows_BlockProb[i][0][end];
		for (int kk=1; kk<=num_motifs; kk++) {
			prob = LogAddAlgorithm::log_add(prob, crmWindows_BlockProb[i][kk][end]);
		}
		v_pos.push_back(window_start[i]);
		v_score.push_back(prob);
	}
	
	// Compute and subtract the background prob
	//double * bkgProb = new double[v_pos.size()];
	//for (int n=0; n<v_pos.size(); ++n) bkgProb[n]=0;
	//double prob;
	//for (int i=0; i<this->seq_length; i++) {
	//	prob = compCrmMotifBlock(1, i, 0);
	//	for (int n=0; n<v_pos.size(); ++n)
	//	{
	//		if ( i>=v_pos[n] && i<v_pos[n]+wLen )
	//			bkgProb[n] += prob;
	//	}
	//}
	//for (int i=0; i<v_pos.size(); ++i)
	//	v_score[i] -= bkgProb[i];
	double * bkgProb = new double[this->seq_length+1];
	double prob = 0;
	for (int i=0; i<this->seq_length; i++) {
		bkgProb[i] = prob;	
		prob += compCrmMotifBlock(1, i, 0);
	}
	bkgProb[this->seq_length] = prob;
	for (int i=0; i<v_pos.size(); ++i)
	{
		int end = v_pos[i] + wLen;
		if (end > this->seq_length) end = this->seq_length;
		v_score[i] += (bkgProb[v_pos[i]] - bkgProb[end]);
		if(fabs(v_score[i]) < EPS) v_score[i] = 0;
	}

	return;
}

void HMM::scanCrmByWindows_blockProb(int n, int k, const int wLen, const int sLen, vector<int>& window_start, vector< DynamicArray<double> >& crmWindows_BlockProb, vector<int>& v_pos, vector<double>& v_score)
{
	int motif_len = (k==0) ? 1 : this->motifs[k-1].length();

	double block_prob = GSL_NEGINF;
	if ( n - motif_len +1 >= 0 )
		block_prob = this->compCrmMotifBlock(motif_len, n, k);

	int num_windows = window_start.size();
	for (int i=0; i<num_windows; ++i)
	{
		int pos = n-window_start[i];
		if ( pos < 0 ) continue;
		else
		{
			if ( pos < wLen )
			{
				if( pos - motif_len +1 < 0 )
					crmWindows_BlockProb[i][k][pos] = GSL_NEGINF;
				else if ( pos - motif_len +1 == 0 )
				{
					crmWindows_BlockProb[i][k][pos] = block_prob;
				}
				else	// compute sum of prob for various block length
				{
					double blockProb = GSL_NEGINF;
					double curBlockProb = block_prob;
					int len = motif_len;
					int min_nt_length = getMinNtLen(len, n);	
					while(min_nt_length <= motif_len && pos>=len)
					{
						if(k==0 || isMotifBlock(len, n, motif_len, k))
						{
							if(len > motif_len) curBlockProb=compCrmMotifBlock(len, n, k);
							double prob = GSL_NEGINF;
							double tmpProb;
							for (int kk=0; kk<=this->num_motifs; kk++) {
								tmpProb = crmWindows_BlockProb[i][kk][pos-len];
								prob = LogAddAlgorithm::log_add(tmpProb, prob);
							}
							blockProb = LogAddAlgorithm::log_add(blockProb, prob + curBlockProb);
						}
						if(k==0 || min_nt_length == motif_len) break;
						else min_nt_length = getMinNtLen(++len, n);
					}
					crmWindows_BlockProb[i][k][pos] = blockProb;
				}
			}
		}
	}

	return;
}
*/

// Given the parameters of the model,
// compute the probability of sliding windows of a particular output CRM sequence
void HMM::scanCrmByWindows(const int wLen, const int sLen, vector<int>& v_pos, vector<double>& v_score)
{
	//this->CrmBlockVCell.resize(this->num_motifs+1, this->seq_length);
	this->CrmBlockProb.resize(this->num_motifs+1, this->seq_length);
	double * bkgProb = new double[this->seq_length+1];
	
	const int start=0;
	const int end=this->seq_length-1;

	double prob = 0;
	for (int i=start; i<=end; i++) {
		bkgProb[i] = prob;	
		prob += compCrmMotifBlock(1, i, 0);
		for (int k=0; k<=num_motifs; k++) {
			Forward_CRM_block_Prob(i, k, start);
			//Forward_CRM_block_Prob_viterbi(i, k, start);
		}
	}
	bkgProb[end+1] = prob;

	// Compute the complete prob of each window sequences.
	int start_pos = start;
	while(start_pos <= end)
	{
		int end_pos = start_pos+wLen-1;
		if (end_pos >= end) end_pos = end;
		double prob_end = this->CrmBlockProb[0][end_pos];
		for (int k=1; k<=num_motifs; k++) {
			prob_end = LogAddAlgorithm::log_add(prob_end, this->CrmBlockProb[k][end_pos]);
		}
		double prob_previous = 0;
		if (start_pos > start)
		{
			prob_previous = this->CrmBlockProb[0][start_pos-1];
			for (int k=1; k<=num_motifs; k++) {
				prob_previous = LogAddAlgorithm::log_add(prob_previous, this->CrmBlockProb[k][start_pos-1]);
			}
		}
		v_pos.push_back(start_pos+1);
		prob = prob_end - prob_previous + bkgProb[start_pos] - bkgProb[end_pos+1];
		if(fabs(prob) < EPS) prob = 0;
		v_score.push_back( prob );
		start_pos += sLen;
	}

/*	// Extract the viterbi path
	this->getVPathOfCRM_block(start, end);
	// Get the motif block scores
	this->getMotifBlockScoreFromVPath(bkgProb, this->vPath_CRM_block[0], start, end, v_sites);
*/
	if (! this->mDiagnose)
	{
		//this->CrmBlockVCell.clear();
		this->CrmBlockProb.clear();
		//this->vPath_CRM_block.clear();
	}
	delete [] bkgProb;

	return;
}

// Given the parameters of the model,
// compute the probability of sliding windows of a particular output CRM sequence
// and compute the viterbi decoding of the sites.
void HMM::scanCrmByWindows(const int wLen, const int sLen, vector<int>& v_pos, vector<double>& v_score, vector< motifSite >& v_sites)
{
	this->CrmBlockVCell.resize(this->num_motifs+1, this->seq_length);
	this->CrmBlockProb.resize(this->num_motifs+1, this->seq_length);
	double * bkgProb = new double[this->seq_length+1];
	
	const int start=0;
	const int end=this->seq_length-1;

	double prob = 0;
	for (int i=start; i<=end; i++) {
		bkgProb[i] = prob;	
		prob += compCrmMotifBlock(1, i, 0);
		for (int k=0; k<=num_motifs; k++) {
			//Forward_CRM_block_Prob(i, k, start);
			Forward_CRM_block_Prob_viterbi(i, k, start);
		}
	}
	bkgProb[end+1] = prob;

	// Compute the complete prob of each window sequences.
	int start_pos = start;
	while(start_pos <= end)
	{
		int end_pos = start_pos+wLen-1;
		if (end_pos >= end) end_pos = end;
		double prob_end = this->CrmBlockProb[0][end_pos];
		for (int k=1; k<=num_motifs; k++) {
			prob_end = LogAddAlgorithm::log_add(prob_end, this->CrmBlockProb[k][end_pos]);
		}
		double prob_previous = 0;
		if (start_pos > start)
		{
			prob_previous = this->CrmBlockProb[0][start_pos-1];
			for (int k=1; k<=num_motifs; k++) {
				prob_previous = LogAddAlgorithm::log_add(prob_previous, this->CrmBlockProb[k][start_pos-1]);
			}
		}
		v_pos.push_back(start_pos+1);
		prob = prob_end - prob_previous + bkgProb[start_pos] - bkgProb[end_pos+1];
		if(fabs(prob) < EPS) prob = 0;
		v_score.push_back( prob );
		start_pos += sLen;
	}

	// Extract the viterbi path
	this->getVPathOfCRM_block(start, end);
	// Get the motif block scores
	this->getMotifBlockScoreFromVPath(bkgProb, this->vPath_CRM_block[0], start, end, v_sites);

	if (! this->mDiagnose)
	{
		this->CrmBlockVCell.clear();
		this->CrmBlockProb.clear();
		this->vPath_CRM_block.clear();
	}
	delete [] bkgProb;

	return;
}

// Given the parameters of the model,
// compute the probability of sliding windows of a particular output CRM sequence on the reference genome
void HMM::scanCrmByWindows_ref(const int wLen, const int sLen, vector<int>& v_refPos, vector<int>& v_pos, vector<double>& v_score)
{
	//this->CrmBlockVCell.resize(this->num_motifs+1, this->seq_length);
	this->CrmBlockProb.resize(this->num_motifs+1, this->seq_length);
	double * bkgProb = new double[this->seq_length+1];
	
	const int start=0;
	const int end=this->seq_length-1;

	double prob = 0;
	for (int i=start; i<=end; i++) {
		bkgProb[i] = prob;	
		prob += compCrmMotifBlock(1, i, 0);
		for (int k=0; k<=num_motifs; k++) {
			Forward_CRM_block_Prob(i, k, start);
			//Forward_CRM_block_Prob_viterbi(i, k, start);
		}
	}
	bkgProb[end+1] = prob;

	// Compute the complete prob of each window sequences.
	vector< int > ref_starts;
	int ref_pos = this->indels[this->refSequence].getNtCounts(start-1)+1;
	int cur_pos;
	for(int i=start; i<=end; ++i)
	{
		if(this->indels[this->refSequence].getNtCounts(i) == ref_pos)
		{
			ref_starts.push_back(i);
			++ref_pos;
		}
	}	
	const int ref_length = ref_starts.size();	
	int start_pos, end_pos;
	for (int i=0; i<ref_length; i+=sLen)
	{
		start_pos = ref_starts[i];
		if (i+wLen > ref_length) end_pos = ref_starts.back();
		else end_pos = ref_starts[i+wLen-1];
		double prob_end = this->CrmBlockProb[0][end_pos];
		for (int k=1; k<=num_motifs; k++) {
			prob_end = LogAddAlgorithm::log_add(prob_end, this->CrmBlockProb[k][end_pos]);
		}
		double prob_previous = 0;
		if (start_pos > start)
		{
			prob_previous = this->CrmBlockProb[0][start_pos-1];
			for (int k=1; k<=num_motifs; k++) {
				prob_previous = LogAddAlgorithm::log_add(prob_previous, this->CrmBlockProb[k][start_pos-1]);
			}
		}
		v_refPos.push_back(this->indels[this->refSequence].getNtCounts(start_pos));
		v_pos.push_back(start_pos+1);
		prob = prob_end - prob_previous + bkgProb[start_pos] - bkgProb[end_pos+1];
		if(fabs(prob) < EPS) prob = 0;
		v_score.push_back( prob );
	}
	
/*	// Extract the viterbi path
	this->getVPathOfCRM_block(start, end);
	// Get the motif block scores
	this->getMotifBlockScoreFromVPath(bkgProb, this->vPath_CRM_block[0], start, end, v_sites);
	for(int i=0; i<v_sites.size(); ++i)
	{
		v_refSitePos.push_back(v_sites[i].pos);
		v_sites[i].pos = this->indels[this->refSequence].getNtCounts(v_sites[i].pos);
	}
*/
	if (! this->mDiagnose)
	{
		//this->CrmBlockVCell.clear();
		this->CrmBlockProb.clear();
		//this->vPath_CRM_block.clear();
	}
	delete [] bkgProb;

	return;
}

// Given the parameters of the model,
// compute the probability of sliding windows of a particular output CRM sequence on the reference genome
// and compute the viterbi decoding of the sites.
void HMM::scanCrmByWindows_ref(const int wLen, const int sLen, vector<int>& v_refPos, vector<int>& v_pos, vector<double>& v_score, vector<int>& v_refSitePos, vector< motifSite >& v_sites)
{
	this->CrmBlockVCell.resize(this->num_motifs+1, this->seq_length);
	this->CrmBlockProb.resize(this->num_motifs+1, this->seq_length);
	double * bkgProb = new double[this->seq_length+1];
	
	const int start=0;
	const int end=this->seq_length-1;

	double prob = 0;
	for (int i=start; i<=end; i++) {
		bkgProb[i] = prob;	
		prob += compCrmMotifBlock(1, i, 0);
		for (int k=0; k<=num_motifs; k++) {
			//Forward_CRM_block_Prob(i, k, start);
			Forward_CRM_block_Prob_viterbi(i, k, start);
		}
	}
	bkgProb[end+1] = prob;

	// Compute the complete prob of each window sequences.
	vector< int > ref_starts;
	int ref_pos = this->indels[this->refSequence].getNtCounts(start-1)+1;
	int cur_pos;
	for(int i=start; i<=end; ++i)
	{
		if(this->indels[this->refSequence].getNtCounts(i) == ref_pos)
		{
			ref_starts.push_back(i);
			++ref_pos;
		}
	}	
	const int ref_length = ref_starts.size();	
	int start_pos, end_pos;
	for (int i=0; i<ref_length; i+=sLen)
	{
		start_pos = ref_starts[i];
		if (i+wLen > ref_length) end_pos = ref_starts.back();
		else end_pos = ref_starts[i+wLen-1];
		double prob_end = this->CrmBlockProb[0][end_pos];
		for (int k=1; k<=num_motifs; k++) {
			prob_end = LogAddAlgorithm::log_add(prob_end, this->CrmBlockProb[k][end_pos]);
		}
		double prob_previous = 0;
		if (start_pos > start)
		{
			prob_previous = this->CrmBlockProb[0][start_pos-1];
			for (int k=1; k<=num_motifs; k++) {
				prob_previous = LogAddAlgorithm::log_add(prob_previous, this->CrmBlockProb[k][start_pos-1]);
			}
		}
		v_refPos.push_back(this->indels[this->refSequence].getNtCounts(start_pos));
		v_pos.push_back(start_pos+1);
		prob = prob_end - prob_previous + bkgProb[start_pos] - bkgProb[end_pos+1];
		if(fabs(prob) < EPS) prob = 0;
		v_score.push_back( prob );
	}
	
	// Extract the viterbi path
	this->getVPathOfCRM_block(start, end);
	// Get the motif block scores
	this->getMotifBlockScoreFromVPath(bkgProb, this->vPath_CRM_block[0], start, end, v_sites);
	for(int i=0; i<v_sites.size(); ++i)
	{
		v_refSitePos.push_back(v_sites[i].pos);
		v_sites[i].pos = this->indels[this->refSequence].getNtCounts(v_sites[i].pos);
	}

	if (! this->mDiagnose)
	{
		this->CrmBlockVCell.clear();
		this->CrmBlockProb.clear();
		this->vPath_CRM_block.clear();
	}
	delete [] bkgProb;

	return;
}

void HMM::Forward_CRM_block_Prob_viterbi(int n, int k, const int START)
{
	int motif_len = (k==0) ? 1 : this->motifs[k-1].length();
	if ( n - motif_len +1 < START )
	{
		this->CrmBlockVCell[k][n].motifInd = -1;
		this->CrmBlockVCell[k][n].posInd = START-1;
		this->CrmBlockVCell[k][n].vLogProb = this->CrmBlockProb[k][n] = GSL_NEGINF;
		return;
	}

	if ( n - motif_len +1 == START )
	{
		this->CrmBlockVCell[k][n].motifInd = -1;
		this->CrmBlockVCell[k][n].posInd = START-1;
		this->CrmBlockVCell[k][n].vLogProb = this->CrmBlockProb[k][n] = this->compCrmMotifBlock(motif_len, n, k);
		return;
	}	
	
	// compute sum of prob for various block length
	double blockProb = GSL_NEGINF;
	double best_vProb = GSL_NEGINF;
	int best_motif = 0;
	int best_pos = -1;
	int len = motif_len;
	int min_nt_length = getMinNtLen(len, n);	
	while(min_nt_length <= motif_len && n>=(len+START))
	{
		if(k==0 || isMotifBlock(len, n, motif_len, k))
		{
			double curBlockProb = compCrmMotifBlock(len, n, k);
			double prob = GSL_NEGINF;
			double tmpProb;
			double tmp_vProb;
			for (int kk=0; kk<=this->num_motifs; kk++) {
				tmpProb = this->CrmBlockProb[kk][n-len];
				prob = LogAddAlgorithm::log_add(tmpProb, prob);
				tmp_vProb = this->CrmBlockVCell[kk][n-len].vLogProb + curBlockProb;
				if (best_vProb < tmp_vProb) {
					best_vProb = tmp_vProb;
					best_motif = kk;
					best_pos = n-len;
				}
			}
			blockProb = LogAddAlgorithm::log_add(blockProb, prob + curBlockProb);
		}
		if(k==0 || min_nt_length == motif_len) break;
		else min_nt_length = getMinNtLen(++len, n);
    }
	this->CrmBlockProb[k][n] = blockProb;
	this->CrmBlockVCell[k][n].vLogProb = best_vProb;
	this->CrmBlockVCell[k][n].motifInd = best_motif;
	this->CrmBlockVCell[k][n].posInd = best_pos;
	return;
}

void HMM::getMotifBlockScoreFromVPath(double * bkgProb, const vector<vCell>& vp, const int start, const int end, vector< motifSite >& v_sites) const
{
	vector<vCell>::const_iterator it=vp.begin();
	int cur_pos = start;
	if ((*it).motifInd)
	{
		double llr = (*it).vLogProb - bkgProb[(*it).posInd+1] + bkgProb[cur_pos];
		int motifInd = ((*it).motifInd + 1)/2;
		char strand = ((*it).motifInd % 2) ? '+' : '-';
		v_sites.push_back( motifSite(cur_pos+1, motifInd, strand, llr) );
	}
	cur_pos = (*it).posInd + 1;
	++it;

	while(cur_pos <= end)
	{
		if ((*it).motifInd)
		{
			double llr = (*it).vLogProb - (*(it-1)).vLogProb - bkgProb[(*it).posInd+1] + bkgProb[cur_pos];
			int motifInd = ((*it).motifInd + 1)/2;
			char strand = ((*it).motifInd % 2) ? '+' : '-';
			v_sites.push_back( motifSite(cur_pos+1, motifInd, strand, llr) );
		}
		cur_pos = (*it).posInd + 1;
		++it;
	}
}

void HMM::scanCrmByWindows(const string &filePrefix, int winLen, int sftLen)
{
	string f_llr = filePrefix;
	f_llr.append(".wLLR.txt");
	string f_site = filePrefix;
	f_site.append(".site.txt");
	ofstream fout_llr( f_llr.c_str() );
	ofstream fout_site ( f_site.c_str() );

	/*int start = 0;
	while(start < sequences[0].size())
	{
		int end = start+winLen-1;
		if (end >= sequences[0].size()) end = sequences[0].size()-1;
		double prob_CRM = myHmm->Forward_CRM_block(start, end);
		double prob_background = myHmm->cmptCRMBackground(start, end);
		cout << start << "\t" << prob_CRM - prob_background <<endl;
		start += sftLen;
	}*/
	
	vector<int> v_pos;
	vector<double> v_score;
	vector< HMM::motifSite > v_sites;
	if (this->refSequence == -1)
	{
		if (this->seq_length == 1)
		{
			fout_llr << "1\t0" << endl;
			return;
		}
		this->scanCrmByWindows(winLen, sftLen, v_pos, v_score, v_sites);
		for(int i=0; i<v_pos.size(); ++i)
		{
			fout_llr << v_pos[i] << "\t" << v_score[i] << endl;
		}
		for(int i=0; i<v_sites.size(); ++i)
		{
			fout_site << v_sites[i] << endl;
		}
	}
	else
	{
		if (this->seq_length == 1)
		{
			fout_llr << "1\t0\t1" << endl;
			return;
		}
		vector<int> v_refPos;
		vector<int> v_refSitePos;
		this->scanCrmByWindows_ref(winLen, sftLen, v_refPos, v_pos, v_score, v_refSitePos, v_sites);
		for(int i=0; i<v_pos.size(); ++i)
		{
			fout_llr << v_refPos[i] << "\t" << v_score[i] << "\t" << v_pos[i] << endl;
		}
		for(int i=0; i<v_sites.size(); ++i)
		{
			fout_site << v_sites[i] << "\t" << v_refSitePos[i] << endl;
		}
	}
}

double HMM::cmptMaxCrmWindow(int winLen, int sftLen, char * info)
{
	double score = 0.0;
	if (this->seq_length == 1)
	{
		sprintf(info, "%d", 1);
		return score;
	}

	int index;
	vector<int> v_pos;
	vector<double> v_score;
	if (this->refSequence == -1)
	{
		this->scanCrmByWindows(winLen, sftLen, v_pos, v_score);
		score = Math::max(v_score, index);
		sprintf(info, "%d", v_pos[index]);
	}
	else
	{
		vector<int> v_refPos;
		this->scanCrmByWindows_ref(winLen, sftLen, v_refPos, v_pos, v_score);
		score = Math::max(v_score, index);
		sprintf(info, "%d\t%d", v_refPos[index], v_pos[index]);
	}
	
	return score;
}

// compute the viterbi decoding of the sites.
double HMM::cmptMaxCrmSite(char * info)
{
	double score = 0.0;
	if (this->seq_length == 1)
	{
		sprintf(info, "%d", 1);
		return score;
	}

	double * bkgProb = new double[this->seq_length+1];
	vector< HMM::motifSite > v_sites;
	// compute the viterbi path
	this->CrmBlockVCell.resize(this->num_motifs+1, this->seq_length);
	const int start=0;
	const int end=this->seq_length-1;
	double prob = 0;
	for (int i=start; i<=end; i++) {
		bkgProb[i] = prob;	
		prob += compCrmMotifBlock(1, i, 0);
		for (int k=0; k<=num_motifs; k++) {
			Viterbi_CRM_block_vCell(i, k, start);
		}
	}
	bkgProb[end+1] = prob;
	// Extract the viterbi path
	this->getVPathOfCRM_block(start, end);
	// Get the motif block scores
	this->getMotifBlockScoreFromVPath(bkgProb, this->vPath_CRM_block[0], start, end, v_sites);
	
	int index = -1;
	for(int i=0; i<v_sites.size(); ++i)
	{
		if ( score < v_sites[i].LLRscore )
		{
			score = v_sites[i].LLRscore;
			index = i;
		}
	}
	
	if (index == -1)
	{
		sprintf(info, "%d", -1);
	}
	else
	{
		if (this->refSequence == -1)
		{
			sprintf(info, "%d\t%c", v_sites[index].pos, v_sites[index].strand); 
		}
		else
		{
			sprintf(info, "%d\t%c\t%d", this->indels[this->refSequence].getNtCounts(v_sites[index].pos), v_sites[index].strand, v_sites[index].pos);
		}
	}

	if (! this->mDiagnose)
	{
		this->CrmBlockVCell.clear();
		this->vPath_CRM_block.clear();
	}
	delete [] bkgProb;

	return score;
}

void HMM::printCrmPosition(const string &filePrefix, const vector<string> &motifNames)
{
	string filename = filePrefix;
	filename.append(".module.txt");
	ofstream fout( filename.c_str() );
	
	int cur_pos = 0;
	bool was_crm = false;
	int crm_start;
	int crm_end;
	vector<string> cur_motifs;
	vector<vCell>::const_iterator it=this->vPath.begin();
	while(it != this->vPath.end())
	{
		if ((*it).motifInd >= 0)	// CRM
		{
			if (!was_crm)
			{
				was_crm = true;
				crm_start = (this->refSequence >=0) ? this->indels[this->refSequence].getNtCounts(cur_pos) : cur_pos;
			}
			int motifInd = ((*it).motifInd + 1)/2;
			if(motifInd) cur_motifs.push_back(motifNames[motifInd-1]);
		}
		else						// NCRM
		{
			if(was_crm)
			{
				was_crm = false;
				crm_end = (this->refSequence >=0) ? this->indels[this->refSequence].getNtCounts(cur_pos-1) : (cur_pos-1);
				// There might be case in which there is no tfbs. If so, treat it as noncrm.
				if ( cur_motifs.size() == 0 ) continue;
				// Remove duplicated motifs
				sort(cur_motifs.begin(), cur_motifs.end());
				vector<string>::iterator iter = unique(cur_motifs.begin(), cur_motifs.end());
				// print previous crm
				fout << crm_end-crm_start+1 << "\t" << crm_start << "\t" << crm_end << "\t";
				copy(cur_motifs.begin(), iter-1, ostream_iterator<string>(fout, ","));
				fout << *(iter-1) << endl;
				cur_motifs.clear();
			}
		}
		cur_pos = (*it).posInd + 1;
		++it;
	}
	if(was_crm)
	{
		crm_end = (this->refSequence >=0) ? this->indels[this->refSequence].getNtCounts(cur_pos-1) : (cur_pos-1);
		// There might be case in which there is no tfbs. If so, treat it as noncrm.
		if ( cur_motifs.size() )
		{
			// Remove duplicated motifs
			sort(cur_motifs.begin(), cur_motifs.end());
			vector<string>::iterator iter = unique(cur_motifs.begin(), cur_motifs.end());
			// print previous crm
			fout << crm_end-crm_start+1 << "\t" << crm_start << "\t" << crm_end << "\t";
			copy(cur_motifs.begin(), iter-1, ostream_iterator<string>(fout, ","));
			fout << *(iter-1) << endl;
			cur_motifs.clear();
		}
	}
}
