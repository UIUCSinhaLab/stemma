/***************************
* The library of general tools
***************************/

#ifndef TOOLS_H
#define TOOLS_H

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <gsl/gsl_vector.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_rng.h>
#include <gsl_math.h>

#include "common.h"
#include "Matrix.h"

/*
#include <cassert>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <vector>

#include <gsl/gsl_math.h>
#include <gsl/gsl_linalg.h>
#include <gsl/gsl_randist.h>
*/

using namespace std;

namespace myUtilities
{

	class GeneralUtil
	{
	public:
		// Re-order the vector of class T according to the string vector
		template< class T >
		static void ReorderVectorByString( vector< T >& v, vector< string >& string2index, const vector< string >& string4index )
		{
			for(int i=string4index.size()-1; i>=0; --i)
			{
				vector<string>::iterator cur_it=find(string2index.begin(), string2index.end(), string4index[i]);
				int ind = distance(string2index.begin(), cur_it);
				string temp_str=string2index.at(ind);
				string2index.erase(string2index.begin()+ind);
				string2index.insert(string2index.begin(),temp_str);
				T temp=v.at(ind);
				v.erase(v.begin()+ind);
				v.insert(v.begin(),temp);
			}
			return;
		}
	};

	/***********************
	* Log_add algorithm
	***********************/

	class LogAddAlgorithm
	{
	private:
		static double delta;				// interval size
		static vector< double > x_array;	// x[0], ..., x[N]
		static vector< double > T;			// T[0], ..., T[N] where T[k] = log( 1 + exp( x[k] ) )
		
	public:
		// constructor
		LogAddAlgorithm(){}
		
		virtual ~LogAddAlgorithm(){}

		// log-add algorithm: log_add( p, q ) = log( exp(p) + exp(q) )
		static void Init( double a, double b, int N );
		static double log_add( double p, double q );
		static double log_add( const double * p, int size );
		static double log_add( double p, double q, double r );
	};

	/*********************************
	* Mathematics Miscellaneous
	*********************************/

	class Math
	{
	public:
		// log. of a matrix
		static Matrix matrixLog( const Matrix& M );

		// sum
		template< class T >
		static inline T sum( const vector< T >& v )
		{
			T result = 0;
			for ( int i = 0; i < v.size(); i++ )
				result += v[ i ];
				
			return result;	
		}

		// median of a vector
		static double median( const vector< double > &x );

		// max and min
		template< class T >
		static inline T max( T x, T y, int &arg ) {
			if ( x >= y ) {
				arg = 0;
				return x;	
			} else {
				arg = 1;
				return y;	
			}
		}
		template< class T >
		static inline T min( T x, T y, int &arg ) {
			if ( x <= y ) {
				arg = 0;
				return x;	
			} else {
				arg = 1;
				return y;	
			}
		}
		template< class T >
		static inline T max( T x, T y, T z, int &arg ) {
			if ( x >= y ) {
				if ( x >= z ) {
					arg = 0;
					return x;	
				} else {
					arg = 2;
					return z;	
				}
			} else {
				if ( y >= z ) {
					arg = 1; 
					return y;	
				} else {
					arg = 2; 
					return z;	
				}
			}	
		}
		template< class T >
		static inline T min( T x, T y, T z, int &arg ) {
			if ( x <= y ) {
				if ( x <= z ) {
					arg = 0;
					return x;	
				} else {
					arg = 2;
					return z;	
				}
			} else {
				if ( y <= z ) {
					arg = 1; 
					return y;	
				} else {
					arg = 2; 
					return z;	
				}
			}	
		}
		static double max( const vector< double >& v, int &arg );
		static double min( const vector< double >& v, int &arg );

		// the threshold value at a given percentage in a vector of numbers
		// if highest is true, then the value at the highest p; otherwise, the value at the lowest p
		static double elementAt( const vector< double >& v, double p, bool highest = true );

		// rounding function: round x towards zero to the nearest integer (e.g. trunc (1.5) is 1.0 and trunc (-1.5) is -1.0 )
		static double trunc( double x );

		// logit function & inverse logit function
		static double logit( double x );
		static double inv_logit( double x );

		// transformation involving weight parameters (w: 0 <= w_i <= 1) s.t. the new parameters in (-inf,+inf)
		static vector< double > transform( const vector< double > w );		// w -> u
		static vector< double > inverse_transform( const vector< double > u );		// u -> w

		// finite difference method of gradient of a function
		static void numeric_deriv( gsl_vector* grad, double (*f)( const gsl_vector*, void* ), const gsl_vector* v, void* params, double step );

	};

	/*****************************************************
	* Probablity and Statistics 
	******************************************************/
	class Stat
	{
	public:
		// check if a vector of real numbers is probablity mass function
		static bool isPmf( const vector< double > &p );

		// sample one outcome from a multinomial distribution
		static int sampleMul( const gsl_rng * r, const vector< double > &p );

		// sample a positive integer from a truncated geometric series: 1, r, r^2, ... r^(n - 1)
		static int sampleTruncatedGeometric( const gsl_rng* rng, double r, int n );

		// mixture of two multinomial distributions, where the weight of the first one is "weight"
		static vector< double > multinomialMixture( const vector< double >& distr1, const vector< double >& distr2, double weight );
	};

	/*****************************************************
	* String Functions 
	******************************************************/
	class myString
	{
	public:

	// split input string to substrings seperated by [sep]+
	static void split( vector< string >& result, const string& str, const string& sep );

	// convert a string in the format of "{bcd,Kr,hb}" (separated by , or space) into a vector of strings
	static void stringToVector( vector< string >& result, const string& str, const string& leftBoundary = "{", const string& rightBoundary = "}", const string& sep = " ," );

	// convert a string in the format of "{0.3,0.2,0.2,0.3}" (separated by , or space) into a vector of numbers
	static void stringToVector( vector< double >& result, const string& str, const string& leftBoundary = "{", const string& rightBoundary = "}", const string& sep = " ," );
	
	// convert a string to lower case
	static void ToLowerCase(string& str);
	
	// convert a string to upper case
	static void ToUpperCase(string& str);
		
	/******** sequence related utility functions ***********/
	// test if a is a nucleotide {A,G,C,T}
	static bool isNt( int a );
	// test if a is a nucleotide or a gap
	static bool isNtOrGap( int a );
	// test if a is an extended symbol (N, Y, R)
	static bool isExtendedSymbol( int a );
	// test if a is a nt. or an extended symbol
	static bool isNtOrExtended( int a );
	// test if a -> b is transition or transversion where a, b are nts.
	static bool isTransition( int a, int b );
	// the complement of a nt.
	static int complement( int a );
	// conversion of a symbol (nt. or gap or N) to its index in ALPHABET
	static int symbolToInt( char c );
	// generate the distribution of nts from GC content
	static vector< double > createDistr( double GC_content );
	// test if a is in the alphabet
	static bool inAlphabet ( int a ) { return (a>=0 && a<ALPHABET_SIZE); }
	// conversion of a indel symbol (b or -) to its boolean value (false or true)
	static bool IndelToBool( char c );
	
	};

}

#endif
