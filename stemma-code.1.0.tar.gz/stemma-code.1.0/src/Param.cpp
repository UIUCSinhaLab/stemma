// Param.cpp: implementation of the parameter related functions.
//
//////////////////////////////////////////////////////////////////////

#include "Param.h"

void Param::loadParameters(const string& paramFile)
{
	// read the parameters
	map< string, string > params;
	IO::readParams( paramFile, params );
	
	// neutral background distribution (for computing binding energy)
	myString::stringToVector( this->BgPWM, params[ "background" ] );
	assert( this->BgPWM.size() == NBASES && Stat::isPmf( BgPWM ) );

	// substitution rate
	this->rate = atof( params[ "rate" ].c_str() );

	// transition/transversion bias
	this->bias = atof( params[ "bias" ].c_str() );

	// HMM transition probs
	this->mu = atof( params[ "mu" ].c_str() );
	this->nu = atof( params[ "nu" ].c_str() );

	// TFBS gain/loss rate
	myString::stringToVector( this->Lambda, params[ "Lambda" ] );
	myString::stringToVector( this->Mu, params[ "Mu" ] );
	
	// TFBS energy threshold
	myString::stringToVector( this->motifThrs, params[ "motifThr" ] );
	
	/*
	// read the alignment 
	Alignment aln;
	pair< string, string > names;
	rval = aln.load( alnFile, names );
	string name1 = names.first, name2 = names.second;	
	if ( rval == RET_ERROR ) { 
		cerr << "Cannot read the alignment file " << alnFile << endl;
		exit( 1 );
	}
		
	// the time parameter
	double t1 = atof( params[ "t1" ].c_str() );
	double t2 = atof( params[ "t2" ].c_str() );
	double delta_t = atof( params[ "delta_t" ].c_str() );
	TimeParam tp( t1, t2, delta_t );
	//cout << "Time parameter: " << tp.t1 << "\t" << tp.t2 << endl;
	
	
	// read the PWM of the motifs
	//cout << "Read motifs"<< endl;
	string motifFile = params[ "motifFile" ];
	assert( !motifFile.empty() );
	vector< Motif > preMotifs;
	vector< string > motifNames;
	rval = readMotifs( motifFile, preMotifs, motifNames );
	assert( rval != RET_ERROR );
	vector< TfbsMotif > motifs;
	for ( int i = 0; i < preMotifs.size(); ++i ) {
		motifs.push_back( TfbsMotif( preMotifs[ i ].getPwm(), background ) );
	}
	
	// read the weights and thresholds of the TFBS motifs
	string motifInfoFile = params[ "motifInfoFile" ];
	assert( !motifInfoFile.empty() );
	vector< double > weights;	
	vector< double > thresholds;
	ifstream fMotifInfo( motifInfoFile.c_str() );
	if ( !fMotifInfo ) { cerr << "Cannot open " << motifInfoFile << endl; exit( 1 ); }
	string name;
	double weight, threshold;
	while ( fMotifInfo >> name >> weight >> threshold ) {
		weights.push_back( weight );			
		thresholds.push_back( threshold );
	}
	assert( weights.size() == motifs.size() );
	
	// the evolutionary parameters of the background sequence
	double rate = atof( params[ "rate" ].c_str() );
	double bias = atof( params[ "bias" ].c_str() );
	double lambda_ratio = atof( params[ "lambda_ratio" ].c_str() );
	double mu_ratio = atof( params[ "mu_ratio" ].c_str() );
	double r = atof( params[ "r" ].c_str() );
		
	// the relative indel rate within TFBS
	double rho = atof( params[ "rho" ].c_str() );
	*/
}

void Param::dumpParameters(ostream& os)
{
	// neutral background distribution (for computing binding energy)
	os <<"# neutral background nt. distribution (used in computation of binding energy)"<<endl;
	os << "background = {";
	copy(this->BgPWM.begin(), this->BgPWM.end(), ostream_iterator<double>(os, ","));
	os << "}" <<endl;

	// substitution rate
	os << "# evolutionary parameters of the background sequence" <<endl;
	os << "rate = " << this->rate <<endl;
	os << "bias = " << this->bias <<endl;

	// HMM transition probs
	os << "# HMM transition probs" <<endl;
	os << "mu = " << this->mu <<endl;
	os << "nu = " << this->nu <<endl;

	// TFBS gain/loss rate
	os << "# TFBS gain/loss rate" <<endl;
	os << "Lambda = {";
	copy(this->Lambda.begin(), this->Lambda.end(), ostream_iterator<double>(os, ","));
	os << "}" <<endl;
	os << "Mu = {";
	copy(this->Mu.begin(), this->Mu.end(), ostream_iterator<double>(os, ","));
	os << "}" <<endl;
	
	// TFBS energy threshold
	os << "# TFBS energy threshold" <<endl;
	os << "motifThr = {";
	copy(this->motifThrs.begin(), this->motifThrs.end(), ostream_iterator<double>(os, ","));
	os << "}" <<endl;

}
