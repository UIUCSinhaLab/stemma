// IO.cpp: implementation of the IO related functions.
//
//////////////////////////////////////////////////////////////////////

#include "IO.h"

string IO::vector_delimiter = "\t";
string IO::map_delimiter = "\n";
string IO::field_separator = "\t";

// read indel annotations from a file
int IO::readIndelAnts( const string& file, vector< Indel >& indelAnts, vector< string >& names, int format )
{
	// check if the format character is legal
	if ( format != FASTA && format != PHYLIP ) { return INPUT_ERROR; }
	 
	// 	open the file
	ifstream fin( file.c_str() );
	if ( !fin ) { cerr << "Cannot open" << file << endl; exit( 1 ); }

	string line;
	Indel indelAnt;
	
	// read sequences: FASTA format
	if ( format == FASTA ) {
		while ( getline( fin, line ) ) {
			// add the sequence and start a new sequence if the line starts with >
			if ( line[ 0 ] == '>' ) {
				if ( indelAnt.size() ) {
					indelAnt.InitNtCounts();
					indelAnts.push_back( indelAnt );

					indelAnt.clear();
				}
				names.push_back( line.substr( 1 ) );
			} else { 
				// check if the line contains content
				int start = line.find_first_not_of( " \t\r" );
				int last = line.find_last_not_of( " \t\r" );
				if ( start == string::npos || last == string::npos ) continue;
				// append	
				for ( int i = start; i <= last; i++ ) {
					bool idl = myString::IndelToBool( line[ i ] );	// could be a gap
					indelAnt.push_back( idl );
				}
			}			
		}
		
		// add the last sequence
		if( indelAnt.size() )
		{
			indelAnt.InitNtCounts();
			indelAnts.push_back( indelAnt );
		}
	}

	if (indelAnts.size() != names.size())
	{
		cerr << "Error in the indel file: " << file;
		cerr << ", " << indelAnts.size() << " indel sequences with " << names.size() << " names" << endl;
		exit( INPUT_ERROR );
	}

	return 0;
}

int IO::readIndelAnts( const string& file, vector< Indel >& indelAnts, int format )
{
	vector< string > names;
	int rval = readIndelAnts( file, indelAnts, names, format );	
	return rval;
}

void IO::writeIndelAnts( const string& file, const vector< Indel >& indelAnts, const vector< string >& names, int format )
{
	assert( indelAnts.size() == names.size() );
	
	// check if the format character is legal
	if ( format != FASTA && format != PHYLIP ) {
		cerr<< "ERROR: Undefined format for sequence input!"<<endl;
		exit( INPUT_ERROR );
	}
		
	ofstream fout( file.c_str() );
	if ( format == FASTA ) {
		for ( int i = 0; i < indelAnts.size(); i++ ) {
			fout << ">" << names[ i ] << endl;
			indelAnts[i].dumpIndelAnt( fout );
			fout << endl;
		}
	}
}

void IO::writeIndelAnts( const string& file, const vector< Indel >& indelAnts, int format )
{
	// default name: integer starting from 1
	vector< string > names;
	for ( int i = 0; i < indelAnts.size(); i++ ) {
		char buffer[ 10 ];
		sprintf( buffer, "%i", i );
		names.push_back( string( buffer ) );	
	}	
	
	// print
	writeIndelAnts( file, indelAnts, names, format );
}

// read parameter file into a <field, value> table. Return 0 if successful, -1 otherwise
// Format: field = value [# ...] where # indicates the start of comments (ignored)
// Ex. kappa = 2.0 # kappa: the transition/transversion bias
void IO::readParams( const string& file, map< string, string >& params, const char* comment )
{
	params.clear();
	
	// open the parameter file
	ifstream fin( file.c_str() );
	if ( !fin ){
		cerr << "Cannot open the parameter file: " << file << endl;
		exit( INPUT_ERROR );
	}
	
	// read parameters
	string line;
	while ( getline( fin, line ) ) {
		// skip a line if it starts with a comment or non-alphnumerical charcter 
		int first = line.find_first_not_of( " \t\r" );
		if ( !isalnum( line[ first ] ) || strchr( comment, line[ first ] ) ) continue;
				
		// check if the line contains '=', if not error
		int posEq = line.find( '=' );
		if ( posEq == string::npos ) {
			cerr << "Error in the parameter file: missing =" <<endl;
			exit( INPUT_ERROR );
		}
		
		// read the parameter name
		string name;
		int pos1 = line.find_first_not_of( " \t\r" );
		int pos2 = line.find_last_not_of( " \t\r", posEq - 1);
		if ( pos1 <= pos2 ) name = line.substr( pos1, pos2 - pos1 + 1 );
		
		// read the value, skipping the part of sentence starting with a comment symbol if any
		string value;
		pos1 = line.find_first_not_of( " \t\r", posEq + 1 );
		int posComment = line.find_first_of( comment );
		if ( posComment != string::npos ) {
			pos2 = line.find_last_not_of( " \t\r", posComment - 1 );
		} else {
			pos2 = line.find_last_not_of( " \t\r" );
		}
		if ( pos1 <= pos2 ) value = line.substr( pos1, pos2 - pos1 + 1 );
		
		// add to the table of parameters
		if ( name.size() && value.size() ) 
			params[name] = value;
		else 
		{
			cerr<< "Wrong format of the parameter file at line: " << line <<endl;
			exit( INPUT_ERROR );
		}
	}
}

// Read in a table file
// Format: mutiple fields seperated by TAB
//         Line start with # indicates comments, will be ignored
// The inner vector is constructed from one line.
void IO::readTable( const string& file, vector< vector< string > >& table, const char* comment )
{
	table.clear();
	
	// open file
	ifstream fin( file.c_str() );
	if ( !fin ){
		cerr << "Cannot open the file: " << file << endl;
		exit( INPUT_ERROR );
	}
	
	// read strings
	string line;
	while ( getline( fin, line ) ) {
		// skip a line if it starts with a comment or is empty 
		int first = line.find_first_not_of( " \t\r\n" );
		if ( first == string::npos || strchr( comment, line[ first ] ) ) continue;
				
		vector<string> fields;
		myString::split(fields, line, "\t");
		table.push_back(fields);
	}
}

// read sequences from a file
int IO::readSequences( const string& file, vector< Sequence >& seqs, vector< string >& names, int format )
{
	// check if the format character is legal
	if ( format != FASTA && format != PHYLIP ) { return INPUT_ERROR; }
	 
	// 	open the file
	ifstream fin( file.c_str() );
	if ( !fin ) { cerr << "Cannot open" << file << endl; exit( 1 ); }

	string line;
	Sequence seq;
	
	// read sequences: FASTA format
	if ( format == FASTA ) {
		while ( getline( fin, line ) ) {
			// add the sequence and start a new sequence if the line starts with >
			//cout << line << endl;
			if ( line[ 0 ] == '>' ) {
				if ( seq.size() ) {
					seqs.push_back( seq );
					seq.clear();
				}
				
				names.push_back( line.substr( 1 ) );
			} else { 
				// check if the line contains content
				int start = line.find_first_not_of( " \t\r" );
				int last = line.find_last_not_of( " \t\r" );
				if ( start == string::npos || last == string::npos ) continue;
				
				// append the sequence	
				for ( int i = start; i <= last; i++ ) {
					int nt = myString::symbolToInt( line[ i ] );	// could be a gap
					if ( nt >= 0 && nt < ALPHABET_SIZE ) {
						seq.push_back( nt );
					} else {
						cerr << "Illegal symbol: " << nt << " in " << file << endl;
						return INPUT_ERROR;	
					} 
				}
			}			
		}
		
		// add the last sequence
		if( seq.size() ) seqs.push_back( seq );
	}

	if (seqs.size() != names.size())
	{
		cerr << "Error in the sequence file: " << file;
		cerr << ", " << seqs.size() << " sequences with " << names.size() << " names" << endl;
		exit( INPUT_ERROR );
	}

	return 0;	
}

int IO::readSequences( const string& file, vector< Sequence >& seqs, int format )
{
	vector< string > names;
	int rval = readSequences( file, seqs, names, format );	
	return rval;
}

void IO::writeSequences( const string& file, const vector< Sequence >& seqs, const vector< string >& names, int format )
{
	assert( seqs.size() == names.size() );
	
	// check if the format character is legal
	if ( format != FASTA && format != PHYLIP ) {
		cerr<< "ERROR: Undefined format for sequence input!"<<endl;
		exit( INPUT_ERROR );
	}
		
	ofstream fout( file.c_str() );
	if ( format == FASTA ) {
		for ( int i = 0; i < seqs.size(); i++ ) {
			fout << ">" << names[ i ] << endl;
			seqs[i].dumpSequence( fout );
			fout << endl;
		}
	}
}

void IO::writeSequences( const string& file, const vector< Sequence >& seqs, int format )
{
	// default name: integer starting from 1
	vector< string > names;
	for ( int i = 0; i < seqs.size(); i++ ) {
		char buffer[ 10 ];
		sprintf( buffer, "%i", i );
		names.push_back( string( buffer ) );	
	}	
	
	// print
	writeSequences( file, seqs, names, format );
}

void IO::writeAlignment( const string& file, const Alignment& align, const vector< string >& names, int format )
{
	// TODO
}

void IO::writeAlignment( const string& file, const Alignment& align, int format )
{
	// TODO
}

int IO::readMotifs( const string& file, vector< Motif >& motifs, vector< string >& names, int format)
{
	switch (format)
	{
	case FM:
		return readFmMotifs( file, motifs, names );
	case WTMX:
		return readWtmxMotifs( file, motifs, names );
	default:
		cerr<< "Undefined format for motif file: " << file <<endl;
		cerr<< "It should be in FM or WTMX format!" <<endl;
		exit( INPUT_ERROR );
	}
	
	return 0;
}

// read the motifs (PWMs) in a FM format: frequency matrix.
// The format is a four column, space separated file.
// Each line represents a position in the binding site
// and each column represents a base in the order A, C, G & T.
// It is a frequency matrix, not a counts matrix.
// For each position in the site, the frequencies of each base must add up to 1.
int IO::readFmMotifs( const string& file, vector< Motif >& motifs, vector< string >& names )
{
	// open the file
	ifstream fin( file.c_str() );
	if ( !fin ) { cerr << "Cannot open" << file << endl; exit( INPUT_ERROR ); }

	string line = "";
	vector < double * > fm;
	// read the motifs
	while ( !fin.eof() )
	{
		getline( fin, line );
		if ( line.size() == 0 ) continue;
		if ( line[ 0 ] == '>' ) {
			// read the name
			string name( line.substr(1).c_str() );
			names.push_back( name );
			if( fm.size() )
			{
				motifs.push_back( Motif( Matrix( fm, NBASES ) ) );
				for(int i=0; i<fm.size(); i++) delete fm[i];
				fm.clear();
			}
		}
		else
		{
			vector< string > prob;
			myString::split(prob, line, " \t\n");
			if ( prob.size() != NBASES)
			{
				cerr<< "Wrong FM format in the motif file: "<< file;
				cerr<< ", at line: " << line << endl;
				exit( INPUT_ERROR );
			}
			double * row = new double[NBASES];
			for ( int i = 0; i < NBASES; ++i ) {
				row[i] = atof( prob[i].c_str() );
			}
			fm.push_back( row );
		}
		line = "";
	}

	if( fm.size() )
	{
		motifs.push_back( Motif( Matrix( fm, NBASES ) ) );
		//for(int i=0; i<fm.size(); i++) delete fm[i];
		fm.clear();
	}

	if (motifs.size() != names.size())
	{
		cerr << "Error in the motif file: " << file;
		cerr << ", " << motifs.size() << " motifs with " << names.size() << " names" << endl;
		exit( INPUT_ERROR );
	}

	return 0;
}

// read the motifs (PWMs) in a WTMX (FASTA-like) format: pseudocounts within the file
int IO::readWtmxMotifs( const string& file, vector< Motif >& motifs, vector< string >& names )
{
	// open the file
	ifstream fin( file.c_str() );
	if ( !fin ) { cerr << "Cannot open" << file << endl; exit( INPUT_ERROR ); }

	string line;
	
	// read the motifs
	do {
		getline( fin, line );
		
		if ( line[ 0 ] != '>' ) continue;
		
		// read the names, length and pseudocount
		int MAX_SIZE = 100;
		char lineStr[ MAX_SIZE ];
		strcpy( lineStr, ( line.substr( 1 ) ).c_str() );
		char *name, *lengthStr, *pseudoCountStr;
		name = strtok( lineStr, " \t" );
		lengthStr = strtok( NULL, " \t" );
		pseudoCountStr = strtok( NULL, " \t" );
		int length;
		double pseudoCount;
		if ( lengthStr ) length = atoi( lengthStr );
		else { return INPUT_ERROR; }
		if ( pseudoCountStr ) pseudoCount = atof( pseudoCountStr );
		else pseudoCount = 0;
		
		// read the count matrix
		Matrix countMat( length, NBASES );
		for ( int i = 0; i < length; ++i ) {
			for ( int j = 0; j < NBASES; ++j ) {
				fin >> countMat( i, j );
			}	
		}
		
		// create the motif
		names.push_back( string( name ) );
		motifs.push_back( Motif( countMat, pseudoCount ) );
		
	} while ( !fin.eof() );
					
	return 0;
}

int IO::readMotifs( const string& file, vector< Motif >& motifs, int format )
{
	vector< string > names;
	return readMotifs( file, motifs, names, format );	
}

int IO::readMotifs( const string& file, const vector< double >& background, vector< TfbsMotif >& motifs, vector< string >& names, int format )
{
	vector< Motif > preMotifs;
	int rval = readMotifs( file, preMotifs, names, format );
	if ( rval == INPUT_ERROR ) return rval;
	motifs.clear();
	for ( int i = 0; i < preMotifs.size(); i++ ) {
		motifs.push_back( TfbsMotif( preMotifs[ i ].getPwm(), background ) );
	}
	
	return rval;	
}

int IO::readMotifs( const string& file, const vector< double >& background, vector< TfbsMotif >& motifs, int format )
{
	vector< string > names;
	return readMotifs( file, background, motifs, names, format );	
}

/*
// output vector< T >
template< class T >
ostream& operator<<( ostream& os, const vector< T >& v )
{
	if ( !v.empty() ) os << v[ 0 ];
	for ( int i = 1; i < v.size(); i++ ) {
		os << vector_delimiter << v[ i ];
	}
	
	return os;	
}

// output map< T1, T2 >
template< class T1, class T2 >
ostream& operator<<( ostream& os, const map< T1, T2 >& table )
{
	class map< T1, T2 >::const_iterator it;
	for ( it = table.begin(); it != table.end(); it++ ) { 
		os << it->first << IO_Ctrl::field_separator << it->second << IO_Ctrl::map_delimiter;    
	}

	return os;
}
*/
