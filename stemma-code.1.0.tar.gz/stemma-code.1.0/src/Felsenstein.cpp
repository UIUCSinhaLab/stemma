// Felsenstein.cpp: implementation of the Felsenstein algorithm class.
//
//////////////////////////////////////////////////////////////////////

#include "Felsenstein.h"

Felsenstein::Felsenstein(const PhyloTree &pt, const vector< Indel > &idls, const vector< TfbsMotif > &mots, const vector< Sequence > &seqs
		, const DynamicArray<SubstModel *> &motifModels, SubstModel* ncrmModel
		, const vector< double > &Lambda, const vector< double > &Mu
		, const int stateHistMode, const int stateSwitchMode)
		: indels(idls), sequences(seqs)
		, lambda(Lambda), mu(Mu)
		, StateHistAprxMode(stateHistMode), StateSwitchAprxMode(stateSwitchMode)
{
	this->mNumOfNodes = idls.size();
	this->motifLen.push_back(1);
	this->mConservedBranchProb.push_back(vector< double *** >(1, NULL));
	this->mGainBranchProb.push_back(vector< double *** >(1, NULL));
	this->mLossBranchProb.push_back(vector< double *** >(1, NULL));
	for (int i=0; i<mots.size(); ++i)
	{
		int len = mots[i].length();
		this->motifLen.push_back(len);
		this->mConservedBranchProb.push_back(vector< double *** >(len, NULL));
		this->mGainBranchProb.push_back(vector< double *** >(len, NULL));
		this->mLossBranchProb.push_back(vector< double *** >(len, NULL));
	}

	this->InitBranchCells(Lambda[0], pt, motifModels, ncrmModel);

	this->cmptCrmBranchProb_conserved();
	this->cmptCrmBranchProb_turnover();

	this->cmptOmega();

	switch(this->StateHistAprxMode)
	{
	case 0: // background only
		this->StateHists.clear();
		break;
	case 1:	// conserved only
		this->cmptStateHists_1();
		break;
	case 2:	// at most one event + oneapproximate history
		this->cmptStateHists_2();
		break;
	case 3: // only the approximate history
		this->cmptStateHists_3();
		break;
	default:
		cerr << "Undefined StateHistAprxMode=" << this->StateHistAprxMode<<endl;
		exit(FELSEN_ERROR);
	}

	this->cmptValidBranchCols();

	switch(this->StateSwitchAprxMode)
	{
	case 2: // t'=t/2
		this->cmptCrmBlockProbFuncPtr = &Felsenstein::cmptCrmBlockProb_2;
		this->printCrmBlockProbFuncPtr = &Felsenstein::printCrmBlockProb_2;
		break;
	case 3: // t'=0
		this->cmptCrmBlockProbFuncPtr = &Felsenstein::cmptCrmBlockProb_3;
		this->printCrmBlockProbFuncPtr = &Felsenstein::printCrmBlockProb_3;
		break;
	default:
		cerr << "Undefined StateSwitchAprxMode=" << this->StateSwitchAprxMode<<endl;
		exit(FELSEN_ERROR);
	}

	return;
}

Felsenstein::Felsenstein(bool *** tfbsPos, const PhyloTree &pt, const vector< Indel > &idls, const vector< TfbsMotif > &mots, const vector< Sequence > &seqs
		, const DynamicArray<SubstModel *> &motifModels, SubstModel* ncrmModel
		, const vector< double > &Lambda, const vector< double > &Mu
		, const int stateHistMode, const int stateSwitchMode)
		: TfbsPositions(tfbsPos)
		, indels(idls), sequences(seqs)
		, lambda(Lambda), mu(Mu)
		, StateHistAprxMode(stateHistMode), StateSwitchAprxMode(stateSwitchMode)
{
	this->mNumOfNodes = idls.size();
	this->motifLen.push_back(1);
	this->mConservedBranchProb.push_back(vector< double *** >(1, NULL));
	this->mGainBranchProb.push_back(vector< double *** >(1, NULL));
	this->mLossBranchProb.push_back(vector< double *** >(1, NULL));
	for (int i=0; i<mots.size(); ++i)
	{
		int len = mots[i].length();
		this->motifLen.push_back(len);
		this->mConservedBranchProb.push_back(vector< double *** >(len, NULL));
		this->mGainBranchProb.push_back(vector< double *** >(len, NULL));
		this->mLossBranchProb.push_back(vector< double *** >(len, NULL));
	}

	this->InitBranchCells(Lambda[0], pt, motifModels, ncrmModel);

	this->cmptCrmBranchProb_conserved();
	this->cmptCrmBranchProb_turnover();

	this->cmptOmega();

	switch(this->StateHistAprxMode)
	{
	case 0: // background only
		this->StateHists.clear();
		break;
	case 1:	// conserved only
		this->cmptStateHists_1();
		break;
	case 2:	// at most one event
		this->cmptStateHists_2();
		break;
	case 3: // only the approximate history
		this->cmptStateHists_3();
		break;
	default:
		cerr << "Undefined StateHistAprxMode=" << this->StateHistAprxMode<<endl;
		exit(FELSEN_ERROR);
	}

	this->cmptValidBranchCols();

	switch(this->StateSwitchAprxMode)
	{
	case 2: // t'=t/2
		this->cmptCrmBlockProbFuncPtr = &Felsenstein::cmptCrmBlockProb_2;
		this->printCrmBlockProbFuncPtr = &Felsenstein::printCrmBlockProb_2;
		break;
	case 3: // t'=0
		this->cmptCrmBlockProbFuncPtr = &Felsenstein::cmptCrmBlockProb_3;
		this->printCrmBlockProbFuncPtr = &Felsenstein::printCrmBlockProb_3;
		break;
	default:
		cerr << "Undefined StateSwitchAprxMode=" << this->StateSwitchAprxMode<<endl;
		exit(FELSEN_ERROR);
	}

	return;
}

Felsenstein::~Felsenstein()
{
	delete [] this->mBranchData;
	delete [] this->mBranchParam;

	for (int i=0; i<this->motifLen.size(); ++i)
	{
		for (int j=0; j<this->motifLen[i]; ++j)
		{
			for (int n=0; n<this->mNumOfNodes-1; ++n)
			{
				for(int nt=0; nt<NBASES; ++nt)
					delete [] this->mConservedBranchProb[i][j][n][nt];
				delete [] this->mConservedBranchProb[i][j][n];
			}
			delete [] this->mConservedBranchProb[i][j];
		}
	}
	this->mConservedBranchProb.clear();
	
	for (int i=1; i<this->motifLen.size(); ++i)
	{
		for (int j=0; j<this->motifLen[i]; ++j)
		{
			for (int n=0; n<this->mNumOfNodes-1; ++n)
			{
				for(int nt=0; nt<NBASES; ++nt)
				{
					delete [] this->mGainBranchProb[i][j][n][nt];
					delete [] this->mLossBranchProb[i][j][n][nt];
				}
				delete [] this->mGainBranchProb[i][j][n];
				delete [] this->mLossBranchProb[i][j][n];
			}
			delete [] this->mGainBranchProb[i][j];
			delete [] this->mLossBranchProb[i][j];
		}
	}
	this->mGainBranchProb.clear();
	this->mLossBranchProb.clear();

	this->BranchValidCols.clear();
	this->omega.clear();
	this->motifLen.clear();
	this->cacheStateHistProb.clear();
	this->StateHists.clear();
	
	return;
}

void Felsenstein::loadSequence(const PhyloTree &pt, const vector< Indel > &idls, const vector< Sequence > &seqs)
{
	assert(this->mNumOfNodes == idls.size());
	
	this->sequences.clear();
	this->indels.clear();
	
	this->sequences = seqs;
	this->indels = idls;
	this->updateBranchCells_seqIndex(pt);
	this->cmptValidBranchCols();

	return;
}

void Felsenstein::loadSequence(bool *** tfbsPos, const PhyloTree &pt, const vector< Indel > &idls, const vector< Sequence > &seqs)
{
	assert(this->mNumOfNodes == idls.size());
	
	this->sequences.clear();
	this->indels.clear();
	
	this->sequences = seqs;
	this->indels = idls;
	this->updateBranchCells_seqIndex(pt);
	this->cmptValidBranchCols();

	this->TfbsPositions = tfbsPos;

	return;
}

void Felsenstein::updateBranchCells_seqIndex(const PhyloTree &pt)
{
	PhyloTree::Node *root = pt.getRoot();

	int curIndex = this->mNumOfNodes -1;
	this->mBranchData[curIndex].seqIndex = root->getSeqInd();

	if (root->children.size())
	{
		for (vector<PhyloTree::Node *>::const_iterator it = root->children.begin(); it != root->children.end(); ++it)
		{
			--curIndex;
			this->recUpdtBranchCell(curIndex, *it);
		}
	}
	return;
}

void Felsenstein::recUpdtBranchCell(int &index, const PhyloTree::Node *root)
{
	int curIndex = index;
	this->mBranchData[curIndex].seqIndex = root->getSeqInd();

	if (root->children.size())
	{
		for (vector<PhyloTree::Node *>::const_iterator it = root->children.begin(); it != root->children.end(); ++it)
		{
			--index;
			this->recUpdtBranchCell(index, *it);
		}
	}
	return;
}

void Felsenstein::InitBranchCells(const double lambda_o, const PhyloTree &pt, const DynamicArray< SubstModel* >& motifModels, SubstModel* ncrmModel)
{
	PhyloTree::Node *root = pt.getRoot();
	int num_states = motifModels.rows();
	int num_cols = motifModels.cols();
	this->mBranchData = new DataBranchCell[this->mNumOfNodes];
	this->mBranchParam = new ParBranchCell[this->mNumOfNodes];

	int curIndex = this->mNumOfNodes -1;
	this->mBranchData[curIndex].seqIndex = root->getSeqInd();
	this->mBranchData[curIndex].parentIndex = -1;
	Matrix piMatrix(NBASES, NBASES);
	piMatrix.setZero();
	for (int nt=0; nt<NBASES; ++nt)
	{
		piMatrix.setElement(nt, nt, log(ncrmModel->getPi()[nt]));
	}
	this->mBranchParam[curIndex].NcrmSubstProbMatrix = piMatrix;
	this->mBranchParam[curIndex].CrmSubstProbMatrix.resize(num_states, num_cols, Matrix(NBASES, NBASES));
	for (int k=0; k<num_states; ++k)
	{
		for (int j=0; j<num_cols; ++j)
		{
			if (motifModels[k][j])
			{
				for (int nt=0; nt<NBASES; ++nt)
				{
					piMatrix.setElement(nt, nt, log(motifModels[k][j]->getPi()[nt]));
				}
				this->mBranchParam[curIndex].CrmSubstProbMatrix[k][j] = piMatrix;
			}
		}
	}
	
	if (root->children.size())
	{
		int chdIndex = curIndex;
		for (vector<PhyloTree::Node *>::const_iterator it = root->children.begin(); it != root->children.end(); ++it)
		{
			--chdIndex;
			this->mBranchData[curIndex].childrenIndex.push_back(chdIndex);
			this->mBranchData[chdIndex].parentIndex = curIndex;
			this->recInitBranchCell(lambda_o, chdIndex, *it, motifModels, ncrmModel);
		}
	}
	return;
}

void Felsenstein::recInitBranchCell(const double lambda_o, int &index, const PhyloTree::Node *root, const DynamicArray<SubstModel *> &motifModels, SubstModel* ncrmModel)
{
	int curIndex = index;
	double branch_len = root->getBranchLength();
	this->mBranchData[curIndex].branchLen = branch_len;
	this->mBranchData[curIndex].seqIndex = root->getSeqInd();
	this->mBranchParam[curIndex].o2oSubstProb = 0.0 - lambda_o * branch_len;
	
	int num_states = motifModels.rows();
	int num_cols = motifModels.cols();
	this->mBranchParam[curIndex].CrmSubstProbMatrix.resize(num_states, num_cols, Matrix(NBASES,NBASES));
	this->mBranchParam[curIndex].NcrmSubstProbMatrix = Math::matrixLog(ncrmModel->compProbMatrix(branch_len));
	if (this->StateSwitchAprxMode == 2)
		this->mBranchParam[curIndex].CrmSubstProbMatrix_mid.resize(num_states, num_cols, Matrix(NBASES,NBASES));
	for (int k=0; k<num_states; ++k)
	{
		for (int j=0; j<num_cols; ++j)
		{
			if (motifModels[k][j])
			{
				this->mBranchParam[curIndex].CrmSubstProbMatrix[k][j] = Math::matrixLog(motifModels[k][j]->compProbMatrix(branch_len));
				if (this->StateSwitchAprxMode == 2)
					this->mBranchParam[curIndex].CrmSubstProbMatrix_mid[k][j] = Math::matrixLog(motifModels[k][j]->compProbMatrix(branch_len/2));
			}
		}
	}

	if (root->children.size())
	{
		for (vector<PhyloTree::Node *>::const_iterator it = root->children.begin(); it != root->children.end(); ++it)
		{
			--index;
			this->mBranchData[curIndex].childrenIndex.push_back(index);
			this->mBranchData[index].parentIndex = curIndex;
			this->recInitBranchCell(lambda_o, index, *it, motifModels, ncrmModel);
		}
	}
	return;
}

void Felsenstein::cmptOmega()
{
	int num_states = lambda.size();
	assert ( num_states == mu.size() );

	double denum = 0.0;
	this->omega.assign(num_states, 0.0);
	for (int k=0; k<num_states; ++k)
	{
		this->omega[k] = this->lambda[k] / this->mu[k];
		denum += this->omega[k];
	}
	for (int k=0; k<num_states; ++k)
	{
		this->omega[k] = log(this->omega[k] / denum);
	}

	return;
}

void Felsenstein::cmptStateHists_3()
{
	// all-zero
	this->StateHists.push_back(0);
	this->BranchStates.push_back(1<<(this->mNumOfNodes-1));

	this->cmptPartOfStateHistProb();

	return;
}

void Felsenstein::cmptStateHists_2()
{
	// Add histories with one all-one subtree rooted at each node
	BitMapOfStates * hists = new BitMapOfStates[this->mNumOfNodes];
	for (int i=0; i<this->mNumOfNodes; ++i)
	{
		hists[i] = 1 << i;
		for (int j=0; j<this->mBranchData[i].childrenIndex.size(); j++)
		{
			hists[i] += hists[this->mBranchData[i].childrenIndex[j]];
		}
	}
	
	// Add histories with one all-zero subtree rooted at each node
	BitMapOfStates max = hists[this->mNumOfNodes-1];
	for (int i=this->mNumOfNodes-1; i>=0; --i)
	{
		this->StateHists.push_back(max - hists[i]);
		this->BranchStates.push_back(1<<i);
		this->StateHists.push_back(hists[i]);
		this->BranchStates.push_back(1<<i);
	}
	delete [] hists;

	this->cmptPartOfStateHistProb();

	return;
}

void Felsenstein::cmptStateHists_1()
{
	// all-zero
	this->StateHists.push_back(0);
	// all-one
	BitMapOfStates max = 1 << (this->mNumOfNodes);
	this->StateHists.push_back(max - 1);
	this->BranchStates.push_back(1<<(this->mNumOfNodes-1));
	this->BranchStates.push_back(1<<(this->mNumOfNodes-1));

	this->cmptPartOfStateHistProb();

	return;
}

void Felsenstein::cmptPartOfStateHistProb_2()
{
	// Initialize the state hist prob vector
	int num_histories = this->StateHists.size();
	int num_states = this->omega.size();
	this->cacheStateHistProb.resize(num_states, num_histories, 0.0);

	// compute the total branch len for all state switch cases
	for (int i=0; i<this->mNumOfNodes; ++i)
	{
		int num_children = this->mBranchData[i].childrenIndex.size();
		if (num_children == 0) continue;
		for (int j=0; j<num_histories; ++j)
		{
			int headState = (this->isMotifState(i, j)) ? 2 : 0;
			for (int c=0; c<num_children; ++c)
			{
				int branchState = (this->isMotifState(this->mBranchData[i].childrenIndex[c], j)) ? (1+headState) : headState;
				double branch_len = this->mBranchData[this->mBranchData[i].childrenIndex[c]].branchLen;
				switch (branchState)
				{
				case k2k:	// k to k
					for(int k=1; k<num_states; ++k)
					{
						this->cacheStateHistProb[k][j] -= branch_len * this->mu[k];
					}
					break;
				case o2k:	// o to k
					for(int k=1; k<num_states; ++k)
					{
						this->cacheStateHistProb[k][j] += log(branch_len * this->lambda[k]) - this->mu[k]*branch_len*0.5;
					}
					break;
				case k2o:	// k to o
					for(int k=1; k<num_states; ++k)
					{
						this->cacheStateHistProb[k][j] += log(exp(branch_len*this->mu[k]) - 1) - this->mu[k]*branch_len*1.5;
					}
					break;
				}
			}
		}
	}

	return;
}

void Felsenstein::cmptPartOfStateHistProb_3()
{
	// Initialize the state hist prob vector
	int num_histories = this->StateHists.size();
	int num_states = this->omega.size();
	this->cacheStateHistProb.resize(num_states, num_histories, 0.0);

	// compute the total branch len for all state switch cases
	for (int i=0; i<this->mNumOfNodes; ++i)
	{
		int num_children = this->mBranchData[i].childrenIndex.size();
		if (num_children == 0) continue;
		for (int j=0; j<num_histories; ++j)
		{
			int headState = (this->isMotifState(i, j)) ? 2 : 0;
			for (int c=0; c<num_children; ++c)
			{
				int branchState = (this->isMotifState(this->mBranchData[i].childrenIndex[c], j)) ? (1+headState) : headState;
				double branch_len = this->mBranchData[this->mBranchData[i].childrenIndex[c]].branchLen;
				switch (branchState)
				{
				case k2k:	// k to k
					for(int k=1; k<num_states; ++k)
					{
						this->cacheStateHistProb[k][j] -= branch_len * this->mu[k];
					}
					break;
				case o2k:	// o to k
					for(int k=1; k<num_states; ++k)
					{
						this->cacheStateHistProb[k][j] += log(branch_len * this->lambda[k]) - this->mu[k]*branch_len;
					}
					break;
				case k2o:	// k to o
					for(int k=1; k<num_states; ++k)
					{
						this->cacheStateHistProb[k][j] += log(exp(branch_len*this->mu[k]) - 1) - this->mu[k]*branch_len;
					}
					break;
				}
			}
		}
	}

	return;
}

void Felsenstein::cmptPartOfStateHistProb()
{
	// compute the cached value for state history probs
	switch (this->StateSwitchAprxMode)
	{
	case 2:	// switch happens at the middle
		cmptPartOfStateHistProb_2();
		break;
	case 3:	// switch happens at the beginning
		cmptPartOfStateHistProb_3();
		break;
	default:
		cerr << "Undefined mode for state switch approximation: " << this->StateSwitchAprxMode <<endl;
		exit( FELSEN_ERROR );
	}
}

void Felsenstein::cmptValidBranchCols()
{	
	// compute cached values for valid branch columns
	int seq_length = this->indels[0].size();
	this->BranchValidCols.resize(this->mNumOfNodes-1, seq_length);
	for (int i=0; i<this->mNumOfNodes-1; ++i)
	{
		this->BranchValidCols[i].assign(seq_length, 0.0);
	}
	for (int i=0; i<this->mNumOfNodes; ++i)
	{
		int num_children = this->mBranchData[i].childrenIndex.size();
		if (num_children == 0) continue;
		int headInd = this->mBranchData[i].seqIndex;
		for (int c=0; c<num_children; ++c)
		{
			int cInd = this->mBranchData[i].childrenIndex[c];
			int tailInd = this->mBranchData[cInd].seqIndex;
			for( int n=0; n<seq_length; ++n)
			{
				if ( ! this->indels[headInd][n] && ! this->indels[tailInd][n] )
					this->BranchValidCols[cInd][n] = 1.0;
				else if ( ! this->indels[headInd][n] || ! this->indels[tailInd][n] )
					this->BranchValidCols[cInd][n] = 0.5;
			}
		}
	}
	/*int lastInd = this->mNumOfNodes-1;
	int rootInd = this->mBranchData[lastInd].seqIndex;
	for( int n=0; n<seq_length; ++n)
	{
		this->BranchValidCols[lastInd][n] = (this->indels[rootInd][n]) ? 0.0 : 1.0;
	}*/

	return;
}

inline bool Felsenstein::isMotifState(const int nodeInd, const int histInd) const
{
	return (this->StateHists[histInd] & (1 << nodeInd));
}

void Felsenstein::dumpStateHists(ostream &os) const
{
	for (vector<BitMapOfStates>::const_iterator it = this->StateHists.begin(); it != this->StateHists.end(); ++it)
	{
		this->dumpStateHist(os, *it);
		os << endl;
	}
}

void Felsenstein::dumpStateHist(ostream &os, BitMapOfStates value) const
{
	const int SHIFT = this->mNumOfNodes; // 8 * sizeof( BitMapOfStates );
	const BitMapOfStates MASK = 1 << (SHIFT-1);
	for ( int i = 1; i <= SHIFT; ++i ) 
	{
		os << ( value & MASK ? '1' : '0' );
		value <<= 1;
	}
}

double Felsenstein::cmptNcrmColProb(const int n) const
{
	double prob;

	double ** prob2sum = new double* [this->mNumOfNodes];
	int i=0;
	for (; i<this->mNumOfNodes-1; ++i)
	{
		double *  cur_prob2sum = new double[NBASES];
		int num_children = this->mBranchData[i].childrenIndex.size();
		if (num_children == 0)	// Leaf node
		{
			int curNT = this->sequences[this->mBranchData[i].seqIndex].getNt(n);
			if (curNT >= NBASES)	// N or -: missing data
			{
				for (int nt=0; nt<NBASES; ++nt)
					cur_prob2sum[nt] = 0.0;
			}
			else	// n.t.
			{
				for (int nt=0; nt<NBASES; ++nt)
					cur_prob2sum[nt] = this->mBranchParam[i].NcrmSubstProbMatrix.getElement(nt, curNT);
			}
		}
		else	// Internal node
		{
			for (int headNT=0; headNT<NBASES; ++headNT)
			{
				double tmp_prob2sum[NBASES];
				for (int tailNT=0; tailNT<NBASES; ++tailNT)
				{
					tmp_prob2sum[tailNT] = this->mBranchParam[i].NcrmSubstProbMatrix.getElement(headNT, tailNT);
					for (int c=0; c<num_children; ++c)
					{
						tmp_prob2sum[tailNT] += prob2sum[this->mBranchData[i].childrenIndex[c]][tailNT];
					}
				}
				cur_prob2sum[headNT] = LogAddAlgorithm::log_add(tmp_prob2sum, NBASES);
			}
		}
		prob2sum[i] = cur_prob2sum;
	}
	prob2sum[i] = new double[NBASES];
	for (int nt=0; nt<NBASES; ++nt)
	{
		prob2sum[i][nt] = this->mBranchParam[i].NcrmSubstProbMatrix.getElement(nt, nt);
		int num_children = this->mBranchData[i].childrenIndex.size();
		for (int c=0; c<num_children; ++c)
		{
			prob2sum[i][nt] += prob2sum[this->mBranchData[i].childrenIndex[c]][nt];
		}
	}

	prob = LogAddAlgorithm::log_add(prob2sum[i], NBASES);

	// free memory
	for(i=0; i<this->mNumOfNodes; ++i) delete [] prob2sum[i];
	delete [] prob2sum;

	return prob;
}

double Felsenstein::cmptCrmBlockProb_2(const int len, const int n, const int k) const
{
	double prob = GSL_NEGINF;
	if ( k == 0 )
	{
		assert(len==1);
		prob = this->cmptStateHistProb_2(len, n, 0, k);
		prob +=	this->cmptCrmColProbGivenSH_Bkg(n);
		return prob;
	}

	int ** BlockColIndex = new int* [len];
	for (int i=0; i<len; ++i)
	{
		BlockColIndex[i] = new int [this->mNumOfNodes];
	}
	for (int i=0; i<this->mNumOfNodes; ++i)
	{
		int motif_col = 0;
		int ind = this->mBranchData[i].seqIndex;
		for (int j=0; j<len; ++j)
		{
			if (this->indels[ind][n-len+1+j]) BlockColIndex[j][i] = -1;
			else BlockColIndex[j][i] = motif_col++;
		}
	}

	for (int i=1; i<this->StateHists.size(); ++i)
	{
		// First to check whether the given state history is consistent with the indel annotations.
		// i.e., the seq at state k should have nt length == motif_len[k]
		//		 the k->k branch should have the same indel annotation
		if ( ! this->isValidStateHist(len, n, this->StateHists[i], k) )
			continue;
		
		double shProb = this->cmptStateHistProb_2(len, n, i, k);
		shProb += this->cmptCrmBlockProbGivenSH(len,n,this->StateHists[i],this->BranchStates[i],k,BlockColIndex);
		prob = LogAddAlgorithm::log_add(prob, shProb);
	}

	// add one more history according to the PWMscan annotation: TfbsPositions
	if (this->StateHistAprxMode>=2 && k>0)
	{
		BitMapOfStates bmpST = TfbsAnt2ValidStateHist(len, n, k);
		if ( find(this->StateHists.begin(), this->StateHists.end(), bmpST) == this->StateHists.end())
		{
			BitMapOfStates bmpBH = this->StateHist2BranchState(bmpST);
			double shProb = this->cmptFullStateHistProb_2(len, n, bmpST, k);
			shProb += this->cmptCrmBlockProbGivenSH(len,n,bmpST,bmpBH,k,BlockColIndex);
			prob = LogAddAlgorithm::log_add(prob, shProb);
		}
	}
	
	// free memory
	for (int i=0; i<len; i++)
	{
		delete [] BlockColIndex[i];
	}
	delete [] BlockColIndex;

	return prob;
}

double Felsenstein::cmptCrmBlockProb_3(const int len, const int n, const int k) const
{
	double prob = GSL_NEGINF;
	if ( k == 0 )
	{
		assert(len==1);
		prob = this->cmptStateHistProb_3(len, n, 0, k);
		prob +=	this->cmptCrmColProbGivenSH_Bkg(n);
		return prob;
	}

	int ** BlockColIndex = new int* [len];
	for (int i=0; i<len; ++i)
	{
		BlockColIndex[i] = new int [this->mNumOfNodes];
	}
	for (int i=0; i<this->mNumOfNodes; ++i)
	{
		int motif_col = 0;
		int ind = this->mBranchData[i].seqIndex;
		for (int j=0; j<len; ++j)
		{
			if (this->indels[ind][n-len+1+j]) BlockColIndex[j][i] = -1;
			else BlockColIndex[j][i] = motif_col++;
		}
	}

	for (int i=1; i<this->StateHists.size(); ++i)
	{
		// First to check whether the given state history is consistent with the indel annotations.
		// i.e., the seq at state k should have nt length == motif_len[k]
		//		 the k->k branch should have the same indel annotation
		if ( ! this->isValidStateHist(len, n, this->StateHists[i], k) )
			continue;

		double shProb = this->cmptStateHistProb_3(len, n, i, k);
		shProb += this->cmptCrmBlockProbGivenSH(len,n,this->StateHists[i],this->BranchStates[i],k,BlockColIndex);
		prob = LogAddAlgorithm::log_add(prob, shProb);
	}
	// add one more history according to the PWMscan annotation: TfbsPositions
	if (this->StateHistAprxMode>=2 && k>0)
	{
		BitMapOfStates bmpST = TfbsAnt2ValidStateHist(len, n, k);
		if ( find(this->StateHists.begin(), this->StateHists.end(), bmpST) == this->StateHists.end())
		{
			BitMapOfStates bmpBH = this->StateHist2BranchState(bmpST);
			double shProb = this->cmptFullStateHistProb_3(len, n, bmpST, k);
			shProb += this->cmptCrmBlockProbGivenSH(len,n,bmpST,bmpBH,k,BlockColIndex);
			prob = LogAddAlgorithm::log_add(prob, shProb);
		}
	}

	// free memory
	for (int i=0; i<len; i++)
	{
		delete [] BlockColIndex[i];
	}
	delete [] BlockColIndex;

	return prob;
}

double Felsenstein::printCrmBlockProb_2(ostream &os, const int len, const int n, const int k) const
{
	double prob = GSL_NEGINF;
	if ( k == 0 )
	{
		assert(len==1);
		os << "0:\t";
		this->dumpStateHist(os, this->StateHists[0]);
		prob = this->cmptStateHistProb_2(len, n, 0, k);
		os << "\t" << prob;
		double tmp_prob = this->cmptCrmColProbGivenSH_Bkg(n);
		os << "\t" << tmp_prob;
		prob +=	tmp_prob;
		os << "\t" << prob << endl;
		return prob;
	}

	int ** BlockColIndex = new int* [len];
	for (int i=0; i<len; ++i)
	{
		BlockColIndex[i] = new int [this->mNumOfNodes];
	}
	for (int i=0; i<this->mNumOfNodes; ++i)
	{
		int motif_col = 0;
		int ind = this->mBranchData[i].seqIndex;
		for (int j=0; j<len; ++j)
		{
			if (this->indels[ind][n-len+1+j]) BlockColIndex[j][i] = -1;
			else BlockColIndex[j][i] = motif_col++;
		}
	}

	for (int i=1; i<this->StateHists.size(); ++i)
	{
		// First to check whether the given state history is consistent with the indel annotations.
		// i.e., the seq at state k should have nt length == motif_len[k]
		//		 the k->k branch should have the same indel annotation
		if ( ! this->isValidStateHist(len, n, this->StateHists[i], k) )
			continue;

		os << i << ":\t";
		this->dumpStateHist(os, this->StateHists[i]);
		double shProb = this->cmptStateHistProb_2(len, n, i, k);
		os << "\t" << shProb;
		double tmp_prob = this->cmptCrmBlockProbGivenSH(len,n,this->StateHists[i],this->BranchStates[i],k,BlockColIndex);
		os << "\t" << tmp_prob;
		shProb += tmp_prob;
		os << "\t" << shProb << endl;
		prob = LogAddAlgorithm::log_add(prob, shProb);
	}
	// add one more history according to the PWMscan annotation: TfbsPositions
	if (this->StateHistAprxMode>=2 && k>0)
	{
		BitMapOfStates bmpST = TfbsAnt2ValidStateHist(len, n, k);
		if ( find(this->StateHists.begin(), this->StateHists.end(), bmpST) == this->StateHists.end())
		{
			BitMapOfStates bmpBH = this->StateHist2BranchState(bmpST);
			os << "add:\t";
			this->dumpStateHist(os, bmpST);
			double shProb = this->cmptFullStateHistProb_2(len, n, bmpST, k);
			os << "\t" << shProb;
			double tmp_prob = this->cmptCrmBlockProbGivenSH(len,n,bmpST,bmpBH,k,BlockColIndex);
			os << "\t" << tmp_prob;
			shProb += tmp_prob;
			os << "\t" << shProb << endl;
			prob = LogAddAlgorithm::log_add(prob, shProb);
		}
	}

	// free memory
	for (int i=0; i<len; i++)
	{
		delete [] BlockColIndex[i];
	}
	delete [] BlockColIndex;
	
	return prob;
}

double Felsenstein::printCrmBlockProb_3(ostream &os, const int len, const int n, const int k) const
{
	double prob = GSL_NEGINF;
	if ( k == 0 )
	{
		assert(len==1);
		os << "0:\t";
		this->dumpStateHist(os, this->StateHists[0]);
		prob = this->cmptStateHistProb_3(len, n, 0, k);
		os << "\t" << prob;
		double tmp_prob = this->cmptCrmColProbGivenSH_Bkg(n);
		os << "\t" << tmp_prob;
		prob +=	tmp_prob;
		os << "\t" << prob << endl;
		return prob;
	}

	int ** BlockColIndex = new int* [len];
	for (int i=0; i<len; ++i)
	{
		BlockColIndex[i] = new int [this->mNumOfNodes];
	}
	for (int i=0; i<this->mNumOfNodes; ++i)
	{
		int motif_col = 0;
		int ind = this->mBranchData[i].seqIndex;
		for (int j=0; j<len; ++j)
		{
			if (this->indels[ind][n-len+1+j]) BlockColIndex[j][i] = -1;
			else BlockColIndex[j][i] = motif_col++;
		}
	}

	for (int i=1; i<this->StateHists.size(); ++i)
	{
		// First to check whether the given state history is consistent with the indel annotations.
		// i.e., the seq at state k should have nt length == motif_len[k]
		//		 the k->k branch should have the same indel annotation
		if ( ! this->isValidStateHist(len, n, this->StateHists[i], k) )
			continue;

		os << i << ":\t";
		this->dumpStateHist(os, this->StateHists[i]);
		double shProb = this->cmptStateHistProb_3(len, n, i, k);
		os << "\t" << shProb;
		double tmp_prob = this->cmptCrmBlockProbGivenSH(len,n,this->StateHists[i],this->BranchStates[i],k,BlockColIndex);
		os << "\t" << tmp_prob;
		shProb += tmp_prob;
		os << "\t" << shProb << endl;
		prob = LogAddAlgorithm::log_add(prob, shProb);
	}
	// add one more history according to the PWMscan annotation: TfbsPositions
	if (this->StateHistAprxMode>=2 && k>0)
	{
		BitMapOfStates bmpST = TfbsAnt2ValidStateHist(len, n, k);
		if ( find(this->StateHists.begin(), this->StateHists.end(), bmpST) == this->StateHists.end())
		{
			BitMapOfStates bmpBH = this->StateHist2BranchState(bmpST);
			os << "add:\t";
			this->dumpStateHist(os, bmpST);
			double shProb = this->cmptFullStateHistProb_3(len, n, bmpST, k);
			os << "\t" << shProb;
			double tmp_prob = this->cmptCrmBlockProbGivenSH(len,n,bmpST,bmpBH,k,BlockColIndex);
			os << "\t" << tmp_prob;
			shProb += tmp_prob;
			os << "\t" << shProb << endl;
			prob = LogAddAlgorithm::log_add(prob, shProb);
		}
	}

	// free memory
	for (int i=0; i<len; i++)
	{
		delete [] BlockColIndex[i];
	}
	delete [] BlockColIndex;
	
	return prob;
}

inline BitMapOfStates Felsenstein::TfbsAnt2ValidStateHist(const int len, const int n, const int k) const
{
	BitMapOfStates rtn = 0;
	int motif_len = this->motifLen[k];
	for (int i=0; i<this->mNumOfNodes; ++i)
	{
		int num_children = this->mBranchData[i].childrenIndex.size();
		int ind = this->mBranchData[i].seqIndex;
		if (num_children == 0)
		{
			// (3) the seq at state k should have strong binding energy
			if (this->TfbsPositions[k][ind][n])
			{
				// (1) the seq at state k should have nt length == motif_len[k]
				/*int nt_length = 0;
				for (int j=n-len+1; j<=n; ++j)
				{
					if (! this->indels[ind][j]) ++nt_length;
				}
				if ( nt_length == motif_len ) rtn += (1 << i);
				*/
				if ( this->indels[ind].countNts(len, n) == motif_len ) rtn += (1 << i);
			}
		}
		else
		{
			bool flag = false;
			for (int c=0; c<num_children; ++c)
			{
				int cInd = this->mBranchData[i].childrenIndex[c];
				if ( rtn & (1 << cInd) )
				{
					// (2) the k->k branch should have the same indel annotation     
					int cSeqInd = this->mBranchData[cInd].seqIndex;
					int j=n-len+1;
					for (; j<=n; ++j)
					{
						if (this->indels[ind][j] != this->indels[cSeqInd][j]) break;
					}
					if(j>n) flag = true;
					else { flag = false; break; }
				}
			}
			if (flag) rtn += (1 << i);
		}
	}
	return rtn;
}

inline BitMapOfStates Felsenstein::StateHist2BranchState(BitMapOfStates st) const
{
	BitMapOfStates rtn = 0;
	for (int i=this->mNumOfNodes-1; i>=0; --i)
	{
		int num_children = this->mBranchData[i].childrenIndex.size();
		if (num_children > 0)	// Internal node
		{
			for (int c=0; c<num_children; ++c)
			{
				int cInd = this->mBranchData[i].childrenIndex[c];
				if ( ((st & (1 << i)) >> i) != ((st & (1 << cInd)) >> cInd) )
					rtn += 1 << cInd;
			}
		}
	}
	
	return rtn;
}

double Felsenstein::cmptStateHistProb_2(const int len, const int n, const int stInd, const int k) const
{
	double prob = 0.0;
	
	// Compute column related prob
	for (int i=0; i<this->mNumOfNodes; ++i)
	{
		int num_children = this->mBranchData[i].childrenIndex.size();
		if (num_children > 0)	// Internal node
		{
			int headState = (this->isMotifState(i, stInd)) ? 2 : 0;
			for (int c=0; c<num_children; ++c)
			{
				int cInd = this->mBranchData[i].childrenIndex[c];
				int branchState = (this->isMotifState(cInd, stInd)) ? (1+headState) : headState;
				if (branchState == k2k) continue;

				double validCols = 0.0;
				for (int ind=n-len+1; ind<=n; ++ind) validCols += this->BranchValidCols[cInd][ind];
				switch (branchState)
				{
				case o2k:	// o->k
					prob += validCols * this->mBranchParam[cInd].o2oSubstProb / 2.0;
					break;
				case k2o:	// k->o
					prob += validCols * this->mBranchParam[cInd].o2oSubstProb / 2.0;
					break;
				case o2o:	// o->o
					prob += validCols * this->mBranchParam[cInd].o2oSubstProb;
					break;
				}
			}
		}
	}

	// Compute the root node emit prob
	int lastInd = this->mNumOfNodes - 1;
	if (this->isMotifState(lastInd, stInd))
	{
		prob += this->omega[k];
	}
	else
	{
		//double nt_length = 0.0;
		//for (int ind=n-len+1; ind<=n; ++ind) nt_length += this->BranchValidCols[lastInd][ind];
		double nt_length = (double) this->indels[this->mBranchData[lastInd].seqIndex].countNts(len, n);
		prob += nt_length * this->omega[0];
	}

	// multiply the cached value of part of the state history prob
	prob += this->cacheStateHistProb[k][stInd];

	return prob;
}

double Felsenstein::cmptStateHistProb_3(const int len, const int n, const int stInd, const int k) const
{
	double prob = 0.0;

	// Compute column related prob
	for (int i=0; i<this->mNumOfNodes; ++i)
	{
		int num_children = this->mBranchData[i].childrenIndex.size();
		if (num_children > 0)	// Internal node
		{
			for (int c=0; c<num_children; ++c)
			{
				int cInd = this->mBranchData[i].childrenIndex[c];
				// k->k, o->k
				if (this->isMotifState(cInd, stInd)) continue;
				// o->o, k->o
				double validCols = 0.0;
				for (int ind=n-len+1; ind<=n; ++ind) validCols += this->BranchValidCols[cInd][ind];
				prob += validCols * this->mBranchParam[cInd].o2oSubstProb;
			}
		}
	}
	// Compute the root node emit prob
	int lastInd = this->mNumOfNodes-1;
	if (this->isMotifState(lastInd, stInd))
	{
		prob += this->omega[k];
	}
	else
	{
		//double nt_length = 0.0;
		//for (int ind=n-len+1; ind<=n; ++ind) nt_length += this->BranchValidCols[lastInd][ind];
		double nt_length = (double) this->indels[this->mBranchData[lastInd].seqIndex].countNts(len, n);
		prob += nt_length * this->omega[0];
	}

	// Multiply the cached value of part of the state history prob
	prob += this->cacheStateHistProb[k][stInd];

	return prob;
}

// Check whether the given state history is consistent with the indel annotations.
// (1) the seq at state k should have nt length == motif_len[k]
// (2) the k->k branch should have the same indel annotation
// (3) the seq at state k should have strong binding energy
bool Felsenstein::isValidStateHist(const int len, const int n, BitMapOfStates stateHist, const int k) const
{
	int motif_len = this->motifLen[k];
	int * states = new int[this->mNumOfNodes];
	for (int i=0; i<this->mNumOfNodes; ++i)
	{
		states[i] = stateHist & (1<<i);
		if (states[i])
		{
			int ind = this->mBranchData[i].seqIndex;
			int num_children = this->mBranchData[i].childrenIndex.size();
			if (num_children == 0)	// Leaf node
			{
				// (3) the seq at state k should have strong binding energy
				if (this->TfbsPositions && ! this->TfbsPositions[k][ind][n]) return false;				
				// (1) the seq at state k should have nt length == motif_len[k]
				/*int nt_length = 0;
				for (int j=n-len+1; j<=n; ++j)
				{
					if (! this->indels[ind][j]) ++nt_length;
				}
				if ( nt_length != motif_len ) return false;
				*/
				if ( this->indels[ind].countNts(len, n) != motif_len ) return false;
			}
			else
			{
				for (int c=0; c<num_children; ++c)
				{
					int cInd = this->mBranchData[i].childrenIndex[c];
					if (states[cInd] == 0)
					{
						// (1) the seq at state k should have nt length == motif_len[k]
						/*int nt_length = 0;
						for (int j=n-len+1; j<=n; ++j)
						{
							if (! this->indels[ind][j]) ++nt_length;
						}
						if ( nt_length != motif_len ) return false;
						*/
						if ( this->indels[ind].countNts(len, n) != motif_len ) return false;
					}
					else
					{
						// (2) the k->k branch should have the same indel annotation     
						int cSeqInd = this->mBranchData[cInd].seqIndex;
						for (int j=n-len+1; j<=n; ++j)
						{
							if (this->indels[ind][j] != this->indels[cSeqInd][j]) return false;
						}
					}
				}
			}
		}
	}
	
	delete [] states;

	return true;
}

double Felsenstein::cmptCrmBlockProbGivenSH_2(const int len, const int n, BitMapOfStates stateHist, BitMapOfStates branchState, const int k, int ** motifColInd) const
{
	double prob = 0;
	if (k==0)
	{
		assert(stateHist == 0);
		assert(len == 1);
		prob = this->cmptCrmColProbGivenSH_2(n,stateHist,branchState,k,motifColInd[0]);
		return prob;
	}
	
	for(int i=0; i<len; i++)
	{
		prob += this->cmptCrmColProbGivenSH_2(n-len+1+i,stateHist,branchState,k,motifColInd[i]);
	}	
	return prob;
}

double Felsenstein::cmptCrmBlockProbGivenSH_3(const int len, const int n, BitMapOfStates stateHist, BitMapOfStates branchState, const int k, int ** motifColInd) const
{
	double prob = 0;
	if (k==0)
	{
		assert(stateHist == 0);
		assert(len == 1);
		prob = this->cmptCrmColProbGivenSH_3(n,stateHist,branchState,k,motifColInd[0]);
		return prob;
	}
	
	for(int i=0; i<len; i++)
	{
		prob += this->cmptCrmColProbGivenSH_3(n-len+1+i,stateHist,branchState,k,motifColInd[i]);
	}	
	return prob;
}

// Compute and cache the conserved branch prob
void Felsenstein::cmptCrmBranchProb_conserved()
{
	for (int k=0; k<this->motifLen.size(); ++k)
	{
		for (int j=0; j<this->motifLen[k]; ++j)
		{
			// compute and cache the conserved branch prob for each motif
			this->mConservedBranchProb[k][j] = new double **[this->mNumOfNodes-1];
			for (int i=this->mNumOfNodes-1; i>=0; --i)
			{
				int num_children = this->mBranchData[i].childrenIndex.size();
				if (num_children > 0)
				{
					for (int c=0; c<num_children; ++c)
					{
						int cInd = this->mBranchData[i].childrenIndex[c];
						this->mConservedBranchProb[k][j][cInd] = cmptConservedBranchProb(k, j, cInd);
					}
				}
			}
		}
	}

	return;
}

// Compute and cache the turnover branch prob
void Felsenstein::cmptCrmBranchProb_turnover()
{
	for (int k=1; k<this->motifLen.size(); ++k)
	{
		for (int j=0; j<this->motifLen[k]; ++j)
		{
			// compute and cache the conserved branch prob for each motif
			this->mGainBranchProb[k][j] = new double **[this->mNumOfNodes-1];
			this->mLossBranchProb[k][j] = new double **[this->mNumOfNodes-1];
			for (int i=this->mNumOfNodes-1; i>=0; --i)
			{
				int num_children = this->mBranchData[i].childrenIndex.size();
				if (num_children > 0)
				{
					for (int c=0; c<num_children; ++c)
					{
						int cInd = this->mBranchData[i].childrenIndex[c];
						switch(this->StateSwitchAprxMode)
						{
						case 2:
							this->mGainBranchProb[k][j][cInd] = cmptTurnoverBranchProb_2(k, j, cInd, 1);
							this->mLossBranchProb[k][j][cInd] = cmptTurnoverBranchProb_2(k, j, cInd, 0);
							break;
						case 3:
							this->mGainBranchProb[k][j][cInd] = cmptTurnoverBranchProb_3(k, j, cInd, 1);
							this->mLossBranchProb[k][j][cInd] = cmptTurnoverBranchProb_3(k, j, cInd, 0);
							break;
						}
					}
				}
			}
		}
	}

	return;
}

inline double** Felsenstein::cmptConservedBranchProb(const int k, const int motifCol, const int cInd) const
{
	double ** branchProb = new double * [NBASES];
	if (motifCol==-1 || k==0)	// use CRM background evol model
	{
		for (int headNT=0; headNT<NBASES; ++headNT)
		{
			branchProb[headNT] = new double [NBASES];
			for (int tailNT=0; tailNT<NBASES; ++tailNT)
			{
				branchProb[headNT][tailNT] = this->mBranchParam[cInd].CrmSubstProbMatrix[0][0].getElement(headNT, tailNT);
			}
		}
	}
	else
	{
		for (int headNT=0; headNT<NBASES; ++headNT)
		{
			branchProb[headNT] = new double [NBASES];
			for (int tailNT=0; tailNT<NBASES; ++tailNT)
			{
				branchProb[headNT][tailNT] = this->mBranchParam[cInd].CrmSubstProbMatrix[k][motifCol].getElement(headNT, tailNT);
			}
		}
	}

	return branchProb;
}

inline double Felsenstein::cmptConservedBranchProb(const int k, const int motifCol, const int headNT, const int tailNT, const int cInd) const
{
	if (motifCol==-1 || k==0)	// use CRM background evol model
		return this->mBranchParam[cInd].CrmSubstProbMatrix[0][0].getElement(headNT, tailNT);
	else
		return this->mBranchParam[cInd].CrmSubstProbMatrix[k][motifCol].getElement(headNT, tailNT);
}

inline double** Felsenstein::cmptTurnoverBranchProb_2(const int k, const int motifCol, const int cInd, const int tailState) const
{
	double ** branchProb = new double * [NBASES];
	if (tailState)	//o2k
	{
		if (motifCol == -1)	// use CRM background evol model
		{
			for (int headNT=0; headNT<NBASES; ++headNT)
			{
				branchProb[headNT] = new double [NBASES];
				for (int tailNT=0; tailNT<NBASES; ++tailNT)
				{
					branchProb[headNT][tailNT] = this->mBranchParam[cInd].CrmSubstProbMatrix[0][0].getElement(headNT, tailNT);
				}
			}
		}
		else	// use CRM motif evol model
		{
			for (int headNT=0; headNT<NBASES; ++headNT)
			{
				branchProb[headNT] = new double [NBASES];
				for (int tailNT=0; tailNT<NBASES; ++tailNT)
				{
					double tmp_prob2sum[NBASES];
					for (int midNT=0; midNT<NBASES; ++midNT)
					{
						tmp_prob2sum[midNT] = this->mBranchParam[cInd].CrmSubstProbMatrix_mid[0][0].getElement(headNT, midNT);
						tmp_prob2sum[midNT] += this->mBranchParam[cInd].CrmSubstProbMatrix_mid[k][motifCol].getElement(midNT, tailNT);
					}
					branchProb[headNT][tailNT] = LogAddAlgorithm::log_add(tmp_prob2sum, NBASES);
				}
			}
		}
	}
	else	//k2o
	{
		if (motifCol == -1)	// use CRM background evol model
		{
			for (int headNT=0; headNT<NBASES; ++headNT)
			{
				branchProb[headNT] = new double [NBASES];
				for (int tailNT=0; tailNT<NBASES; ++tailNT)
				{
					branchProb[headNT][tailNT] = this->mBranchParam[cInd].CrmSubstProbMatrix[0][0].getElement(headNT, tailNT);
				}
			}
		}
		else	// use CRM motif evol model
		{
			for (int headNT=0; headNT<NBASES; ++headNT)
			{
				branchProb[headNT] = new double [NBASES];
				for (int tailNT=0; tailNT<NBASES; ++tailNT)
				{
					double tmp_prob2sum[NBASES];
					for (int midNT=0; midNT<NBASES; ++midNT)
					{
						tmp_prob2sum[midNT] = this->mBranchParam[cInd].CrmSubstProbMatrix_mid[k][motifCol].getElement(headNT, midNT);
						tmp_prob2sum[midNT] += this->mBranchParam[cInd].CrmSubstProbMatrix_mid[0][0].getElement(midNT, tailNT);
					}
					branchProb[headNT][tailNT] = LogAddAlgorithm::log_add(tmp_prob2sum, NBASES);
				}
			}
		}
	}

	return branchProb;
}


inline double Felsenstein::cmptTurnoverBranchProb_2(const int k, const int motifCol, const int headNT, const int tailNT, const int cInd, const int tailState) const
{
	if (tailState)	//o2k
	{
		if (motifCol == -1)	// use CRM background evol model
			return this->mBranchParam[cInd].CrmSubstProbMatrix[0][0].getElement(headNT, tailNT);
		else	// use CRM motif evol model
		{
			double tmp_prob2sum[NBASES];
			for (int midNT=0; midNT<NBASES; ++midNT)
			{
				tmp_prob2sum[midNT] = this->mBranchParam[cInd].CrmSubstProbMatrix_mid[0][0].getElement(headNT, midNT);
				tmp_prob2sum[midNT] += this->mBranchParam[cInd].CrmSubstProbMatrix_mid[k][motifCol].getElement(midNT, tailNT);
			}
			return LogAddAlgorithm::log_add(tmp_prob2sum, NBASES);
		}
	}
	else	//k2o
	{
		if (motifCol == -1)	// use CRM background evol model
			return this->mBranchParam[cInd].CrmSubstProbMatrix[0][0].getElement(headNT, tailNT);
		else	// use CRM motif evol model
		{
			double tmp_prob2sum[NBASES];
			for (int midNT=0; midNT<NBASES; ++midNT)
			{
				tmp_prob2sum[midNT] = this->mBranchParam[cInd].CrmSubstProbMatrix_mid[k][motifCol].getElement(headNT, midNT);
				tmp_prob2sum[midNT] += this->mBranchParam[cInd].CrmSubstProbMatrix_mid[0][0].getElement(midNT, tailNT);
			}
			return LogAddAlgorithm::log_add(tmp_prob2sum, NBASES);
		}
	}
}
	
inline double Felsenstein::cmptCrmColProbGivenSH_2(const int n, BitMapOfStates stateHist, BitMapOfStates branchState, const int k, int * motifColInd) const
{
	double prob;

	if (this->mNumOfNodes == 1)
	{
		int curNT = this->sequences[this->mBranchData[0].seqIndex].getNt(n);
		if (curNT < NBASES)	// n.t.
		{
			if (stateHist)
				prob = this->mBranchParam[0].CrmSubstProbMatrix[k][motifColInd[0]].getElement(curNT, curNT);
			else
				prob = this->mBranchParam[0].CrmSubstProbMatrix[0][0].getElement(curNT, curNT);
		}
		else
		{
			double prob2sum[NBASES];
			for (int nt=0; nt<NBASES; ++nt)
			{
				prob2sum[nt] = this->mBranchParam[0].CrmSubstProbMatrix[0][0].getElement(nt, nt);
			}
			prob = LogAddAlgorithm::log_add(prob2sum, NBASES);
		}
		return prob;
	}

	int i;
	double ** prob2sum = new double* [this->mNumOfNodes];
	for (i=0; i<this->mNumOfNodes-1; ++i)
	{
		double *  cur_prob2sum = NULL;
		int num_children = this->mBranchData[i].childrenIndex.size();
		int branch_state = branchState & (1<<i);
		int curState = stateHist & (1<<i);
		if (num_children == 0)	// Leaf node
		{
			int curNT = this->sequences[this->mBranchData[i].seqIndex].getNt(n);
			if (curNT < NBASES)	// n.t.
			{
				cur_prob2sum = new double[NBASES];
				if (branch_state)	//o2k, k2o
				{
					if (curState)	//o2k
					{
						for (int nt=0; nt<NBASES; ++nt)
							cur_prob2sum[nt] = cmptTurnoverBranchProb_2(k, motifColInd[i], nt, curNT, i, curState);
					}
					else	//k2o
					{
						if (motifColInd[this->mBranchData[i].parentIndex] == -1)
						{
							for (int nt=0; nt<NBASES; ++nt)
								cur_prob2sum[nt] = cmptConservedBranchProb(0, 0, nt, curNT, i);
						}
						else
						{
							for (int nt=0; nt<NBASES; ++nt)
								cur_prob2sum[nt] = cmptTurnoverBranchProb_2(k, motifColInd[this->mBranchData[i].parentIndex], nt, curNT, i, curState);
						}
					}
				}
				else
				{
					if (curState)	//k2k
					{
						for (int nt=0; nt<NBASES; ++nt)
							cur_prob2sum[nt] = cmptConservedBranchProb(k, motifColInd[i], nt, curNT, i);
					}
					else		//o2o
					{
						for (int nt=0; nt<NBASES; ++nt)
							cur_prob2sum[nt] = cmptConservedBranchProb(0, 0, nt, curNT, i);
					}
				}
			}
		}
		else	// Internal node
		{
			bool noMissing = false;
			for (int c=0; c<num_children; ++c)
			{
				if (prob2sum[this->mBranchData[i].childrenIndex[c]])
				{
					noMissing = true;
					break;
				}
			}
			if (noMissing)
			{
				cur_prob2sum = new double[NBASES];
				double ** branchProb;
				if (branch_state)	//o2k, k2o
				{
					if (curState)	//o2k
						branchProb = cmptTurnoverBranchProb_2(k, motifColInd[i], i, curState);
					else
						branchProb = cmptTurnoverBranchProb_2(k, motifColInd[this->mBranchData[i].parentIndex], i, curState);
				}
				else
				{
					if (curState)	//k2k
						branchProb = cmptConservedBranchProb(k, motifColInd[i], i);
					else		//o2o
						branchProb = cmptConservedBranchProb(0, 0, i);
				}
				for (int headNT=0; headNT<NBASES; ++headNT)
				{
					double tmp_prob2sum[NBASES];
					for (int tailNT=0; tailNT<NBASES; ++tailNT)
					{
						tmp_prob2sum[tailNT] = branchProb[headNT][tailNT];
						for (int c=0; c<num_children; ++c)
						{
							if(prob2sum[this->mBranchData[i].childrenIndex[c]])
								tmp_prob2sum[tailNT] += prob2sum[this->mBranchData[i].childrenIndex[c]][tailNT];
						}
					}
					cur_prob2sum[headNT] = LogAddAlgorithm::log_add(tmp_prob2sum, NBASES);
				}
				for (int headNT=0; headNT<NBASES; ++headNT) delete [] branchProb[headNT];
				delete [] branchProb;
			}
		}
		prob2sum[i] = cur_prob2sum;
	}
	
	prob2sum[i] = new double[NBASES];
	int headState = stateHist & (1<<i);
	for (int nt=0; nt<NBASES; ++nt)
	{
		if (headState && motifColInd[i] >= 0)
			prob2sum[i][nt] = this->mBranchParam[i].CrmSubstProbMatrix[k][motifColInd[i]].getElement(nt, nt);
		else
			prob2sum[i][nt] = this->mBranchParam[i].CrmSubstProbMatrix[0][0].getElement(nt, nt);
		int num_children = this->mBranchData[i].childrenIndex.size();
		for (int c=0; c<num_children; ++c)
		{
			if(prob2sum[this->mBranchData[i].childrenIndex[c]])
				prob2sum[i][nt] += prob2sum[this->mBranchData[i].childrenIndex[c]][nt];
		}
	}

	prob = LogAddAlgorithm::log_add(prob2sum[i], NBASES);

	// free memory
	for (i=0; i<this->mNumOfNodes; ++i) delete [] prob2sum[i];
	delete [] prob2sum;

	return prob;
}

inline double** Felsenstein::cmptTurnoverBranchProb_3(const int k, const int motifCol, const int cInd, const int tailState) const
{
	if(tailState)	//o2k ~= k2k
		return cmptConservedBranchProb(k, motifCol, cInd);
	else	//k2o ~= o2o
		return cmptConservedBranchProb(0, 0, cInd);
}


inline double Felsenstein::cmptTurnoverBranchProb_3(const int k, const int motifCol, const int headNT, const int tailNT, const int cInd, const int tailState) const
{
	if(tailState)	//o2k ~= k2k
		return cmptConservedBranchProb(k, motifCol, headNT, tailNT, cInd);
	else	//k2o ~= o2o
		return cmptConservedBranchProb(0, 0, headNT, tailNT, cInd);
}

inline double Felsenstein::cmptCrmColProbGivenSH_3(const int n, BitMapOfStates stateHist, BitMapOfStates branchState, const int k, int * motifColInd) const
{
	double prob;

	if (this->mNumOfNodes == 1)
	{
		int curNT = this->sequences[this->mBranchData[0].seqIndex].getNt(n);
		if (curNT < NBASES)	// n.t.
		{
			if (stateHist)
				prob = this->mBranchParam[0].CrmSubstProbMatrix[k][motifColInd[0]].getElement(curNT, curNT);
			else
				prob = this->mBranchParam[0].CrmSubstProbMatrix[0][0].getElement(curNT, curNT);
		}
		else
		{
			double prob2sum[NBASES];
			for (int nt=0; nt<NBASES; ++nt)
			{
				prob2sum[nt] = this->mBranchParam[0].CrmSubstProbMatrix[0][0].getElement(nt, nt);
			}
			prob = LogAddAlgorithm::log_add(prob2sum, NBASES);
		}
		return prob;
	}

	int i;
	double ** prob2sum = new double* [this->mNumOfNodes];
	for (i=0; i<this->mNumOfNodes-1; ++i)
	{
		double *  cur_prob2sum = NULL;
		int num_children = this->mBranchData[i].childrenIndex.size();
		int branch_state = branchState & (1<<i);
		int curState = stateHist & (1<<i);
		if (num_children == 0)	// Leaf node
		{
			int curNT = this->sequences[this->mBranchData[i].seqIndex].getNt(n);
			if (curNT < NBASES)	// n.t.
			{
				cur_prob2sum = new double[NBASES];
				if (branch_state)	//o2k, k2o
				{
					for (int nt=0; nt<NBASES; ++nt)
						cur_prob2sum[nt] = cmptTurnoverBranchProb_3(k, motifColInd[i], nt, curNT, i, curState);
				}
				else
				{
					if (curState)	//k2k
					{
						for (int nt=0; nt<NBASES; ++nt)
							cur_prob2sum[nt] = cmptConservedBranchProb(k, motifColInd[i], nt, curNT, i);
					}
					else		//o2o
					{
						for (int nt=0; nt<NBASES; ++nt)
							cur_prob2sum[nt] = cmptConservedBranchProb(0, 0, nt, curNT, i);
					}
				}
			}
		}
		else	// Internal node
		{
			bool noMissing = false;
			for (int c=0; c<num_children; ++c)
			{
				if (prob2sum[this->mBranchData[i].childrenIndex[c]])
				{
					noMissing = true;
					break;
				}
			}
			if (noMissing)
			{
				cur_prob2sum = new double[NBASES];
				double ** branchProb;
				if (branch_state)	//o2k, k2o
					branchProb = cmptTurnoverBranchProb_3(k, motifColInd[i], i, curState);
				else
				{
					if (curState)	//k2k
						branchProb = cmptConservedBranchProb(k, motifColInd[i], i);
					else		//o2o
						branchProb = cmptConservedBranchProb(0, 0, i);
				}
				for (int headNT=0; headNT<NBASES; ++headNT)
				{
					double tmp_prob2sum[NBASES];
					for (int tailNT=0; tailNT<NBASES; ++tailNT)
					{
						tmp_prob2sum[tailNT] = branchProb[headNT][tailNT];
						for (int c=0; c<num_children; ++c)
						{
							if(prob2sum[this->mBranchData[i].childrenIndex[c]])
								tmp_prob2sum[tailNT] += prob2sum[this->mBranchData[i].childrenIndex[c]][tailNT];
						}
					}
					cur_prob2sum[headNT] = LogAddAlgorithm::log_add(tmp_prob2sum, NBASES);
				}
				for (int headNT=0; headNT<NBASES; ++headNT) delete [] branchProb[headNT];
				delete [] branchProb;
			}
		}
		prob2sum[i] = cur_prob2sum;
	}
	
	prob2sum[i] = new double[NBASES];
	int headState = stateHist & (1<<i);
	for (int nt=0; nt<NBASES; ++nt)
	{
		if (headState && motifColInd[i] >= 0)
			prob2sum[i][nt] = this->mBranchParam[i].CrmSubstProbMatrix[k][motifColInd[i]].getElement(nt, nt);
		else
			prob2sum[i][nt] = this->mBranchParam[i].CrmSubstProbMatrix[0][0].getElement(nt, nt);
		int num_children = this->mBranchData[i].childrenIndex.size();
		for (int c=0; c<num_children; ++c)
		{
			if(prob2sum[this->mBranchData[i].childrenIndex[c]])
				prob2sum[i][nt] += prob2sum[this->mBranchData[i].childrenIndex[c]][nt];
		}
	}

	prob = LogAddAlgorithm::log_add(prob2sum[i], NBASES);

	// free memory
	for (i=0; i<this->mNumOfNodes; ++i) delete [] prob2sum[i];
	delete [] prob2sum;

	return prob;
}

inline double Felsenstein::cmptCrmColProbGivenSH_Bkg(const int n) const
{
	double prob;

	if (this->mNumOfNodes == 1)
	{
		int curNT = this->sequences[this->mBranchData[0].seqIndex].getNt(n);
		if (curNT < NBASES)	// n.t.
		{
			prob = this->mBranchParam[0].CrmSubstProbMatrix[0][0].getElement(curNT, curNT);
		}
		else
		{
			double prob2sum[NBASES];
			for (int nt=0; nt<NBASES; ++nt)
			{
				prob2sum[nt] = this->mBranchParam[0].CrmSubstProbMatrix[0][0].getElement(nt, nt);
			}
			prob = LogAddAlgorithm::log_add(prob2sum, NBASES);
		}
		return prob;
	}

	int i;
	double ** prob2sum = new double* [this->mNumOfNodes];
	for (i=0; i<this->mNumOfNodes-1; ++i)
	{
		double *  cur_prob2sum = NULL;
		int num_children = this->mBranchData[i].childrenIndex.size();
		if (num_children == 0)	// Leaf node
		{
			int curNT = this->sequences[this->mBranchData[i].seqIndex].getNt(n);
			if (curNT < NBASES)	// n.t.
			{
				cur_prob2sum = new double[NBASES];
				for (int nt=0; nt<NBASES; ++nt)
					cur_prob2sum[nt] = this->mConservedBranchProb[0][0][i][nt][curNT];
			}
		}
		else	// Internal node
		{
			bool noMissing = false;
			for (int c=0; c<num_children; ++c)
			{
				if (prob2sum[this->mBranchData[i].childrenIndex[c]])
				{
					noMissing = true;
					break;
				}
			}
			if (noMissing)
			{
				cur_prob2sum = new double[NBASES];
				for (int headNT=0; headNT<NBASES; ++headNT)
				{
					double tmp_prob2sum[NBASES];
					for (int tailNT=0; tailNT<NBASES; ++tailNT)
					{
						tmp_prob2sum[tailNT] = this->mConservedBranchProb[0][0][i][headNT][tailNT];
						for (int c=0; c<num_children; ++c)
						{
							if(prob2sum[this->mBranchData[i].childrenIndex[c]])
								tmp_prob2sum[tailNT] += prob2sum[this->mBranchData[i].childrenIndex[c]][tailNT];
						}
					}
					cur_prob2sum[headNT] = LogAddAlgorithm::log_add(tmp_prob2sum, NBASES);
				}
			}
		}
		prob2sum[i] = cur_prob2sum;
	}
	
	prob2sum[i] = new double[NBASES];
	for (int nt=0; nt<NBASES; ++nt)
	{
		prob2sum[i][nt] = this->mBranchParam[i].CrmSubstProbMatrix[0][0].getElement(nt, nt);
		int num_children = this->mBranchData[i].childrenIndex.size();
		for (int c=0; c<num_children; ++c)
		{
			if(prob2sum[this->mBranchData[i].childrenIndex[c]])
				prob2sum[i][nt] += prob2sum[this->mBranchData[i].childrenIndex[c]][nt];
		}
	}

	prob = LogAddAlgorithm::log_add(prob2sum[i], NBASES);

	// free memory
	for (i=0; i<this->mNumOfNodes; ++i) delete [] prob2sum[i];
	delete [] prob2sum;

	return prob;
}

inline double Felsenstein::cmptCrmColProbGivenSH_Motif(const int n, BitMapOfStates stateHist, BitMapOfStates branchState, const int k, int * motifColInd) const
{
	double prob;

	if (this->mNumOfNodes == 1)
	{
		int curNT = this->sequences[this->mBranchData[0].seqIndex].getNt(n);
		if (curNT < NBASES)	// n.t.
		{
			if (stateHist)
				prob = this->mBranchParam[0].CrmSubstProbMatrix[k][motifColInd[0]].getElement(curNT, curNT);
			else
				prob = this->mBranchParam[0].CrmSubstProbMatrix[0][0].getElement(curNT, curNT);
		}
		else
		{
			double prob2sum[NBASES];
			for (int nt=0; nt<NBASES; ++nt)
			{
				prob2sum[nt] = this->mBranchParam[0].CrmSubstProbMatrix[0][0].getElement(nt, nt);
			}
			prob = LogAddAlgorithm::log_add(prob2sum, NBASES);
		}
		return prob;
	}
	
	int i;
	double ** prob2sum = new double* [this->mNumOfNodes];
	for (i=0; i<this->mNumOfNodes-1; ++i)
	{
		double *  cur_prob2sum = NULL;
		int num_children = this->mBranchData[i].childrenIndex.size();
		int branch_state = branchState & (1<<i);
		int curState = stateHist & (1<<i);
		if (num_children == 0)	// Leaf node
		{
			int curNT = this->sequences[this->mBranchData[i].seqIndex].getNt(n);
			if (curNT < NBASES)	// n.t.
			{
				cur_prob2sum = new double[NBASES];
				if (branch_state)	// turnover
				{
					if  (curState)	// o2k
					{
						for (int nt=0; nt<NBASES; ++nt)
							cur_prob2sum[nt] = this->mGainBranchProb[k][motifColInd[i]][i][nt][curNT];
					}
					else	// k2o
					{
						if (motifColInd[this->mBranchData[i].parentIndex] == -1)
						{
							for (int nt=0; nt<NBASES; ++nt)
								cur_prob2sum[nt] = this->mConservedBranchProb[0][0][i][nt][curNT];
						}
						else
						{
							for (int nt=0; nt<NBASES; ++nt)
								cur_prob2sum[nt] = this->mLossBranchProb[k][motifColInd[this->mBranchData[i].parentIndex]][i][nt][curNT];
						}
					}
				}
				else	// no turnover
				{
					if (curState)	// k2k
					{
						for (int nt=0; nt<NBASES; ++nt)
							cur_prob2sum[nt] = this->mConservedBranchProb[k][motifColInd[i]][i][nt][curNT];
					}
					else	// o2o
					{
						for (int nt=0; nt<NBASES; ++nt)
							cur_prob2sum[nt] = this->mConservedBranchProb[0][0][i][nt][curNT];
					}
				}
			}
		}
		else	// Internal node
		{
			bool noMissing = false;
			for (int c=0; c<num_children; ++c)
			{
				if (prob2sum[this->mBranchData[i].childrenIndex[c]])
				{
					noMissing = true;
					break;
				}
			}
			if (noMissing)
			{
				cur_prob2sum = new double[NBASES];
				double ** branchProb;
				if (branch_state)	// turnover
				{
					if  (curState)	// o2k
					{
						if (motifColInd[i] == -1)
							branchProb = this->mConservedBranchProb[0][0][i];
						else
							branchProb = this->mGainBranchProb[k][motifColInd[i]][i];
					}
					else	// k2o
					{
						if (motifColInd[this->mBranchData[i].parentIndex] == -1)
							branchProb = this->mConservedBranchProb[0][0][i];
						else
							branchProb = this->mLossBranchProb[k][motifColInd[this->mBranchData[i].parentIndex]][i];
					}
				}
				else	// no turnover
				{
					if (curState && motifColInd[i] != -1)	//k2k
						branchProb = this->mConservedBranchProb[k][motifColInd[i]][i];
					else		//o2o
						branchProb = this->mConservedBranchProb[0][0][i];
				}
				for (int headNT=0; headNT<NBASES; ++headNT)
				{
					double tmp_prob2sum[NBASES];
					for (int tailNT=0; tailNT<NBASES; ++tailNT)
					{
						tmp_prob2sum[tailNT] = branchProb[headNT][tailNT];
						for (int c=0; c<num_children; ++c)
						{
							if(prob2sum[this->mBranchData[i].childrenIndex[c]])
								tmp_prob2sum[tailNT] += prob2sum[this->mBranchData[i].childrenIndex[c]][tailNT];
						}
					}
					cur_prob2sum[headNT] = LogAddAlgorithm::log_add(tmp_prob2sum, NBASES);
				}
			}
		}
		prob2sum[i] = cur_prob2sum;
	}
	
	prob2sum[i] = new double[NBASES];
	int headState = stateHist & (1<<i);
	for (int nt=0; nt<NBASES; ++nt)
	{
		if (headState && motifColInd[i] >= 0)
			prob2sum[i][nt] = this->mBranchParam[i].CrmSubstProbMatrix[k][motifColInd[i]].getElement(nt, nt);
		else
			prob2sum[i][nt] = this->mBranchParam[i].CrmSubstProbMatrix[0][0].getElement(nt, nt);
		int num_children = this->mBranchData[i].childrenIndex.size();
		for (int c=0; c<num_children; ++c)
		{
			if(prob2sum[this->mBranchData[i].childrenIndex[c]])
				prob2sum[i][nt] += prob2sum[this->mBranchData[i].childrenIndex[c]][nt];
		}
	}

	prob = LogAddAlgorithm::log_add(prob2sum[i], NBASES);

	// free memory
	for (i=0; i<this->mNumOfNodes; ++i) delete [] prob2sum[i];
	delete [] prob2sum;

	return prob;
}

double Felsenstein::cmptCrmBlockProbGivenSH(const int len, const int n, BitMapOfStates stateHist, BitMapOfStates branchState, const int k, int ** motifColInd) const
{
	double prob = 0;
	for(int i=0; i<len; i++)
	{
		prob += this->cmptCrmColProbGivenSH_Motif(n-len+1+i,stateHist,branchState,k,motifColInd[i]);
	}
	return prob;
}

double Felsenstein::cmptFullStateHistProb_3(const int len, const int n, BitMapOfStates stateHist, const int k) const
{
	double prob = 0.0;
	
	for (int i=0; i<this->mNumOfNodes; ++i)
	{
		int num_children = this->mBranchData[i].childrenIndex.size();
		if (num_children == 0) continue;
		int headState = (stateHist & (1<<i)) ? 2 : 0;
		for (int c=0; c<num_children; ++c)
		{
			int cInd = this->mBranchData[i].childrenIndex[c];
			int branchState = (stateHist & (1<<cInd)) ? (1+headState) : headState;
			double branch_len = this->mBranchData[cInd].branchLen;
			double validCols = 0.0;
			switch (branchState)
			{
			case k2k:	// k to k
				prob -= branch_len * this->mu[k];
				break;
			case o2k:	// o to k
				prob += log(branch_len * this->lambda[k]) - this->mu[k]*branch_len;
				break;
			case k2o:	// k to o
				prob += log(exp(branch_len*this->mu[k]) - 1) - this->mu[k]*branch_len;
				for (int ind=n-len+1; ind<=n; ++ind) validCols += this->BranchValidCols[cInd][ind];
				prob += validCols * this->mBranchParam[cInd].o2oSubstProb;
				break;
			case o2o:	// o to o
				for (int ind=n-len+1; ind<=n; ++ind) validCols += this->BranchValidCols[cInd][ind];
				prob += validCols * this->mBranchParam[cInd].o2oSubstProb;
				break;
			}
		}
	}
	
	// Compute the root node emit prob
	int lastInd = this->mNumOfNodes-1;
	if (stateHist & (1<<lastInd))
	{
		prob += this->omega[k];
	}
	else
	{
		//double nt_length = 0.0;
		//for (int ind=n-len+1; ind<=n; ++ind) nt_length += this->BranchValidCols[lastInd][ind];
		double nt_length = (double) this->indels[this->mBranchData[lastInd].seqIndex].countNts(len, n);
		prob += nt_length * this->omega[0];
	}

	return prob;
}

double Felsenstein::cmptFullStateHistProb_2(const int len, const int n, BitMapOfStates stateHist, const int k) const
{
	double prob = 0.0;
	
	for (int i=0; i<this->mNumOfNodes; ++i)
	{
		int num_children = this->mBranchData[i].childrenIndex.size();
		if (num_children == 0) continue;
		int headState = (stateHist & (1<<i)) ? 2 : 0;
		for (int c=0; c<num_children; ++c)
		{
			int cInd = this->mBranchData[i].childrenIndex[c];
			int branchState = (stateHist & (1<<cInd)) ? (1+headState) : headState;
			double branch_len = this->mBranchData[cInd].branchLen;
			double validCols = 0.0;
			for (int ind=n-len+1; ind<=n; ++ind) validCols += this->BranchValidCols[cInd][ind];
			switch (branchState)
			{
			case k2k:	// k to k
				prob -= branch_len * this->mu[k];
				break;
			case o2k:	// o to k
				prob += log(branch_len * this->lambda[k]) - this->mu[k]*branch_len*0.5;
				prob += validCols * this->mBranchParam[cInd].o2oSubstProb / 2.0;
				break;
			case k2o:	// k to o
				prob += log(exp(branch_len*this->mu[k]) - 1) - this->mu[k]*branch_len*1.5;
				prob += validCols * this->mBranchParam[cInd].o2oSubstProb / 2.0;
				break;
			case o2o:	// o to o
				prob += validCols * this->mBranchParam[cInd].o2oSubstProb;
				break;
			}
		}
	}

	// Compute the root node emit prob
	int lastInd = this->mNumOfNodes - 1;
	if (stateHist & (1<<lastInd))
	{
		prob += this->omega[k];
	}
	else
	{
		//double nt_length = 0.0;
		//for (int ind=n-len+1; ind<=n; ++ind) nt_length += this->BranchValidCols[lastInd][ind];
		double nt_length = (double) this->indels[this->mBranchData[lastInd].seqIndex].countNts(len, n);
		prob += nt_length * this->omega[0];
	}

	return prob;
}

void Felsenstein::getStateHistNodeIndex(vector< int > &seqIndex) const
{
	for (int i=0; i<this->mNumOfNodes; ++i)
	{
		seqIndex.push_back(this->mBranchData[i].seqIndex);
	}
	return;
}

double Felsenstein::cmptCrmBlockProb(const int len, const int n, const int k) const
{
	return (this->*cmptCrmBlockProbFuncPtr)(len, n, k);
}

double Felsenstein::printCrmBlockProb(ostream &os, const int len, const int n, const int k) const
{
	return (this->*printCrmBlockProbFuncPtr)(os, len, n, k);
}

