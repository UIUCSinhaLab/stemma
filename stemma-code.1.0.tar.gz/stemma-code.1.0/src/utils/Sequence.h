#ifndef SEQUENCE_H
#define SEQUENCE_H
#include <cctype>
#include <cstring>
#include <string>
#include <utility>

#include "Tools.h"

/*****************************************************
* DNA Sequences
******************************************************/

// alphabet
const char ALPHABET[] = { 'A', 'C', 'G', 'T', 'N', '-' };
const int NBASES = 4;	// number of bases
const int ALPHABET_SIZE = 6;
const int GAP = 5;		// '-'

const int MAX_SEQ_LENGTH = 10000;
const double EPS = 1e-10;

/* Utility functions */
// test if a is a nucleotide {A,G,C,T}
bool isNt( int a );
// test if a is a nucleotide or a gap
bool isNtOrGap( int a );
// test if a is an extended symbol (N, Y, R)
bool isExtendedSymbol( int a );
// test if a is a nt. or an extended symbol
bool isNtOrExtended( int a );
// test if a -> b is transition or transversion where a, b are nts.
bool isTransition( int a, int b );
// the complement of a nt.
int complement( int a );
// conversion of a symbol (nt. or gap or N) to its index in ALPHABET
int symbolToInt( char c );
// generate the distribution of nts from GC content
vector< double > createDistr( double GC_content );
// map a pair of symbols to alignment state (0, 1 or 2)
int alnState( int x, int y );

/* BaseSequence class */
class BaseSequence {
protected:
	vector< int > nts;		// nts[ i ]: the i-th nt.
public:
	// constructors
	BaseSequence() : nts() {}
	BaseSequence( const vector< int >& _nts );
	virtual void copy( const BaseSequence& other ) { nts = other.nts; }
	BaseSequence( const BaseSequence& other ) { copy( other ); }
	
	// assignment
	BaseSequence& operator=( const BaseSequence& other ) { copy( other ); return *this; }

	// access methods
	int size() const { return nts.size(); }
	int getNt( int pos ) const { 
		assert( pos >= 0 && pos < size() );
		return nts[ pos ]; 
	}
	void setNt( int pos, int nt ) { 
		assert( pos >= 0 && pos < size() && isNtOrExtended( nt ) );
		nts[ pos ] = nt; 
	}
	const int& operator[]( int pos ) const {
		assert( pos >= 0 && pos < size() );
		return nts[ pos ];	
	}
	int& operator[]( int pos ) {
		assert( pos >= 0 && pos < size() );
		return nts[ pos ];	
	}
	const vector< int >& getNts() const { return nts; }
	
	// check if a BaseSequence contains gap
	bool containsGap() const;
	
	// information of the sequence
	void getNtCounts( vector< int >& counts ) const;
	
	// insert a nt. at the end of sequence
	virtual int push_back( int nt );	
	
	// clear the sequence
	void clear() { nts.clear(); }
};

// file formats for Sequence
enum FileFormats { FASTA, PHYLIP };

class SeqElement;
class TfbsMotif;
class Site;

/* Sequence class */
class Sequence : public BaseSequence {
	vector< int > annots;	// annots[ i ]: the annotation of the i-th nt. 0 - background; k - k-th Tfbs
public:	
	// constructors
	Sequence() : BaseSequence() {}
	Sequence( const vector< int >& _nts ) : BaseSequence( _nts ) , annots( nts.size(), 0 ) {}
	Sequence( const vector< int >& _nts, const vector< int >& _annots );
	void copy( const Sequence& other ) { nts = other.nts; annots = other.annots; }
	Sequence( const Sequence& other ) { copy( other ); }
	
	// assignment
	Sequence& operator=( const Sequence& other ) { copy( other ); return *this; }
	
	// access methods
	int getAnnot( int pos ) const {
		assert( pos >= 0 && pos < size() );
		return annots[ pos ];	
	}
	const vector< int >& getAnnots() const { return annots; }
		
	// move forward or backward a certain length, skipping gaps in the process if skipGaps is true. Return the actual length moved
	int moveForward( int start, int length, bool skipGaps = true ) const;
	int moveBackward( int end, int length, bool skipGaps = true ) const;
	
	// replace the rev. compl. motif id with the original one
	void recoverRevComplAnnot();
	
	// insert a nt. or a sequence element at the end of sequence
	int push_back( int nt );
	int push_back( const SeqElement& elem );

	// insert a nt. to a sequence before a certain position
	void insert( int pos, int nt );
	
	// erase a nt. or a range of nts.
	void erase( int pos );		
	void erase( int start, int end );		// [start, end)
	
	// remove gaps, i.e. restore the sequence
	Sequence restoreSeq() const; 
	
	// annotate a sequence segment S[ start, start + length - 1 ] with the type (which motif or background)
	int annot( int start, int length, int type );

    // annotate(reconstruct) the sequence from a set of sites
    int annot( const vector< TfbsMotif >& motifs, const vector< Site >& sites );
	
	// the list of TFBS start positions
	vector< vector< int > > getTfbsPositions( const vector< TfbsMotif >& motifs ) const;
	
	// given a position, extract its motif information: if it is TFBS, return type and offset; o/w, return the type of the nearest (to the right) TFBS and the distance (0,0 if none) 
	void getMotifInfo( int pos, const vector< TfbsMotif >& motifs, bool& isTfbs, int& type, int& offset ) const;
	
	// given a position that is not in a TFBS, find its neighborhood whose boundaries are the left and right nearest TFBS (close in the left but open in the right)
	pair< int, int > findNeighborhood( int pos ) const;
	
	// output
	friend ostream& operator<<( ostream& os, const Sequence& seq );
	
	// load Sequence from a file
	int load( const string& file, string& name, int format = FASTA );
	int load( const string& file, int format = FASTA );
	
	// print TFBS information of a sequence
	void printInfo( const vector< TfbsMotif >& motifs ) const;
	
	// whether print the annotation or not
	static bool printAnnot;		
};

/* SeqElement class */
class SeqElement : public BaseSequence {
public:
	// constructor
	SeqElement() : BaseSequence() {}
	SeqElement( const vector< int >& _nts ) : BaseSequence( _nts ) {}
	SeqElement( const Sequence& seq, int start, int length );
	void copy( const SeqElement& other ) { nts = other.nts; }
	SeqElement( const SeqElement& other ) { copy( other ); }

	// assignment
	SeqElement& operator=( const SeqElement& other ) { copy( other ); return *this; }
	
	// equality test
	bool operator==( const SeqElement& other ) const { return nts == other.nts; }
			
	// insert a nt. at the end of sequence
	int push_back( int nt );

	// remove gaps, i.e. restore the sequence element
	SeqElement restoreElem() const; 

	// reverse complement of a sequence element
	SeqElement compRevCompl() const;
		
	// compute the log-likelihood of generating this sequence element with some distribution
	double comp_ll( const vector< double >& pi ) const;
	
	// output
	friend ostream& operator<<( ostream& os, const SeqElement& elem );	
};

// read sequences from a file
int readSequences( const string& file, vector< Sequence >& seqs, vector< string >& names, int format = FASTA );
int readSequences( const string& file, vector< Sequence >& seqs, int format = FASTA );

// write sequences to a file
int writeSequences( const string& file, const vector< Sequence >& seqs, const vector< string >& names, int format = FASTA );
int writeSequences( const string& file, const vector< Sequence >& seqs, int format = FASTA );

/*****************************************************
* DNA Sequence Motifs
******************************************************/

/* Motif class: position-specific multinomial distributions */
class Motif {
protected:
	Matrix pwm;	// the position weight matrix
public:	
	// constructors
	Motif() : pwm() {}
	Motif( int _length ) : pwm( _length, 4 ) { assert( _length > 0 ); }
	Motif( const Matrix& _pwm ) : pwm( _pwm ) { assert( pwm.getCols() == 4 ); }
	Motif( const Matrix& countMatrix, double pseudoCount );	// countMatrix in Transfac format
	void copy( const Motif& other ) { pwm = other.pwm; }
	Motif( const Motif& other ) { copy( other ); }
	
	// assignment
	Motif& operator=( const Motif& other ) { copy( other ); return *this; }
	
	// access methods
	int length() const { return pwm.getRows(); }
	const Matrix& getPwm() const { return pwm; } 
	
	// sample a site from PWM
	void sample( const gsl_rng* rng, SeqElement& elem ) const;
		
	// load a Motif
	int load( const string& file, string& name );
	int load( const string& file );
	
	// output
	friend ostream& operator<<( ostream& os, const Motif& motif );
};

/* TfbsMotif class: transcription factor binding site motif, adding energy computation */
class TfbsMotif : public Motif {
	// background distribution
	vector< double > background;
	
	// energy matrix, defined as: E(i,a) = energy of nt. a at position i
	Matrix energyMat;
public:
	// constructors
	TfbsMotif() : Motif(), energyComputed( false ) {}
	TfbsMotif( int _length ) : Motif( _length ), energyMat( _length, 4 ), energyComputed( false ) {}	
	TfbsMotif( const Matrix& _pwm, const vector< double >& _background ); 
	TfbsMotif( const Matrix& countMatrix, double pseudoCount, const vector< double >& _background );		// countMatrix in Transfac format
	void copy( const TfbsMotif& other ) { pwm = other.pwm; background = other.background; energyMat = other.energyMat; }
	TfbsMotif( const TfbsMotif& other ) { copy( other ); }

	// assignment
	TfbsMotif& operator=( const TfbsMotif& other ) { copy( other ); return *this; }
	
	// access methods
	const vector< double >& getBackground() const { return background; }
	const Matrix& getEnergyMat() const { return energyMat; }
	
	// the reverse complement of this motif
	TfbsMotif compRevCompl() const;

	// compute the energy (log-likelihood ratio) of a site 
	double energy( const SeqElement& elem ) const;
	
	// compute the log-likelihood of generating a site 
	double comp_ll( const SeqElement& elem ) const;
	
	// sample a site whose energy is larger than a threshold
	void sampleGoodSite( const gsl_rng* rng, SeqElement& elem, double thr ) const;
	
	// load a TfbsMotif
	int load( const string& file, const vector< double >& background, string& name );
	int load( const string& file, const vector< double >& background );
	
	// output
	friend ostream& operator<<( ostream& os, const TfbsMotif& motif );
private:
	bool energyComputed;	// whether energy matrix has been computed
	void init();	
};

// read the motifs (PWMs) in a FASTA-like format: pseudocounts within the file
int readMotifs( const string& file, vector< Motif >& motifs, vector< string >& names );
int readMotifs( const string& file, vector< Motif >& motifs );
int readMotifs( const string& file, const vector< double >& background, vector< TfbsMotif >& motifs, vector< string >& names );
int readMotifs( const string& file, const vector< double >& background, vector< TfbsMotif >& motifs );

/*****************************************************
* Annotation of DNA Sequences: scanning for TFBS
******************************************************/

/* Annotator class: annotate the putative TFBS in a sequence and its reverse complement
 * The value of position is the end position (open) if at the (-) strand. 
 * Note that the binding sites could overlap */
class Annotator {
	const Sequence& seq;
	const TfbsMotif& motif;
public:
	// constructor
	Annotator( const Sequence& _seq, const TfbsMotif& _motif );
	
	// annotate the sequence: find the putative BS in both strands
	void annotate( double threshold, vector< int >& positionsPos, vector< int >& positionsNeg ) const;
	
	// find the best matching site
	void searchBestSite( int& position, bool& orientation ) const;
};

/* Site class: a TFBS in a sequence with its relevant information */
class Site {
public:
	// constructors
	Site( int _start, bool _strand, int _factorIdx ) : start( _start ), strand( _strand ), factorIdx( _factorIdx ), energy( 0 ) {}
	Site( int _start, bool _strand, int _factorIdx, double _energy ) : start( _start ), strand( _strand ), factorIdx( _factorIdx ), energy( _energy ) {}	
	void copy( const Site& other ) { start = other.start; strand = other.strand; factorIdx = other.factorIdx; energy = other.energy; }
	Site( const Site& other ) { copy( other ); }
	
	// assignment
	Site& operator=( const Site& other ) { copy( other ); return *this; }	
		
	friend ostream& operator<<( ostream& os, const Site& site );	
	
	int start;		// start position: 0-based
	bool strand;	// 1: positive; 0: negative
	int factorIdx;	// the index of the associated TF: start from 0
	double energy;	// the energy relative to the strongest site (nonnegative)
};

// representation of Sequence as a Site vector
typedef vector< Site > SiteVec;		

// read sites (of potentially multiple sequences)
int readSites( const string& file, const map< string, int >& factorIdxMap, vector< SiteVec >& sites, vector< string >& names );
int readSites( const string& file, const map< string, int >& factorIdxMap, vector< SiteVec >& sites );

/*****************************************************
* Alignment of DNA Sequences
******************************************************/

/* Alignment class */
class Alignment {
	vector< pair< int, int > > columns;	
public:
	// constructors
	Alignment() : columns() {}
	Alignment( const vector< pair< int, int > >& _columns );
	Alignment( const string& str1, const string& str2 );
	void copy( const Alignment& other ) { columns = other.columns; }
	Alignment( const Alignment& other ) { copy( other ); }
	
	// assignment
	Alignment& operator=( const Alignment& other ) { copy( other ); return *this; }
	
	// access methods
	int size() const { return columns.size(); }
	const pair< int, int >& operator[]( int pos ) const {
		assert( pos >= 0 && pos < size() );
		return columns[ pos ];	
	}
	pair< int, int >& operator[]( int pos ) {
		assert( pos >= 0 && pos < size() );
		return columns[ pos ];	
	}

	// counts of 4 nts in the alignment
	void getNtCounts( vector< int >& counts ) const;
	
	// extract the two original sequences
	int extractSequences( Sequence& seq1, Sequence& seq2 ) const;
	
	// map positions in the alignment to the positions in the two original sequences
	vector< pair< int, int > > mapAlnPositions() const;
	
	// map the positions in the original sequence to the alignment positions
	void mapSeqPositions( vector< int >& seq1Positions, vector< int >& seq2Positions ) const;
	
	// number of matches in the alignment
	int nMatches() const;
	int nNongaps() const;
	
	// alignment statistics: n1 = number of type1 indels; n2 = number of type2 indels; and the indel length distribution
	// return the total number of events (matches and mismatches + indels)
	int stat( int& n1, int& n2, map< int, int >& lengthDistr ) const;
	
	// insert a column to the alignment
	int push_front( int x1, int x2 ); 	// at the beginning 
	int push_back( int x1, int x2 ); 	// at the end 
	
	// append another alignment
	int append_front( const Alignment& other );
	int append_back( const Alignment& other );
	
	// clear the alignment
	void clear() { columns.clear(); }
	
	// output operator
	friend ostream& operator<<( ostream& os, const Alignment& aln );
	
	// load Alignment from a file
	int load( const string& file, pair< string, string >& names, int format = FASTA );
	int load( const string& file, int format = FASTA );	
	
	// print Alignment
	void print( const string& file, const pair< string, string >& names, int format = FASTA ) const;
};

/*****************************************************
* Sequence/Alignment Analysis & Output
******************************************************/

/* AlignmentBlock class */
class AlignmentBlock {
public:
	int start;		// start position of the block in the alignment
	int end;		// end position of the block in the alignment
	pair< int, int > annot;		// annotation of the block in 2 sequences
	bool strand;	// which strand 

	// constructor
	AlignmentBlock( int _start, int _end, const pair< int, int >& _annot, bool _strand );
	
	// extract the pair of sequence elements from the associated alignment
	pair< SeqElement, SeqElement > getElemPair( const Alignment& aln ) const;
};

/* AnnotatedAlignment class
 * Extract/access information in the annotated alignment */
class AnnotatedAlignment {
	const Sequence& seq1;
	string name1;
	const Sequence& seq2;
	string name2;
	const Alignment& aln;
	const vector< TfbsMotif >& motifs;
	const vector< string >& motifNames;
public:
	// constructor
	AnnotatedAlignment( const Sequence& _seq1, const string& _name1, const Sequence& _seq2, const string& _name2, const Alignment& _aln, const vector< TfbsMotif >& _motifs, const vector< string >& _motifNames ) : seq1( _seq1 ), name1( _name1 ), seq2( _seq2 ), name2( _name2 ), aln( _aln ), motifs( _motifs ), motifNames( _motifNames ) {}
	
	// parse the alignment into a series of blocks: assuming no overlapping of BS (output from the ModuleAlign method)
	void parse( vector< AlignmentBlock >& blocks ) const;
	
	// extract the conserved blocks (TFBS): defined as aligned BS starting at the same position
	void extractConservedTfbs( vector< AlignmentBlock >& blocks ) const;
	
	// print the annotated alignment
	void print( ostream& os, int lineMax = 100 ) const;
	
	// print conserved TFBS columns in the first sequence (in a conserved BS, some columns may not be conserved)
	void printConservedTfbsCols( const string& file ) const;
    void printConservedTfbsCols( ostream& os ) const;
};

#endif
