/* Compute the energy thresholds of motifs given the p-value cutoff */

#include "Sequence.h"

int main( int argc, char* argv[] )
{
	// command line processing
	string motifFile;
	int sampleSize = 1000000;		// default sample size
	double pvalCutoff = 0.002;		// default p-value cutoff
	double neutral_GC = 0.4;		// default GC content 
	for ( int i = 1; i < argc; i++ ) {
		if ( !strcmp( "-m", argv[ i ] ) )
			motifFile = argv[ ++i ];
		else if ( !strcmp( "-N", argv[ i ] ) )
			sampleSize = atoi( argv[ ++i ] );
		else if ( !strcmp( "-p", argv[ i ] ) )
			pvalCutoff = atof( argv[ ++i ] );
		else if ( !strcmp( "-c", argv[ i ] ) )
			neutral_GC = atof( argv[ ++i ] );
	}
	if ( motifFile.empty() ) {
		cerr << "Usage: " << argv[ 0 ] << " -m motifFile [-N sampleSize -p pvalCutoff -c neutral_GC]" << endl;
		exit( 1 );
	}
	
	int rval;
	
	// random number generator
	gsl_rng* rng;
	gsl_rng_env_setup();
	const gsl_rng_type * T = gsl_rng_default;	// create rng type
	rng = gsl_rng_alloc (T);
	gsl_rng_set( rng, time( 0 ) );		// set the seed equal to simulTime(0)
		
	// neutral background distribution
	vector< double > background = createDistr( neutral_GC );

	// read the PWM of the motifs
	vector< TfbsMotif > motifs;
	vector< string > names;
	rval = readMotifs( motifFile, background, motifs, names );
	assert( rval != RET_ERROR );

	// compute the energy threshold of each motif
	vector< double > thresholds;
	for ( int k = 0; k < motifs.size(); k++ ) {
		int l = motifs[ k ].length();
		
		// the neutral distribution to be sampled from
		Matrix bgDistrs( l, 4 );
		bgDistrs.setRows( background );
		Motif bgMotif( bgDistrs );
		
		// sample sites 
		vector< double > energyVect;
		for ( int i = 0; i < sampleSize; i++ ) {
			SeqElement site;
			bgMotif.sample( rng, site ); 
			energyVect.push_back( motifs[ k ].energy( site ) );
		}
		
		// the energy threshold
		thresholds.push_back( elementAt( energyVect, pvalCutoff ) ); 	
	}
	
	// output the results
	for ( int k = 0; k < motifs.size(); k++ ) {
		cout << names[ k ] << "\t" << thresholds[ k ] << endl;
	}
		
	return 0;	
}
