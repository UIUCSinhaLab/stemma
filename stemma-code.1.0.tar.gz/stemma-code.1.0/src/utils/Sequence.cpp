#include <sstream>
#include "Sequence.h"

// test if a is a nucleotide {A,G,C,T}
bool isNt( int a )
{
	if ( a < 0 || a > 3 ) return false;
	else return true;	
}

// test if a is a nucleotide or a gap
bool isNtOrGap( int a )
{
	if ( isNt( a ) || a == GAP ) return true;
	else return false;	
}

// test if a is an extended symbol (N, Y, R)
bool isExtendedSymbol( int a )
{
	if ( a >= 0 && a < ALPHABET_SIZE && a != GAP ) 
		return true;
	else
		return false;
}

// test if a is a nt. or an extended symbol
bool isNtOrExtended( int a )
{
	return ( a >= 0 && a < ALPHABET_SIZE && a != GAP);	
}

// test if a -> b is transition or transversion where a, b are nts.
bool isTransition( int a, int b )
{
	assert( isNt( a ) && isNt( b ) && a != b );
	
	if ( a == 0 && b == 2 ) return true;
	if ( a == 2 && b == 0 ) return true;
	if ( a == 1 && b == 3 ) return true;
	if ( a == 3 && b == 1 ) return true;
	
	return false;
}

int complement( int a )
{
	assert( isNt( a ) || a == GAP );
		
	if ( a == 0 ) return 3;
	if ( a == 1 ) return 2;
	if ( a == 2 ) return 1;
	if ( a == 3 ) return 0;	
	if ( a == GAP ) return GAP;	
}

// conversion of a symbol (nt. or gap or N) to its index in ALPHABET
int symbolToInt( char c )
{
	char upper = toupper( c );
	for ( int i = 0; i < ALPHABET_SIZE; i++ ) {
		if ( ALPHABET[ i ] == upper ) return i;	
	}
	
	return -1;
}

vector< double > createDistr( double GC_content )
{
	vector< double > result( 4 );
	result[ 0 ] = ( 1.0 - GC_content ) / 2;
	result[ 1 ] = GC_content / 2;
	result[ 2 ] = result[ 1 ];
	result[ 3 ] = result[ 0 ]; 
	
	return result;
}

int alnState( int x, int y )
{
	if ( x != GAP ) {
		if ( y != GAP ) return 0;
		else return 1; 	
	} else {
		if ( y != GAP ) return 2;
		else return RET_ERROR;
	}
}

BaseSequence::BaseSequence( const vector< int >& _nts ) : nts( _nts )
{
	// check the BaseSequence 
	for ( int i = 0; i < nts.size(); i++ ) {
		assert( nts[ i ] >= 0 && nts[ i ] < ALPHABET_SIZE );
	}	
}

bool BaseSequence::containsGap() const
{
	for ( int i = 0; i < nts.size(); i++ ) {
		if ( nts[ i ] == GAP ) return true;
	}	
	
	return false;
}

// information of the BaseSequence
void BaseSequence::getNtCounts( vector< int >& counts ) const
{
	counts.clear();
	for ( int i = 0; i < NBASES; i++ ) {
		counts.push_back( 0 );
	}
	
	for ( int i = 0; i < nts.size(); i++ ) {
		if ( nts[ i ] != GAP ) counts[ nts[ i ] ]++;	
	}
}

// insert a nt. at the end of BaseSequence
int BaseSequence::push_back( int nt )
{	
	assert( nt >= 0 && nt < ALPHABET_SIZE );
	nts.push_back( nt );
}

bool Sequence::printAnnot = true;

// Sequence constructor
Sequence::Sequence( const vector< int >& _nts, const vector< int >& _annots ) : BaseSequence( _nts ), annots( _annots )
{
	// check if the nts match the annotation
	assert( nts.size() == annots.size() );

	// check the annotation
	for ( int i = 0; i < annots.size(); i++ ) {
		assert( annots[ i ] >= 0 );	
	}	
}

int Sequence::moveForward( int start, int length, bool skipGaps ) const
{	
	if ( length == 0 ) return 0;
	
	int count = 0;
	for ( int i = start; i < size(); i++ ) {
		if ( !skipGaps ) count++;
		else if ( nts[ i ] != GAP ) {
			count++;	
		}
		if ( count == length ) return i + 1 - start;		
	}
	
	return size() - start;
}

int Sequence::moveBackward( int end, int length, bool skipGaps ) const
{	
	if ( length == 0 ) return 0;
	
	int count = 0;
	for ( int i = end; i >= 0; i-- ) {
		if ( !skipGaps ) count++;
		else if ( nts[ i ] != GAP ) {
			count++;	
		}
		if ( count == length ) return end + 1 - i;				
	}
	
	return end + 1;
}

void Sequence::recoverRevComplAnnot()
{
	for ( int i = 0; i < annots.size(); i++ ) {
		if ( annots[ i ] % 2 == 0 ) annots[ i ] = annots[ i ] / 2;
		else annots[ i ] = ( annots[ i ] + 1 ) / 2;
	}	
}

// Sequence: insert a nt. at the end of Sequence
int Sequence::push_back( int nt )
{
	assert( nt >= 0 && nt < ALPHABET_SIZE );
	
	nts.push_back( nt );
	annots.push_back( 0 );
	
	return 0;
}

// Sequence: insert a sequence element at the end of sequence
int Sequence::push_back( const SeqElement& elem )
{
	for ( int i = 0; i < elem.size(); ++i ) push_back( elem[ i ] );	
	return 0;
}

// Sequence: insert a nt. to a sequence before a certain position
void Sequence::insert( int pos, int nt )
{
	assert( pos >= 0 && pos <= nts.size() );
	assert( nt >= 0 && nt < ALPHABET_SIZE );
	
	nts.insert( nts.begin() + pos, nt );
	annots.insert( annots.begin() + pos, 0 );
}

// Sequence: erase a nt. at some position
void Sequence::erase( int pos )
{
	assert( pos >= 0 && pos < nts.size() );
	
	nts.erase( nts.begin() + pos );
	annots.erase( annots.begin() + pos );
}

// Sequence: erase nts in the range of [start,end)
void Sequence::erase( int start, int end )
{
	assert( start >= 0 && start < nts.size() );
	assert( end >= 0 && end <= nts.size() );
	assert( start <= end );
	
	nts.erase( nts.begin() + start, nts.begin() + end );
	annots.erase( annots.begin() + start, annots.begin() + end );
}

// Sequence: remove gaps, i.e. restore the sequence
Sequence Sequence::restoreSeq() const
{
	vector< int > origNts;
	for ( int i = 0; i < nts.size(); ++i ) {
		if ( nts[ i ] != GAP ) origNts.push_back( nts[ i ] );	
	}
	
	return Sequence( origNts );
} 

int Sequence::annot( int start, int length, int type )
{
	assert( start >= 0 && length >= 0 && ( start + length ) <= nts.size() );
	
	for ( int i = 0; i < length; i++ ) {
		annots[ start + i ] = type;	
	}	
}

int Sequence::annot( const vector< TfbsMotif >& motifs, const SiteVec& sites )
{
    for ( int i = 0; i < sites.size(); i++ ) {
        int idx = sites[i].factorIdx;
        annot( sites[i].start, motifs[idx].length(), idx + 1);
    }

    return 0;
}

// Sequence: the list of TFBS start positions
vector< vector< int > > Sequence::getTfbsPositions( const vector< TfbsMotif >& motifs ) const
{
	vector< vector< int > > positions( motifs.size() );
	
	// scan the sequence to collect the TFBS positions
	int i = 0;
	while ( i < nts.size() ) {
		int k = annots[ i ];
		if ( k > 0 ) {
			int l = motifs[ k - 1 ].length();
			positions[ k - 1 ].push_back( i );
			i += l;	
		} else {
			i++;	
		}
	}	
	
	return positions;
}

void Sequence::getMotifInfo( int pos, const vector< TfbsMotif >& motifs, bool& isTfbs, int& type, int& offset ) const
{
	assert( pos >= 0 && pos < nts.size() );
	
	int k = annots[ pos ];
	if ( k > 0 ) {
		isTfbs = true;
		type = k;
		int j = pos - 1;
		while ( j >= 0 && annots[ j ] == k ) j--;
		int l = motifs[ k - 1 ].length();		
		offset = ( pos - j - 1 ) % l;
	} else {
		isTfbs = false;
		int j = pos;
		while ( j < nts.size() && annots[ j ] == 0 ) j++;
		if ( j == nts.size() ) {
			type = 0;
			offset = 0;
		} else {
			type = annots[ j ];
			offset = j - pos ;	
		}
	}	
}

// Sequence: given a position that is not in a TFBS, find its neighborhood whose boundaries are the left and right nearest TFBS (close in the left but open in the right)
pair< int, int > Sequence::findNeighborhood( int pos ) const
{
	assert( pos >= 0 && pos < nts.size() && annots[ pos ] == 0 );
		
	// left boundary
	int i = pos;
	while ( i >= 0 && annots[ i ] == 0 ) i--;
	int left = i + 1;
	
	// right boundary
	i = pos;
	while ( i < nts.size() && annots[ i ] == 0 ) i++;
	int right = i;
	
	return pair< int, int >( left, right );
}

// output the Sequence
ostream& operator<<( ostream& os, const Sequence& seq )
{
	// output the nts
	for ( int i = 0; i < seq.size(); i++ ) {
		os << ALPHABET[ seq[ i ] ];	
	}	
	
	if ( !Sequence::printAnnot ) return os;
	
	// output the annot	
	bool containsTfbs = false;
	for ( int i = 0; i < seq.size(); i++ ) { 
		if ( seq.getAnnot( i ) ) containsTfbs = true;
	}
	if ( containsTfbs ) {
		os << endl;
		for ( int i = 0; i < seq.size(); i++ ) {
			if ( seq.getAnnot( i ) ) os << seq.getAnnot( i );
			else os << ' ';
		}
		os << endl;
	}
	
	return os;
	
	// TO DO: the display is not going to work if the number of motifs > 9
}

// Sequence: load Sequence from a file
int Sequence::load( const string& file, string& name, int format )
{
	vector< Sequence > seqs;
	vector< string > names;
	int rval = readSequences( file, seqs, names, format );
	if ( rval == RET_ERROR ) return RET_ERROR;
	
	copy( seqs[ 0 ] );
	name = names[ 0 ];
	return rval;
}

// Sequence: load Sequence from a file
int Sequence::load( const string& file, int format )
{
	string name;
	int rval = load( file, name, format );
	
	return rval;	
}

// Sequence: print the TFBS information 
void Sequence::printInfo( const vector< TfbsMotif >& motifs ) const
{
	vector< vector< int > > tfbsPositions = getTfbsPositions( motifs );
	
	for ( int k = 0; k < motifs.size(); k++ ) {
		cout << "Binding sites of Motif " << k + 1 << " : " << endl;
		int l = motifs[ k ].length();		
		for ( int i = 0; i < tfbsPositions[ k ].size(); i++ ) {
			int start = tfbsPositions[ k ][ i ];
			SeqElement elem( *this, start , l );
			cout << start << "\t" << elem << "\t" << motifs[ k ].energy( elem ) << endl;
		}
		cout << endl;
	}	
}

// SeqElement constructor: from S[ start, start + length - 1 ] where S is a Sequence
SeqElement::SeqElement( const Sequence& seq, int start, int length )
{
	assert( start >= 0 && length >= 0 && ( start + length ) <= seq.size() );
	
	for ( int i = 0; i < length; i++ ) {
		nts.push_back( seq[ start + i ] );	
	}
}

// SeqElement: insert a nt. at the end of sequence
int SeqElement::push_back( int nt )
{
	assert( nt >= 0 && nt < ALPHABET_SIZE );
	
	nts.push_back( nt );		
}

// SeqElement: remove gaps, i.e. restore the sequence element
SeqElement SeqElement::restoreElem() const
{
	SeqElement result;
	for ( int i = 0; i < nts.size(); i++ ) {
		if ( nts[ i ] != GAP ) result.push_back( nts[ i ] );	
	}
	
	return result;
}

SeqElement SeqElement::compRevCompl() const
{
	SeqElement rcElem;
	for ( int i = nts.size() - 1; i >= 0; i-- ) {
		rcElem.push_back( complement( nts[ i ] ) );	
	}
	
	return rcElem;
}

double SeqElement::comp_ll( const vector< double >& pi ) const
{
	assert( pi.size() == 4 && isPmf( pi ) );
	
	double result = 0;
	for ( int i = 0; i < nts.size(); i++ ) {
		result += log( pi[ nts[ i ] ] );
	}	
	
	return result;
}

// output the SeqElemnt
ostream& operator<<( ostream& os, const SeqElement& elem )
{
	// output the nts
	for ( int i = 0; i < elem.size(); i++ ) {
		os << ALPHABET[ elem[ i ] ];	
	}
	
	return os;	
	//os << endl;	
}

// read sequences from a file
int readSequences( const string& file, vector< Sequence >& seqs, vector< string >& names, int format )
{
	// check if the format character is legal
	if ( format != FASTA && format != PHYLIP ) { return RET_ERROR; }
	 
	// 	open the file
	ifstream fin( file.c_str() );
	if ( !fin ) { cerr << "Cannot open" << file << endl; exit( 1 ); }

	string line;
	Sequence seq;
	
	// read sequences: FASTA format
	if ( format == FASTA ) {
		while ( getline( fin, line ) ) {
			// add the sequence and start a new sequence if the line starts with >
			//cout << line << endl;
			if ( line[ 0 ] == '>' ) { 	
				if ( seq.size() ) {
					seqs.push_back( seq );
					seq.clear();	
				}
				
				names.push_back( line.substr( 1 ) );
			} else { 
				// check if the line contains content
				int start = line.find_first_not_of( " \t\r" );
				int last = line.find_last_not_of( " \t\r" );
				if ( start == string::npos || last == string::npos ) continue;
				
				// append the sequence	
				for ( int i = start; i <= last; i++ ) {
					int nt = symbolToInt( line[ i ] );	// could be a gap
					if ( nt >= 0 && nt < ALPHABET_SIZE ) {
						seq.push_back( nt );
					} else {
						//cerr << "Illegal symbol: " << nt << " in " << file << endl;
						return RET_ERROR;	
					} 
				}
			}			
		}
		
		// add the last sequence
		if( seq.size() ) seqs.push_back( seq );
				
		return 0;
	}
	
	return 0;	
}

int readSequences( const string& file, vector< Sequence >& seqs, int format )
{
	vector< string > names;
	int rval = readSequences( file, seqs, names, format );	
	return rval;
}

int writeSequences( const string& file, const vector< Sequence >& seqs, const vector< string >& names, int format )
{
	assert( seqs.size() == names.size() );
	
	// check if the format character is legal
	if ( format != FASTA && format != PHYLIP ) { return RET_ERROR; }
		
	ofstream fout( file.c_str() );
	Sequence::printAnnot = false;
	
	if ( format == FASTA ) {
		for ( int i = 0; i < seqs.size(); i++ ) {
			fout << ">" << names[ i ] << endl;
			fout << seqs[ i ] << endl;
		}
	}
	
	return 0;
}

int writeSequences( const string& file, const vector< Sequence >& seqs, int format )
{
	// default name: integer starting from 1
	vector< string > names;
	for ( int i = 0; i < seqs.size(); i++ ) {
		char buffer[ 10 ];
		sprintf( buffer, "%i", i );
		names.push_back( string( buffer ) );	
	}	
	
	// print
	return writeSequences( file, seqs, names, format );
}

// Motif constructor: construct PWM from the count matrix
// countMatrix in Transfac format
Motif::Motif( const Matrix& countMatrix, double pseudoCount ) : pwm( countMatrix.getRows(), 4 )
{
	assert( countMatrix.getCols() == 4 && pseudoCount >= 0 );
	
	int l = countMatrix.getRows();		// l: the length of motif
	
	// the sum of each position/column should be a const. (number of sequences)
	double n = 0;		// number of sites used in the count matrix
	for ( int j = 0; j < 4; j++ ) {
		n += countMatrix( 0, j );
	}
	for ( int i = 1; i < l; i++ ) {
		double count = 0;
		for ( int j = 0; j < 4; j++ ) {
			count += countMatrix( i, j );
		}
		if ( fabs(count - n) > EPS ) { cout << "count matrix incorrect" << endl; exit( 1 ); }
	}
	
	// the multinomial distribution at each column
	for ( int i = 0; i < l; i++ ) {
		for ( int j = 0; j < 4; j++ ) {
			pwm( i, j ) = ( countMatrix( i, j ) + pseudoCount ) / ( n + 4.0 * pseudoCount );
		}	
	}
}

// Motif: sample a site from PWM
void Motif::sample( const gsl_rng* rng, SeqElement& elem ) const
{
	assert( rng != NULL );
	elem.clear();
	
	int l = pwm.getRows();
	for ( int i = 0; i < l; i++ ) {
		// nt. distribution at position i
		vector< double > distr = pwm.getRow( i );
		
		// sample nt. from this distribution	
		int nt = sampleMul( rng, distr );
		elem.push_back( nt );
	}		
}

int Motif::load( const string& file, string& name )
{
	vector< Motif > preMotifs;
	vector< string > names;
	int rval = readMotifs( file, preMotifs, names );
	if ( rval == RET_ERROR ) return RET_ERROR;
	
	copy( preMotifs[ 0 ] );
	name = names[ 0 ];
	return rval;		
}

int Motif::load( const string& file )
{
	string name;
	int rval = load( file, name );
	
	return rval;	
}

// output the Motif
ostream& operator<<( ostream& os, const Motif& motif )
{
	os << motif.pwm;
	
	return os;
}

// TfbsMotif constructor
TfbsMotif::TfbsMotif( const Matrix& _pwm, const vector< double >& _background ) : Motif( _pwm ), background( _background ), energyMat( pwm.getRows(), 4 )
{
	assert( background.size() == 4 );	
	
	init();
}

// TfbsMotif constructor: construct PWM from the count matrix
// countMatrix in Transfac format
TfbsMotif::TfbsMotif( const Matrix& countMatrix, double pseudoCount, const vector< double >& _background ) : Motif( countMatrix, pseudoCount ), background( _background ), energyMat( pwm.getRows(), 4 )
{
	assert( background.size() == 4 );
	
	init();
}

TfbsMotif TfbsMotif::compRevCompl() const
{
	// compute PWM of the rev. compl. motif
	int l = length();
	Matrix rc_pwm( l, NBASES );
	for ( int i = 0; i < l; i++ ) {
		for ( int j = 0; j < NBASES; j++ ) {
			rc_pwm( i, j ) = pwm( l - 1 - i, complement( j ) );
		}	
	}
	
	// construct the rev. compl. motif
	return TfbsMotif( rc_pwm, background );
}

// TfbsMotif: compute the energy (log-likelihood) of a site 
double TfbsMotif::energy( const SeqElement& elem ) const
{
	int l = pwm.getRows();
	if( elem.size() != l ) return GSL_NEGINF;
	
	double result = 0;
	for ( int i = 0; i < l; i++ ) {
		// energy at position i
		int nt = elem[ i ];
		result += energyMat( i, nt ); 	
	}
	
	return result;
}

double TfbsMotif::comp_ll( const SeqElement& elem ) const
{
	int l = pwm.getRows();
	assert( elem.size() == l );
	
	double result = 0;
	for ( int i = 0; i < l; i++ ) {
		int nt = elem[ i ];
		result += log( pwm( i, nt ) );
	}
	
	return result;
}

// TfbsMotif: sample a site whose energy is larger than a threshold
void TfbsMotif::sampleGoodSite( const gsl_rng* rng, SeqElement& elem, double thr ) const
{
	assert( rng != NULL );
	double curr_energy = GSL_NEGINF;
	
	while ( curr_energy < thr ) {
		sample( rng, elem );
		curr_energy = energy( elem );
	}
}

int TfbsMotif::load( const string& file, const vector< double >& background , string& name )
{
	vector< TfbsMotif > motifs;
	vector< string > names;
	int rval = readMotifs( file, background, motifs, names );
	if ( rval == RET_ERROR ) return RET_ERROR;
	
	copy( motifs[ 0 ] );
	name = names[ 0 ];
	return rval;				
}

int TfbsMotif::load( const string& file, const vector< double >& background )
{
	string name;
	int rval = load( file, background, name );
	
	return rval;	
}

// output the TfbsMotif
ostream& operator<<( ostream& os, const TfbsMotif& motif )
{
	os << motif.pwm;
	
	return os;
}

// TfbsMotif: initialization
void TfbsMotif::init()
{
	int l = pwm.getRows();
	
	// compute the energy matrix
	for ( int i = 0; i < l; i++ ) {
		for ( int j = 0; j < 4; j++ ) {
			// nt. distribution at position i
			vector< double > distr = pwm.getRow( i );
			
			// energy of nt. j at position i
			energyMat( i, j ) = log( distr[ j ] / background[ j ] );
		}
	}
	
	energyComputed = true;
}

// read the motifs (PWMs) in a FASTA-like format: pseudocounts within the file
int readMotifs( const string& file, vector< Motif >& motifs, vector< string >& names )
{
	// 	open the file
	ifstream fin( file.c_str() );
	if ( !fin ) { cerr << "Cannot open" << file << endl; exit( 1 ); }

	string line;
	
	// read the motifs
	do {
		getline( fin, line );
		
		if ( line[ 0 ] != '>' ) continue;
		
		// read the names, length and pseudocount
		int MAX_SIZE = 100;
		char lineStr[ MAX_SIZE ];
		strcpy( lineStr, ( line.substr( 1 ) ).c_str() );
		char *name, *lengthStr, *pseudoCountStr;
		name = strtok( lineStr, " \t" );
		lengthStr = strtok( NULL, " \t" );
		pseudoCountStr = strtok( NULL, " \t" );
		int length;
		double pseudoCount;
		if ( lengthStr ) length = atoi( lengthStr );
		else { return RET_ERROR; }
		if ( pseudoCountStr ) pseudoCount = atof( pseudoCountStr );
		else pseudoCount = 0;
		
		// read the count matrix
		Matrix countMat( length, NBASES );
		for ( int i = 0; i < length; ++i ) {
			for ( int j = 0; j < NBASES; ++j ) {
				fin >> countMat( i, j );
			}	
		}
		
		// create the motif
		names.push_back( string( name ) );
		motifs.push_back( Motif( countMat, pseudoCount ) );
		
	} while ( !fin.eof() );
					
	return 0;
}

int readMotifs( const string& file, vector< Motif >& motifs )
{
	vector< string > names;
	return readMotifs( file, motifs, names );	
}

int readMotifs( const string& file, const vector< double >& background, vector< TfbsMotif >& motifs, vector< string >& names )
{
	vector< Motif > preMotifs;
	int rval = readMotifs( file, preMotifs, names );
	if ( rval == RET_ERROR ) return rval;
	motifs.clear();
	for ( int i = 0; i < preMotifs.size(); i++ ) {
		motifs.push_back( TfbsMotif( preMotifs[ i ].getPwm(), background ) );
	}
	
	return rval;	
}

int readMotifs( const string& file, const vector< double >& background, vector< TfbsMotif >& motifs )
{
	vector< string > names;
	return readMotifs( file, background, motifs, names );	
}

// Annotator: constructor
Annotator::Annotator( const Sequence& _seq, const TfbsMotif& _motif ) : seq( _seq ), motif( _motif )
{
	for ( int i = 0; i < seq.size(); ++i ) {
		if ( seq[ i ] == GAP ) { cerr << "Annotator::Annotator(): illegal sequence" << endl; exit( 1 ); }	
	}
}

// Annotator: annotate the sequence. Return the number of putative binding sites
void Annotator::annotate( double threshold, vector< int >& positionsPos, vector< int >& positionsNeg ) const
{
	positionsPos.clear();
	positionsNeg.clear();
	int l = motif.length();
	
	for ( int i = 0; i <= seq.size() - l; i++ ) {
		double energy;
		
		// positive strand
		SeqElement elem( seq, i, l );
		energy = motif.energy( elem );
		if ( energy >= threshold ) {
// 			cout << "+\t" << i << "\t" << elem << "\t" << energy << endl;
			positionsPos.push_back( i ); 
		}
		
		// negative strand
		SeqElement rcElem = elem.compRevCompl();
		energy = motif.energy( rcElem );
		if ( energy >= threshold ) {
// 			cout << "-\t" << i << "\t" << elem << "\t" << energy << endl;			
			positionsNeg.push_back( i );
		}
	}
}

void Annotator::searchBestSite( int& position, bool& orientation ) const
{
	int l = motif.length();
	double maxEnergyPos = GSL_NEGINF, maxEnergyNeg = GSL_NEGINF;
	int maxPositionPos, maxPositionNeg;
	
	for ( int i = 0; i <= seq.size() - l; i++ ) {
		double energy;
		
		// positive strand
		SeqElement elem( seq, i, l );
		energy = motif.energy( elem );
		if ( energy > maxEnergyPos ) {
			maxEnergyPos = energy; maxPositionPos = i;
		}
		
		// negative strand;
		SeqElement rcElem = elem.compRevCompl();
		energy = motif.energy( rcElem );		
		if ( energy > maxEnergyNeg ) {
			maxEnergyNeg = energy; maxPositionNeg = i;
		}				
	}
		
	if ( maxEnergyPos >= maxEnergyNeg ) {
		position = maxPositionPos; orientation = 1;	
	} else {
		position = maxPositionNeg; orientation = 0;			
	}
}

ostream& operator<<( ostream& os, const Site& site )
{
	char strandChar = site.strand ? '+' : '-';
	os << site.start << "\t" << strandChar << "\t" << site.factorIdx << "\t" << site.energy;
	
	return os;
}

int readSites( const string& file, const map< string, int >& factorIdxMap, vector< SiteVec >& sites, vector< string >& names )
{
    ifstream fin( file.c_str() );
    if ( !fin ) {
        return RET_ERROR;
    }

    SiteVec currVec;
    while ( !fin.eof() ) {
        string line;
        getline( fin, line );
        if ( line.empty() ) continue;

        if ( line.substr( 0, 1 ) == ">" ) {
            stringstream ss( line.substr( 1 ) );
			string name; 
			ss >> name;
			names.push_back( name );
            if ( !currVec.empty() ) {
                sites.push_back( currVec );
                currVec.clear();
            }
        } else {
            int start;
            char strandChar;
            string factor;
            double energy;
            stringstream ss( line );
            ss >> start >> strandChar >> factor >> energy; 
            bool strand = strandChar == '+' ? 1 : 0;
            map<string, int>::const_iterator iter = factorIdxMap.find( factor );
            currVec.push_back( Site( start, strand, iter->second , energy ) );
        }
    }

    if ( !currVec.empty() ) sites.push_back( currVec );

    return 0;
}

int readSites( const string& file, const map< string, int >& factorIdxMap, vector< SiteVec >& sites )
{
    vector< string > names;
    return readSites( file, factorIdxMap, sites, names );
}

Alignment::Alignment( const vector< pair< int, int > >& _columns ) : columns( _columns )
{
	// check the sequences
	for ( int i = 0; i < columns.size(); i++ ) {
		int x1 = columns[ i ].first;
		int x2 = columns[ i ].second;
		assert( x1 >= 0 && x1 < ALPHABET_SIZE );
		assert( x2 >= 0 && x2 < ALPHABET_SIZE );
        if ( x1 == GAP && x2 == GAP ) continue;
// 		assert( x1 != GAP || x2 != GAP );	// '-' is not aligned to '-'
	}
}

// construct the alignment from two aligned strings
Alignment::Alignment( const string& str1, const string& str2 )
{
	assert( str1.size() == str2.size() );
	
	for ( int i = 0; i < str1.size(); i++ ) {
		int x1 = symbolToInt( str1[ i ] );
		int x2 = symbolToInt( str2[ i ] );
		assert( x1 >= 0 && x1 < ALPHABET_SIZE );
		assert( x2 >= 0 && x2 < ALPHABET_SIZE );
        if ( x1 == GAP && x2 == GAP ) continue;
// 		assert( x1 != GAP || x2 != GAP );	// '-' is not aligned to '-'
		columns.push_back( make_pair( x1, x2 ) );	
	}
}

void Alignment::getNtCounts( vector< int >& counts ) const
{
	counts.clear();
	for ( int i = 0; i < NBASES; i++ ) {
		counts.push_back( 0 );
	}
	
	for ( int i = 0; i < size(); i++ ) {
		int x1 = columns[ i ].first, x2 = columns[ i ].second;
		if ( x1 != GAP ) counts[ x1 ]++;
		if ( x2 != GAP ) counts[ x2 ]++;		
	}
}

int Alignment::extractSequences( Sequence& seq1, Sequence &seq2 ) const
{
	for ( int i = 0; i < columns.size(); i++ ) {
		int x1 = columns[ i ].first;
		int x2 = columns[ i ].second;
		if ( isNt( x1 ) ) seq1.push_back( x1 );
		if ( isNt( x2 ) ) seq2.push_back( x2 );	
	}	
	
	return 0;
}

// gap in the alignment will map to the previous position in the sequence
vector< pair< int, int > > Alignment::mapAlnPositions() const
{
	vector< pair< int, int > > positions;
	int pos1 = -1, pos2 = -1;	// position indices in seq1 and seq2 respectively
	for ( int i = 0; i < columns.size(); i++ ) {
		int x = columns[ i ].first, y = columns[ i ].second ;
		
		if ( x != GAP ) pos1++;	
		if ( y != GAP ) pos2++;
		
		positions.push_back( pair< int, int >( pos1, pos2 ) );	
	}	
	
	return positions;
}

void Alignment::mapSeqPositions( vector< int >& seq1Positions, vector< int >& seq2Positions ) const
{
	seq1Positions.clear();
	seq2Positions.clear();
	
	for ( int i = 0; i < columns.size(); i++ ) {
		int x = columns[ i ].first, y = columns[ i ].second ;	
		
		if ( x != GAP ) seq1Positions.push_back( i );
		if ( y != GAP ) seq2Positions.push_back( i );
	} 
}

int Alignment::nMatches() const
{
	int count = 0;
	for ( int i = 0; i < columns.size(); i++ ) {
		if ( columns[ i ].first == columns[ i ].second ) count++;
	}	
	return count;
}

int Alignment::nNongaps() const
{
	int count = 0; 
	for ( int i = 0; i < columns.size(); i++ ) {
		if ( columns[ i ].first != GAP && columns[ i ].second != GAP ) count++;
	}	
	return count;		
}

// Alignment: alignment statistics: n1 = number of type1 indels; n2 = number of type2 indels; and the indel length distribution
// return the total number of events (matches and mismatches + indels)
int Alignment::stat( int& n1, int& n2, map< int, int >& lengthDistr ) const
{
	n1 = 0; n2 = 0; 
	lengthDistr.clear();
	
	int prevState = 0;
	int n0 = 0;
	int indelSize = 0;	// size of the current indel
	for ( int i = 0; i < columns.size(); ++i ) {
		int x1 = columns[ i ].first, x2 = columns[ i ].second;
		
		if ( x1 != GAP && x2 != GAP ) {
			n0++;
			if ( prevState != 0 ) {
				lengthDistr[ indelSize ]++;
			}
			prevState = 0;
		}
		else {
			if ( x1 == GAP ) {
				if ( prevState == 0 || prevState == 1 ) {
					n2++; indelSize = 1;
				}
				else { 
					indelSize++;
				}
				prevState = 2;
			}
			else {
				if ( prevState == 0 || prevState == 2 ) {
					n1++; indelSize = 1;
				}
				else {
					indelSize++;	
				}
				prevState = 1;					
			}
		}		
	}
	
	if ( prevState != 0 ) {
		lengthDistr[ indelSize ]++;		
	} 
	
	return n0 + n1 + n2;
}

// insert a column at the beginning of alignment
int Alignment::push_front( int x1, int x2 )
{
	assert( x1 >= 0 && x1 < ALPHABET_SIZE );
	assert( x2 >= 0 && x2 < ALPHABET_SIZE );
    if ( x1 == GAP && x2 == GAP ) return 0;
// 	assert( x1 != GAP || x2 != GAP );	// '-' is not aligned to '-'

	columns.insert( columns.begin(), make_pair( x1, x2 ) );		
	
	return 0;
}

// insert a column at the end of alignment
int Alignment::push_back( int x1, int x2 )
{
	assert( x1 >= 0 && x1 < ALPHABET_SIZE );
	assert( x2 >= 0 && x2 < ALPHABET_SIZE );
    if ( x1 == GAP && x2 == GAP ) return 0;
// 	assert( x1 != GAP || x2 != GAP );	// '-' is not aligned to '-'
	
	columns.push_back( make_pair( x1, x2 ) );
	
	return 0;
}

// Alignment: append another alignment at the front
int Alignment::append_front( const Alignment& other )
{
	for ( int i = other.size() - 1; i >= 0; --i ) {
		push_front( other[ i ].first, other[ i ].second );	
	}	
	
	return 0;
}

// append another alignment at the back
int Alignment::append_back( const Alignment& other )
{
	for ( int i = 0; i < other.size(); ++i ) {
		push_back( other[ i ].first, other[ i ].second );				
	}
	
	return 0;	
}

// Alignment: output operator
ostream& operator<<( ostream& os, const Alignment& aln )
{
	for ( int j = 0; j < 2; j++ ) {
		for ( int i = 0; i < aln.size(); i++ ) {
			if ( j == 0 ) os << ALPHABET[ aln[ i ].first ];	
			else os << ALPHABET[ aln[ i ].second ];
		}
		os << endl;
	}
	
	return os;
}

// Alignment: load Alignment from a file
int Alignment::load( const string& file, pair< string, string >& names, int format )
{
	// read the two sequences
	vector< Sequence > seqs;
	vector< string > seqNames;
	int rval = readSequences( file, seqs, seqNames, format );
	if ( rval == RET_ERROR || seqs.size() != 2 ) return RET_ERROR;

	// construct the alignment
	int l = seqs[ 0 ].size();
	if ( seqs[ 1 ].size() != l ) return RET_ERROR;
	for ( int i = 0; i < l; ++i ) {
        if ( seqs[0][i] == GAP && seqs[1][i] == GAP ) continue;
		push_back( seqs[ 0 ][ i ], seqs[ 1 ][ i ] );	
	}
	
	// get the names
	names.first = seqNames[ 0 ];
	names.second = seqNames[ 1 ];
	
	return 0;
}

// Alignment: load Alignment from a file
int Alignment::load( const string& file, int format )
{
	pair< string, string > names;
	int rval = load( file, names, format );
	
	return rval;
}

void Alignment::print( const string& file, const pair< string, string >& names, int format ) const
{
	// construct two sequences (including gaps)
	vector< Sequence > seqs( 2 );
	for ( int i = 0; i < columns.size(); i++ ) {
		seqs[ 0 ].push_back( columns[ i ].first );
		seqs[ 1 ].push_back( columns[ i ].second );		
	}	
	
	// print the alignment
	vector< string > seqNames;
	seqNames.push_back( names.first ); 
	seqNames.push_back( names.second );
	writeSequences( file, seqs, seqNames, format );
}

AlignmentBlock::AlignmentBlock( int _start, int _end, const pair< int, int >& _annot, bool _strand ) : start( _start ), end( _end ), annot( _annot ), strand( _strand )
{
	assert( start >= 0 );
	assert( start <= end );
	assert( annot.first == annot.second || annot.first == 0 || annot.second == 0 );
}

pair< SeqElement, SeqElement > AlignmentBlock::getElemPair( const Alignment& aln ) const
{
	SeqElement elem1, elem2;
	for ( int i = start; i < end; i++ ) {
		elem1.push_back( aln[ i ].first );
		elem2.push_back( aln[ i ].second );	
	}	
	
	return pair< SeqElement, SeqElement >( elem1, elem2 );
}

void AnnotatedAlignment::parse( vector< AlignmentBlock >& blocks ) const
{
	blocks.clear();
	
	int pos1 = 0, pos2 = 0; 	// the position index in seq1 and seq2 respectively	
	int annot1, annot2;			// the current annotation in seq1 and seq2 respectively
	bool strand;
	int i = 0;
	while ( i < aln.size() ) {
		int x = aln[ i ].first, y = aln[ i ].second;
		
		if ( x != GAP && seq1.getAnnot( pos1 ) ) {
			int start = i;
			annot1 = seq1.getAnnot( pos1 );	
			annot2 = y == GAP ? 0 : seq2.getAnnot( pos2 );	
			int l = motifs[ annot1 - 1 ].length();
			int currPos = pos1; 
			SeqElement elem;
			while ( pos1 < currPos + l ) {
				if ( aln[ i ].first != GAP ) { pos1++; elem.push_back( aln[ i ].first ); }
				if ( aln[ i ].second != GAP ) pos2++; 
				i++;				
			}
			int end = i;
			strand = motifs[ annot1 - 1 ].energy( elem ) > motifs[ annot1 - 1 ].energy( elem.compRevCompl() );
			blocks.push_back( AlignmentBlock( start, end, pair< int, int >( annot1, annot2 ), strand ) );
			continue;
		}		
		
		if ( y != GAP && seq2.getAnnot( pos2 ) ) {
			int start = i;
			annot1 = x == GAP ? 0 : seq1.getAnnot( pos1 );
			annot2 = seq2.getAnnot( pos2 );
			int l = motifs[ annot2 - 1 ].length();
			int currPos = pos2; 
			SeqElement elem;			
			while ( pos2 < currPos + l ) {
				if ( aln[ i ].first != GAP ) pos1++;
				if ( aln[ i ].second != GAP ) { pos2++; elem.push_back( aln[ i ].second ); }
				i++;
			}
			int end = i;
			strand = motifs[ annot2 - 1 ].energy( elem ) > motifs[ annot2 - 1 ].energy( elem.compRevCompl() );			
			blocks.push_back( AlignmentBlock( start, end, pair< int, int >( annot1, annot2 ), strand ) );
			continue;
		}
		
		if ( x != GAP ) pos1++;
		if ( y != GAP ) pos2++;	
		i++;
	}
}

void AnnotatedAlignment::extractConservedTfbs( vector< AlignmentBlock >& blocks ) const
{
	blocks.clear();
	int pos1 = 0, pos2 = 0; 	// the position index in seq1 and seq2 respectively	
	bool strand;
	int i = 0;
	while ( i < aln.size() ) {
		int x = aln[ i ].first, y = aln[ i ].second;
		
		if ( x != GAP && y != GAP && seq1.getAnnot( pos1 ) == seq2.getAnnot( pos2 ) && seq1.getAnnot( pos1 ) > 0 ) {
			int start = i;
			int annot = seq1.getAnnot( pos1 );	
			int l = motifs[ annot - 1 ].length();
			int currPos = pos1; 
			SeqElement elem;
			while ( pos1 < currPos + l ) {
				if ( aln[ i ].first != GAP ) { pos1++; elem.push_back( aln[ i ].first ); }
				if ( aln[ i ].second != GAP ) pos2++; 
				i++;				
			}
			int end = i;
			strand = motifs[ annot - 1 ].energy( elem ) > motifs[ annot - 1 ].energy( elem.compRevCompl() );
			blocks.push_back( AlignmentBlock( start, end, pair< int, int >( annot, annot ), strand ) );
			continue;
		}		
		
		if ( x != GAP ) pos1++;
		if ( y != GAP ) pos2++;	
		i++;
	}	
}

void AnnotatedAlignment::print( ostream& os, int lineMax ) const
{
	int i = 0;
	int pos1 = 0, pos2 = 0;		// the position index in seq1 and seq2 respectively
	
	while ( i < aln.size() ) {
		string seq1line, annot1line, seq2line, annot2line, matchline;
		bool containsTfbs1 = false, containsTfbs2 = false;
		
		// process each line
		for ( int j = 0; j < lineMax && i < aln.size(); j++ ) {
			int x = aln[ i ].first, y = aln[ i ].second;
			if ( x == y ) matchline.push_back( '|' );
			else matchline.push_back( ' ' );
			
			// the first sequence
			seq1line.push_back( ALPHABET[ x ] );
			if ( x != GAP ) {
				if ( seq1.getAnnot( pos1 ) ) {
					char buffer[ 10 ];
					sprintf( buffer, "%i", seq1.getAnnot( pos1 ) );
					annot1line += buffer;
					containsTfbs1 = true;
				 }
				else annot1line += " ";
				pos1++;
			} else {
				annot1line +=  " ";	
			}
			
			// the second sequence
			seq2line.push_back( ALPHABET[ y ] );
			if ( y != GAP ) {
				if ( seq2.getAnnot( pos2 ) ) {
					char buffer[ 10 ];
					sprintf( buffer, "%i", seq2.getAnnot( pos2 ) );
					annot2line += buffer;
					containsTfbs2 = true;
				 }
				else annot2line += " ";
				pos2++;
			} else {
				annot2line +=  " ";	
			}
			
			i++;			
		}
		
		// print the lines
		if ( containsTfbs1 ) os << annot1line << endl;		
		os << seq1line << endl;
		os << matchline << endl;
		os << seq2line << endl;
		if ( containsTfbs2 ) os << annot2line << endl;
		os << endl;	
	}
}

void AnnotatedAlignment::printConservedTfbsCols( const string& file ) const
{	
	// print the annotations
	ofstream fout( file.c_str() );
    if ( !fout ) {
        cerr << "Cannot open the file for printing conserved TFBS columns" << file << endl; 
        exit( 1 );
    }
	fout << name1 << "\t" << name2 << endl;
	
	int pos1 = 0, pos2 = 0; 	// the position index in seq1 and seq2 respectively	
	bool strand;
	int i = 0;
	while ( i < aln.size() ) {
		int x = aln[ i ].first, y = aln[ i ].second;
		
		if ( x != GAP && y != GAP && seq1.getAnnot( pos1 ) == seq2.getAnnot( pos2 ) && seq1.getAnnot( pos1 ) > 0 ) {
			fout << pos1 << "\t" << pos2 << endl;
		}		
		
		if ( x != GAP ) pos1++;
		if ( y != GAP ) pos2++;	
		i++;
	}		
}

void AnnotatedAlignment::printConservedTfbsCols( ostream& os ) const
{
	os << name1 << "\t" << name2 << endl;
	
	int pos1 = 0, pos2 = 0; 	// the position index in seq1 and seq2 respectively	
	bool strand;
	int i = 0;
	while ( i < aln.size() ) {
		int x = aln[ i ].first, y = aln[ i ].second;
		
		if ( x != GAP && y != GAP && seq1.getAnnot( pos1 ) == seq2.getAnnot( pos2 ) && seq1.getAnnot( pos1 ) > 0 ) {
			os << pos1 << "\t" << pos2 << endl;
		}		
		
		if ( x != GAP ) pos1++;
		if ( y != GAP ) pos2++;	
		i++;
	}		    
}

