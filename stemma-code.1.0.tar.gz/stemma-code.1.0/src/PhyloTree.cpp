// PhyloTree.cpp: implementation of the PhyloTree class.
//
//////////////////////////////////////////////////////////////////////

#include "PhyloTree.h"

PhyloTree::Node::Node(PhyloTree::Node* n)
	: name(n->getName()), inName(n->getInternalName())
	, seqInd(n->getSeqInd()), t_branch(n->getBranchLength())
{
	children.clear();
	parent = NULL;
}

PhyloTree::Node::~Node()
{
	for( int i=0; i<children.size(); i++ ) {
		delete children[i];
	}
	children.clear();
}

void PhyloTree::Node::Print(FILE *fp) const
{  
  if (children.size() == 0) {
    fprintf(fp,"%s:%.2f",name.c_str(),t_branch);
    return;
  }
  fprintf(fp,"(");
  vector<Node *>::const_iterator it = children.begin();
  (*it)->Print(fp);
  for (++it; it != children.end(); ++it) {
    fprintf(fp,", ");
	Node* child = (*it);
    child->Print(fp);
  }
  fprintf(fp,")%s:%.2f",name.c_str(),t_branch);
}

void PhyloTree::Node::Print(ostream &os) const
{  
  if (children.size() == 0) {
    os<< name << ":" << t_branch;
    return;
  }

  os << "(";
  vector<Node *>::const_iterator it = children.begin();
  (*it)->Print(os);
  for (++it; it != children.end(); ++it) {
    os << ", ";
    Node* child = (*it);
    child->Print(os);
  }
  os << ")" << name << ":" << t_branch;
}

void PhyloTree::Node::Print_internal(ostream &os) const
{  
  if (children.size() == 0) {
 	os<< inName << ":" << t_branch;
    return;
  }

  os << "(";
  vector<Node *>::const_iterator it = children.begin();
  (*it)->Print_internal(os);
  for (++it; it != children.end(); ++it) {
    os << ", ";
    Node* child = (*it);
    child->Print_internal(os);
  }
  os << ")" << inName << ":" << t_branch;
}

void PhyloTree::Print(FILE *fp) const
{
  if( (root->children).size() )
  {
	  fprintf(fp,"(");
	  vector<Node *>::const_iterator it = root->children.begin();
	  (*it)->Print(fp);
	  for (it++; it != root->children.end(); it++) {
		fprintf(fp, ", ");
		(*it)->Print(fp);
	  }
	  fprintf(fp, ")");
  }
  fprintf(fp, "%s;", root->getName().c_str());
}

void PhyloTree::Print(ostream &os) const
{
  if( (root->children).size() )
  {
	  os<< "(";
	  vector<Node *>::const_iterator it = root->children.begin();
	  (*it)->Print(os);
	  for (it++; it != root->children.end(); it++) {
		  os<<", ";
		  (*it)->Print(os);
	  }
	  os<< ")";
  }
  os << root->getName() << ";" <<endl;
}

void PhyloTree::Print_full(ostream &os) const
{
  if( (root->children).size() )
  {
	  os<< "(";
	  vector<Node *>::const_iterator it = root->children.begin();
	  (*it)->Print_internal(os);
	  for (it++; it != root->children.end(); it++) {
		  os<<", ";
		  (*it)->Print_internal(os);
	  }
	  os<< ")";
  }
  os << root->getInternalName() << ";" <<endl;
}

void PhyloTree::ReadPhyloTree(FILE *fp)
{
  if (fp == NULL) {
	  cerr<< "Error: Phylogeny tree file could not be opened!" <<endl;
	  exit(INPUT_ERROR);
  }
  root = ReadPhyloTreeHelper(fp,0);
  root->parent = NULL;
}

void PhyloTree::load(const string& filename) {
  FILE *fp = fopen(filename.c_str(), "r");
  ReadPhyloTree(fp);
  fclose(fp);
}

void PhyloTree::get_comment(FILE *f)
{
  char line[MAX_LINE];
  char c;
  do
    {
      c=fgetc(f);
      if (c=='\n' || c=='\r') {lineid++;}
    } while (c==' ' || c=='\n' || c=='\t' || c=='\r');
  
  if (c=='/') 
    {
      char foo;
      fscanf(f,"%[^\n\r]%c",line,&foo);
      
      lineid++;
      
      get_comment(f);
    }
  else
    {
      ungetc(c,f);
    }
}

// this piece came from MB's Footprinter
PhyloTree::Node *PhyloTree::ReadPhyloTreeHelper(FILE *f, int depth)
{
  char c;
  PhyloTree::Node* here=new PhyloTree::Node;
  PhyloTree::Node* child;
  get_comment(f);

  c=fgetc(f);
  if (c=='(')
  {
    do
	{
	  get_comment(f);
	  child=ReadPhyloTreeHelper(f,depth+1);
	  here->children.push_back(child);
	  child->parent = here;
	  get_comment(f);
	  c=fgetc(f);
	  if (c=='\n' || c=='\r') lineid++;
	    
	  if (c!=',' && c!=')') 
	  {
		cerr<< "ERROR: Wrong format in the tree file, at line "<< lineid+1 << endl;
		exit(INPUT_ERROR);
	  }
	} while (c!=')');
     
    get_comment(f);
      
    char buf[MAX_LINE];
    int x=fscanf(f,"%[^:, \n\r\t();]",buf);
	if (x>=1)
	{
		here->setName(buf);
		here->setInternalName(buf);
	}
	else
	{
	  here->setName("");
	  //cerr<< "ERROR: Missing node label in the tree file, at line " << lineid <<endl;
	  //cerr<< "Note, label for internal nodes are required!"<<endl;
	  //exit(INPUT_ERROR);
	}

    get_comment(f);
    float bl;
	int isbl=0;
    isbl=fscanf(f,":%f",&bl);
    if (isbl) here->setBranchLength(bl);
	else
	{
		// check whether reached the end of the tree symbol ";"
		char ch=fgetc(f);
		if (ch != ';')
		{
			here->setBranchLength(1.0);
			//cerr<< "ERROR: Wrong format in the tree file, at line " << lineid <<endl;
			//cerr<< "Branch length is missed for node: "<< buf <<endl;
			//exit(INPUT_ERROR);
		}
		else here->setBranchLength(0.0);
	}
  }
  else
  {
    ungetc(c,f);
    get_comment(f);
	char buf[MAX_LINE];
    int x=fscanf(f,"%[^:, \n\r\t();]",buf);
    if (x>=1)
	{
	  here->setName(buf);
	  here->setInternalName(buf);
	}
    else
	{
	  cerr<< "ERROR: Missing node label in the tree file, at line " << lineid <<endl;
	  exit(INPUT_ERROR);
	}
	
    get_comment(f);
    float bl;
    int isbl=0;
    isbl=fscanf(f,":%f",&bl);
	if (isbl) here->setBranchLength(bl);
	else
	{
	  here->setBranchLength(1.0);
	  //cerr<< "ERROR: Wrong format in the tree file, at line " << lineid <<endl;
	  //cerr<< "Branch length is missed for node: "<< buf <<endl;
	  //exit(INPUT_ERROR);		
	}
  }
  
  if ( here->getName().compare("") == 0 ) { 
	  char buf[MAX_LINE];
	  sprintf(buf, "Internal%d", count);
	  string name(buf);
	  here->setInternalName(name);
	  count++;
  }
  
  this->numNodes++;
  return here;
}

void PhyloTree::indexNode( const vector< string > &seqNames )
{
	bool * findNode = new bool [seqNames.size()];
	for (int i=0; i<seqNames.size(); i++) findNode[i] = false;
	root->indexNode(seqNames, findNode);
	
	for (int i=0; i<seqNames.size(); i++) {
		if(! findNode[i]) {
			cerr << "Cannot find sequence " << seqNames[i] << " in the input phylogeny!" <<endl;
			exit( INPUT_ERROR );
		}
	}
	delete [] findNode;
}

void PhyloTree::Node::indexNode( const vector< string > &seqNames, bool * findNode)
{
	if (children.size()) {
		for (vector<Node *>::const_iterator it = children.begin(); it != children.end(); it++) {
			(*it)->indexNode(seqNames, findNode);
		}
	}
	
	for (int i=0; i<seqNames.size(); i++) {
		if( strcmp(seqNames[i].c_str(), this->name.c_str()) == 0 )
		{
			this->setSeqInd(i);
			if(! findNode[i]) findNode[i] = true;
			else
			{
				cerr<< "Found duplicate sequence names in the input phylogeny: " << this->name <<endl;
				exit( INPUT_ERROR );
			}
			return;
		}
	}
	cerr << "Cannot find the sequence: " << this->name << endl;
	exit( INPUT_ERROR );
}

PhyloTree::Node* PhyloTree::Node::recCopy()
{
	Node * newRoot = new Node(this);
	vector< Node* > children = this->children;
	for (vector< Node* >::const_iterator it=children.begin(), end=children.end(); it!=end; ++it)
	{
		Node * c = (*it)->recCopy();
		c->parent = newRoot;
		newRoot->children.push_back(c);
	}

	return newRoot;
	
}

void PhyloTree::adjustNumOfNodes()
{
	this->numNodes = 0;
	vector<Node *> list_nodes;
	list_nodes.push_back(this->root);
	while(list_nodes.size())
	{
		Node * cur=list_nodes.front();
		this->numNodes +=1;
		if(cur->children.size())
		{
			for(int i=0; i<cur->children.size(); ++i)
				list_nodes.push_back(cur->children[i]);
		}
		list_nodes.erase(list_nodes.begin());
	}

	return;
}

void PhyloTree::subTree(const vector<string> &seqNames, PhyloTree &subTree) const
{
 	// mark the nodes on the subtree
	map<string, int> node2Count;
	vector< Node* > targetNodes;
	for (int i=0; i<seqNames.size(); ++i)
	{
		Node * n=this->findNodeByName(seqNames[i]);
		if (!n)
		{
			cerr <<"ERROR: could not find the node with name \"" << seqNames[i] <<"\"" <<endl;
			exit(INPUT_ERROR);
		}
		targetNodes.push_back(n);
		while(n)
		{			
			map< string, int >::const_iterator iter=node2Count.find(n->getInternalName());
			if (iter==node2Count.end())
				node2Count[n->getInternalName()]=1;
			else
				node2Count[n->getInternalName()]+=1;
			n=n->parent;
		}
	}

	// find the latest common ancestor
	Node * curRoot;
	for (vector< Node* >::const_iterator it=targetNodes.begin(), end=targetNodes.end(); it!=end; ++it)
	{
		curRoot = (*it);
		while(curRoot!=this->root)
		{
			//common ancestor
			if (node2Count[curRoot->getInternalName()]==seqNames.size()) break;
			curRoot=curRoot->parent;
		}
	}

	// build the new subtree 
	Node * newRoot = curRoot->recCopy();
	subTree.setRoot(newRoot);

	// remove inrelevant nodes
	vector<Node *> list_nodes;
	list_nodes.push_back(newRoot);
	while(list_nodes.size())
	{
		Node * cur=list_nodes.front();

		list_nodes.erase(list_nodes.begin());
		vector<Node *> c;
		for (int i=0; i<cur->children.size(); ++i)
		{
			if (node2Count[cur->children[i]->getInternalName()]>0)
			{
				c.push_back(cur->children[i]);
			}
			else
			{
				delete cur->children[i];
			}
		}
		if (c.size()==1)	// delete current internal node
		{
			double len = c[0]->getBranchLength();
			c[0]->setBranchLength( len + cur->getBranchLength() );
			for(int i=0; i<cur->parent->children.size(); ++i)
			{
				if (cur->parent->children[i] == cur)
				{
					cur->parent->children[i] = c[0];
					break;
				}
			}
			c[0]->parent = cur->parent;
			cur->children.clear();
			delete cur;
		}
		else
		{
			cur->children = c;
		}
		for(int i=0; i<c.size();++i)
		{
			list_nodes.push_back(c[i]);
		}
	}
	
	subTree.adjustNumOfNodes();
	return;
}

// BFS
PhyloTree::Node* PhyloTree::findNodeByName(const string& name) const
{
	vector<Node *> list_nodes;
	list_nodes.push_back(this->root);
	while(list_nodes.size())
	{
		Node * cur=list_nodes.front();
		if (name.compare(cur->getName())==0) return cur;
		if(cur->children.size())
		{
			for(int i=0; i<cur->children.size(); ++i)
				list_nodes.push_back(cur->children[i]);
		}
		list_nodes.erase(list_nodes.begin());
	}
	return NULL;
}

void PhyloTree::reroot(string nodeName, PhyloTree &newTree) const
{
	Node * n=this->findNodeByName(nodeName);
	if (!n)
	{
		cerr <<"ERROR: could not find the node: " << nodeName <<endl;
		exit(INPUT_ERROR);
	}

	if (n==this->root || n->parent == this->root)	// no need to reroot, just cp the entire tree
	{
		Node * new_root = this->root->recCopy();
		newTree.setRoot(new_root);
		return;
	}
	
	Node * new_root = new Node();
	newTree.setRoot(new_root);
	new_root->setSeqInd(-1);
	new_root->setName("");
	new_root->setInternalName("NEWROOT");
	new_root->setBranchLength(0);
	new_root->parent = NULL;
	
	Node * cur_node = n->recCopy();
	new_root->children.push_back(cur_node);
	cur_node->parent = new_root;
	cur_node->setBranchLength(n->getBranchLength());
	
	Node * cur_parent = n->parent;
	Node * pre_node = new_root;
	while(cur_parent)
	{
		cur_node = new Node();
		pre_node->children.push_back(cur_node);
		cur_node->parent = pre_node;
		cur_node->setSeqInd(cur_parent->getSeqInd());
		cur_node->setName(cur_parent->getName());
		cur_node->setInternalName(cur_parent->getInternalName());
		for (vector<Node *>::iterator it=cur_parent->children.begin(); it!=cur_parent->children.end(); ++it)
		{
			if ((*it) != n)
			{	
				Node * tmp_node = (*it)->recCopy();
				cur_node->children.push_back(tmp_node);
			}
			else
				cur_node->setBranchLength(n->getBranchLength());
		}
		n = cur_parent;
		cur_parent = cur_parent->parent;
		pre_node = cur_node;
	}
	double bl = new_root->children[0]->getBranchLength()/2.0;
	new_root->children[0]->setBranchLength(bl);
	new_root->children[1]->setBranchLength(bl);

	// remove the old root node if it now has only one child, and let the new root re-use old root node's infomation
	if (cur_node->children.size() == 1)
	{
		for (vector<Node *>::iterator it=cur_node->children.begin(); it!=cur_node->children.end(); ++it)
		{
			double bl = (*it)->getBranchLength();
			(*it)->setBranchLength(bl+cur_node->getBranchLength());
			(*it)->parent=cur_node->parent;
			cur_node->parent->children.push_back(*it);
		}
		for (vector<Node *>::iterator it=cur_node->parent->children.begin(); it!=cur_node->parent->children.end(); ++it)
		{
			if ((*it) == cur_node)
			{
				cur_node->children.clear();
				cur_node->parent->children.erase(it);
				break;
			}
		}
		new_root->setSeqInd(cur_node->getSeqInd());
		new_root->setName(cur_node->getName());
		new_root->setInternalName(cur_node->getInternalName());
	}	

	newTree.adjustNumOfNodes();
	return;
}
