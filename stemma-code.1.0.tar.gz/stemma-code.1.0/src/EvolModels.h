// EvolModels.h: interface for the evlotionary model related classes.
// Nucleotide Substitution Models
//
//////////////////////////////////////////////////////////////////////

#ifndef EVOL_MODELS_H
#define EVOL_MODELS_H

#include <gsl/gsl_eigen.h>

#include "Sequence.h"

// p22 in PAML manual
enum SubstModelType { JC, K80, F81, F84, HKY, T92, TN93, REV };

/*****************************************************
* SubstModel class: Basic Nucleotide Substitution Model
* implement the generic method of computing the transition probabilities via matrix exponential
******************************************************/

class SubstModel {
protected:
	Matrix rateMatrix;		// transition rate matrix
	vector< double > pi;	// equilibrium distribution 

	// diagonalization of the rate matrix: Q = U * Gamma * invU, where Gamma is diagonal
	vector< double > eigenvalues;
	Matrix U, invU;
public:
	// constructor
	SubstModel();
	SubstModel( const vector< double >& _pi );
	SubstModel( const Matrix& _rateMatrix, const vector< double >& _pi );

	~SubstModel() { pi.clear(); eigenvalues.clear(); }
	
	// access methods
	const Matrix& getRateMatrix() const { return rateMatrix; }
	const vector< double >& getPi() const { return pi; }
	
//	// the substitution rate
//	double getRate() const;
	
	// compute the eigenvalues and eigenvectors of the rate matrix
	void diagonalize();
	
	// compute the transition probability matrix for a given time
	virtual Matrix compProbMatrix( double t );
	
	// propose a random change given the current nt.
	int randomMove( const gsl_rng* rng, int currNt );
	
	// I/O
	void dumpRateMatrix( ostream& os ) const;	

};

/*****************************************************
* SubstModel_JC class: the JC Nucleotide Substitution Model
* Table 1.1 in "Computational Molecular Evolution", Yang
******************************************************/
/*
class SubstModel_JC : public SubstModel {
	double rate;		// total substitution rate
public:
	// constructor
	SubstModel_JC( double _rate );
		
	// access methods
	double getRate() const { return rate; }
	void setRate( double _rate ) { assert( _rate > 0 ); rate = _rate; }
	
	// compute the transition probability matrix for a given time
	Matrix compProbMatrix( double t );
	
private:
	// initialization method
	void init();
};
*/
/*****************************************************
* SubstModel_F81 class: the F81 Nucleotide Substitution Model
* from the original paper, Felsenstein, JME'81
******************************************************/
/*
class SubstModel_F81: public SubstModel {
	double rate;		// total substitution rate
public:
	// constructor
	SubstModel_F81( double _rate, const vector< double >& _pi );

	// access methods
	double getRate() const { return rate; }
	void setRate( double _rate ) { assert( _rate > 0 ); rate = _rate; }
	
	// compute the transition probability matrix for a given time
	Matrix compProbMatrix( double t );
	
private:
	// initialization method
	void init();
};
*/

/*****************************************************
* SubstModel_HKY class: the F81 Nucleotide Substitution Model
* Table 1.1 in "Computational Molecular Evolution", Yang
******************************************************/

class SubstModel_HKY : public SubstModel {
	double alpha;			// transition rate
	double beta;			// transversion rate
public:
	// constructor
	SubstModel_HKY( double _alpha, double _beta, const vector< double >& _pi );
	// constructor: alternative parameterization
	// rate = average rate/site, bias = transition/transversion bias
	SubstModel_HKY( const vector< double >& _pi, double rate, double bias );

	// access methods
	double getAlpha() const { return alpha; }
	double getBeta() const { return beta; }
	void setRates( double _alpha, double _beta ) { assert( _alpha > 0 && _beta > 0 ); alpha = _alpha; beta = _beta; }
	
	// compute the transition probability matrix for a given time
	Matrix compProbMatrix( double t );
	
private:
	// initialization method
	void init();
};

/*****************************************************
* SubstModel_HB class: the F81 Nucleotide Substitution Model
* Table 1.1 in "Computational Molecular Evolution", Yang
******************************************************/

class SubstModel_HB : public SubstModel {
	const Matrix neutRateMatrix;	// transition rate matrix for neut sequences
public:
	// constructor
	SubstModel_HB( const vector< double >& _pi, const Matrix& _neutRateMatrix );
};


/*****************************************************
* Precomputing Data for a Given Model
******************************************************/

/* time related parameters */

/*
class TimeParam {
public:	
	double t1, t2;	// branch lengths
	double delta_t;		// size of an interval
	
	int n1, n2, n;		// number of intervals of t1, t2 and t (total time), or branch length in delta_t unit
	
	// constructor
	TimeParam( double _t1, double _t2, double _delta_t );		
};
*/

/* probabilities under an evolution model for different time (not equal to 0)*/
/*
class EvolData {
public:		
	TimeParam tp;
	
	// evolutionary parameters
	vector< double > pi;	// stationary distribution of nts
	double rate;		// substitution rate
	double bias;		// transition/transversion bias
	double lambda;		// insertion rate
	double mu;			// deletion rate
	double r;			// indel length parameter

	// weight of a nt. (probability of sampling a nt.)
	double weight;
	
	// rate matrix of the substitution model
	Matrix rateMatrix;
	
	// precomputed data: equlibrium distribution
	vector< double > log_pi;
	
	// precomputed data: substitution probabilities
	vector< Matrix > transProbs;	// P(a-->b|t) for any a, b and t
	vector< Matrix > log_transProbs;	// log. of transProbs		
	vector< Matrix > probs;		// P(a,b|t) for any a, b and t
	vector< Matrix > log_probs;	// log. of probs
	
	// precomputed data: indel probabilities
	double log_r;		// log( r )
	double log_r_compl;		// log( 1 - r )
	vector< double > log_ins_probs;		// log( lambda * t ) for any t, 0 <= t <= t1 + t2
	vector< double > log_del_probs;		// log( mu * t ) for any t, 0 <= t <= t1 + t2
	vector< double > no_indel_probs;	// 1 - lambda * t - mu * t for any t
	vector< double > log_no_indel_probs;	// log( 1 - lambda * t - mu * t ) for any t, 0 <= t <= t1 + t2
	Matrix log_indel_probs;		// log( lambda * tuo1 + mu * tuo2 ), 0 <= tuo1, tuo2 <= t1 + t2
	Matrix log_indel_probs_compl;	// log( 1 - lambda * tuo1 - mu * tuo2 ), 0 <= tuo1, tuo2 <= t1 + t2
			
	// precomputed data: power of weight
	double log_weight;
	vector< double > weightPowers;
	
	static int maxLength;
	 
	// constructor
	EvolData( const TimeParam& _tp, const vector< double >& _pi, double _rate, double _bias, double _lambda, double _mu, double _r, double _weight = 1.0 );	
			
	// destructor
	~EvolData() {}
	
	// reset the data 
	void reset( double _weight );
	void reset( double _rate, double _lambda, double _mu, double _r );
	void reset( double _weight, double _rate, double _lambda, double _mu, double _r );
	
	// output
	friend ostream& operator<<( ostream& os, const EvolData& ed );
private:
	void compSubstProbs();
	void compIndelProbs();
	void compWeightProbs();
};
*/

/* probabilities under TFBS evolution model for different time (not equla to 0)*/
/*
class TfbsEvolData {
public:	
	TimeParam tp;
	
	//const SubstModel* bgSubstModel;		// the background model for substitution
	Matrix bgRateMatrix;		// background rate matrix used for the HB model
	vector< double > pi;		// background stationary distribution of nts
	
	// TFBS parameters
	TfbsMotif motif;		// motif of the Tfbs
	double weight;		// prior weight of a TFBS
	//int nCorePos;		// number of "core" positions (for computing rho)
	
	// precomputed data: PWM
	Matrix log_pwm;
	
	// position specific rate matricies 
	vector< Matrix > rateMatrices;
	
	// precomputed data: substitution probabilities for each position
	vector< vector< Matrix > > transProbs;
	vector< vector< Matrix > > log_transProbs;
	vector< vector< Matrix > > probs;
	vector< vector< Matrix > > log_probs;
	
	// precomputed data: rate of indels within Tfbs, as a fraction of the background rate
	double rho;	
	
	// precomputed data: log weight
	double log_weight;
	
	// constructor
	TfbsEvolData( const TimeParam& _tp, const Matrix& _bgRateMatrix, const vector< double >& _pi, const TfbsMotif& _motif, double _rho, double _weight = 1.0 );
	
	// destructor
	~TfbsEvolData() {}
	
	// reset the data according to the given parameters 
	void reset( double _weight );
	void reset( const Matrix& _bgRateMatrix );
	void reset( double _weight, const Matrix& _bgRateMatrix );
		
	// output
	friend ostream& operator<<( ostream& os, const TfbsEvolData& td );	
private:
	void compSubstProbs();
	//void comp_rho();
};
*/

#endif
