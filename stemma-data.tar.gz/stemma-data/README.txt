1. Motif data
---------------------
motifs/blastoderm_motifs: four blastoderm motifs used in the experiment of
predicting the binding locations of individual TFs.
    motifs/blastoderm_motifs/*.wtmx are the PWMs of the four blastoderm motifs
    motifs/blastoderm_motifs/*_p002.thr are the energy thresholds (LLR socres)
      used for the four motifs, at p-value 0.002
motifs/dmel_motif_library.1: has 173 drosophila motifs collected from multiple
resources, used in the experiment of decoding the cis-regulatory program of
anterior-posterior (AP) pattern formation in Drosophila embryonic development.
    motifs/dmel_motif_library.1/wtmx/*.wtmx are the wtmx files for each motif
      resource.

2.  Sequences used for the TF target prediction
---------------------
ChIP/*.gff has the TF target sequence for each of the four blastoderm motifs.
ChIP/*_P_1_table.csv.100.gff has the negative sequence for evaluation of TF
target prediction.

3. Sequences used for the CRM decoding of Drosophila AP genes
---------------------
AP_set/Schroeder_PLoSBiology04.Fig4.txt has the 21 AP genes as the positive
gene set.
AP_set/negative_genes.txt has the 198 randomly sampled genes as the negative
gene set.
AP_set/dmel_redfly.Release4.crm.txt has the known CRM for the 21 AP genes,
from REDFly

4. Phylogeny data
----------------------
tree_files/tree.melanogaster_6.txt: phylogeny of the 6 drosophila species in the melanogaster group, in newick format.
tree_files/tree.fly_12.txt: phelogeny of all 12 sequenced drosophila species, in newick format.

